//! Unrun proposal: adopt as a manager child only with the complete Ephemeral caller B slice.
//! Uses current public callers and the held-provider pattern from auth_refresh_failure_tests.
use super::AuthManager;
use super::CodexAuth;
use super::ExternalAuth;
use super::ExternalAuthFuture;
use super::ExternalAuthRefreshContext;
use super::RefreshTokenError;
use super::load_auth_dot_json;
use super::logout;
use super::save_auth;
use crate::auth::storage::AuthDotJson;
use codex_config::types::AuthCredentialsStoreMode;
use codex_config::types::AuthKeyringBackendKind;
use pretty_assertions::assert_eq;
use std::sync::Arc;
use std::time::Duration;
use tempfile::TempDir;
use tokio::sync::Notify;
use tokio::sync::Semaphore;
use tokio::time::Instant;

enum HeldCall {
    Resolve,
    Refresh,
}
struct Provider {
    initial: CodexAuth,
    refreshed: CodexAuth,
    held: HeldCall,
    entered: Notify,
    release: Semaphore,
}
impl ExternalAuth for Provider {
    fn resolve(&self) -> ExternalAuthFuture<'_, CodexAuth> {
        Box::pin(async {
            if matches!(self.held, HeldCall::Resolve) {
                self.entered.notify_one();
                self.release.acquire().await.unwrap().forget();
            }
            Ok(self.initial.clone())
        })
    }
    fn refresh(&self, context: ExternalAuthRefreshContext) -> ExternalAuthFuture<'_, CodexAuth> {
        Box::pin(async move {
            assert_eq!(context.previous_account_id.as_deref(), Some("account-a"));
            if matches!(self.held, HeldCall::Refresh) {
                self.entered.notify_one();
                self.release.acquire().await.unwrap().forget();
            }
            Ok(self.refreshed.clone())
        })
    }
}
fn provider(initial: &CodexAuth, refreshed: &CodexAuth, held: HeldCall) -> Arc<Provider> {
    Arc::new(Provider {
        initial: initial.clone(),
        refreshed: refreshed.clone(),
        held,
        entered: Notify::new(),
        release: Semaphore::new(/*permits*/ 0),
    })
}
fn auth(token: &str) -> CodexAuth {
    CodexAuth::from_external_chatgpt_tokens(token, "account-a", /*chatgpt_plan_type*/ None)
        .unwrap()
}
fn manager(home: &TempDir) -> Arc<AuthManager> {
    let mut manager = AuthManager::from_optional_auth_for_testing(/*auth*/ None);
    let unique = Arc::get_mut(&mut manager).unwrap();
    unique.codex_home = home.path().to_path_buf();
    unique.auth_credentials_store_mode = AuthCredentialsStoreMode::Ephemeral;
    manager
}
fn observed(manager: &AuthManager, home: &TempDir) -> (Option<AuthDotJson>, Option<AuthDotJson>) {
    let stored = load_auth_dot_json(
        home.path(), AuthCredentialsStoreMode::Ephemeral, AuthKeyringBackendKind::default(),
    ).unwrap();
    // CodexAuth equality compares token-backed modes only; inspect the complete payloads.
    let cached = manager.auth_cached().as_ref().and_then(CodexAuth::get_current_auth_json);
    (stored, cached)
}
#[derive(Clone, Copy)]
enum RefreshPath {
    Guarded,
    Direct,
}
async fn refresh(manager: &AuthManager, path: RefreshPath) -> Result<(), RefreshTokenError> {
    match path {
        RefreshPath::Guarded => manager.refresh_token().await,
        RefreshPath::Direct => manager.refresh_token_from_authority().await,
    }
}
enum SourceChange {
    EqualReplacement,
    SameArcAba,
}

#[tokio::test]
async fn ephemeral_old_refresh_success_cannot_publish_after_equal_source_replacement_or_aba() {
    for path in [RefreshPath::Guarded, RefreshPath::Direct] {
        for change in [SourceChange::EqualReplacement, SourceChange::SameArcAba] {
            let deadline = Instant::now() + Duration::from_secs(/*secs*/ 5);
            let home = tempfile::tempdir().unwrap();
            let manager = manager(&home);
            let initial = auth("initial.e30.signature");
            let old_result = auth("stale.e30.signature");
            let original = provider(&initial, &old_result, HeldCall::Refresh);
            tokio::time::timeout_at(deadline, async {
                manager.set_external_auth(original.clone()).await.unwrap();
                let source_before = manager.inner.read().unwrap().source_revision.clone();
                let revision = manager.inner.read().unwrap().revision.clone();
                let changes = manager.auth_change_state_receiver();
                let alter = async {
                    original.entered.notified().await;
                    let replacement = provider(&initial, &initial, HeldCall::Refresh);
                    manager.set_external_auth(replacement.clone()).await.unwrap();
                    let selected = match change {
                        SourceChange::EqualReplacement => replacement,
                        SourceChange::SameArcAba => {
                            manager.set_external_auth(original.clone()).await.unwrap();
                            original.clone()
                        }
                    };
                    let source = manager.inner.read().unwrap().source_revision.clone();
                    assert_ne!(source, source_before);
                    assert_eq!(manager.inner.read().unwrap().revision, revision);
                    let published = (source, *changes.borrow());
                    original.release.add_permits(/*n*/ 1);
                    (selected, published)
                };
                let (result, (selected, published)) = tokio::join!(refresh(&manager, path), alter);
                assert!(result.is_err());
                let expected = initial.get_current_auth_json();
                assert_eq!(observed(&manager, &home), (expected.clone(), expected));
                let selected_owner: Arc<dyn ExternalAuth> = selected.clone();
                assert!(Arc::ptr_eq(&manager.external_auth_provider().unwrap(), &selected_owner));
                assert_eq!(
                    (manager.inner.read().unwrap().source_revision.clone(), *changes.borrow()),
                    published,
                );
                assert_eq!(manager.refresh_failure_for_auth(&initial), None);
                // A new operation of the selected source must still be able to commit.
                selected.release.add_permits(/*n*/ 1);
                refresh(&manager, path).await.unwrap();
                let accepted = selected.refreshed.get_current_auth_json();
                assert_eq!(observed(&manager, &home), (accepted.clone(), accepted));
                assert!(manager.logout().await.unwrap());
            }).await.unwrap();
        }
    }
}

enum RawMutation {
    EqualSave,
    AbsentDelete,
}
#[tokio::test]
async fn ephemeral_held_install_rejects_equal_save_and_absent_delete() {
    for mutation in [RawMutation::EqualSave, RawMutation::AbsentDelete] {
        let deadline = Instant::now() + Duration::from_secs(/*secs*/ 5);
        let home = tempfile::tempdir().unwrap();
        let manager = manager(&home);
        let existing = auth("existing.e30.signature").get_current_auth_json().unwrap();
        if matches!(mutation, RawMutation::EqualSave) {
            save_auth(home.path(), &existing, AuthCredentialsStoreMode::Ephemeral,
                AuthKeyringBackendKind::default()).unwrap();
        }
        let before = observed(&manager, &home);
        let source = manager.inner.read().unwrap().source_revision.clone();
        let changes = manager.auth_change_state_receiver();
        let generation = *changes.borrow();
        let candidate = auth("stale.e30.signature");
        let candidate = provider(&candidate, &candidate, HeldCall::Resolve);
        tokio::time::timeout_at(deadline, async {
            let alter = async {
                candidate.entered.notified().await;
                match mutation {
                    RawMutation::EqualSave => save_auth(
                        home.path(), &existing, AuthCredentialsStoreMode::Ephemeral,
                        AuthKeyringBackendKind::default(),
                    ).unwrap(),
                    RawMutation::AbsentDelete => assert!(!logout(
                        home.path(), AuthCredentialsStoreMode::Ephemeral,
                        AuthKeyringBackendKind::default(),
                    ).unwrap()),
                }
                candidate.release.add_permits(/*n*/ 1);
            };
            let (result, ()) = tokio::join!(manager.set_external_auth(candidate.clone()), alter);
            assert!(result.is_err());
            assert_eq!(observed(&manager, &home), before);
            assert!(!manager.has_external_auth());
            assert_eq!(manager.inner.read().unwrap().source_revision, source);
            assert_eq!(*changes.borrow(), generation);
            logout(home.path(), AuthCredentialsStoreMode::Ephemeral,
                AuthKeyringBackendKind::default()).unwrap();
        }).await.unwrap();
    }
}

#[tokio::test]
async fn ephemeral_manager_logout_prevents_held_refresh_success_from_resurrecting_auth() {
    for path in [RefreshPath::Guarded, RefreshPath::Direct] {
        let deadline = Instant::now() + Duration::from_secs(/*secs*/ 5);
        let home = tempfile::tempdir().unwrap();
        let manager = manager(&home);
        let initial = auth("initial.e30.signature");
        let original = provider(&initial, &auth("stale.e30.signature"), HeldCall::Refresh);
        tokio::time::timeout_at(deadline, async {
            manager.set_external_auth(original.clone()).await.unwrap();
            let changes = manager.auth_change_state_receiver();
            let alter = async {
                original.entered.notified().await;
                assert!(manager.logout().await.unwrap());
                assert_eq!(observed(&manager, &home), (None, None));
                let published = (manager.inner.read().unwrap().source_revision.clone(), *changes.borrow());
                original.release.add_permits(/*n*/ 1);
                published
            };
            let (result, published) = tokio::join!(refresh(&manager, path), alter);
            assert!(result.is_err());
            assert_eq!(observed(&manager, &home), (None, None));
            assert!(!manager.has_external_auth());
            assert_eq!(manager.refresh_failure_for_auth(&initial), None);
            assert_eq!(
                (manager.inner.read().unwrap().source_revision.clone(), *changes.borrow()),
                published,
            );
        }).await.unwrap();
    }
}

struct ReloadProvider {
    provider: Provider,
    calls: std::sync::atomic::AtomicUsize,
}
impl ExternalAuth for ReloadProvider {
    fn resolve(&self) -> ExternalAuthFuture<'_, CodexAuth> {
        Box::pin(async {
            if self.calls.fetch_add(/*val*/ 1, std::sync::atomic::Ordering::SeqCst) == 0 {
                return Ok(self.provider.initial.clone());
            }
            self.provider.entered.notify_one();
            self.provider.release.acquire().await.unwrap().forget();
            Ok(self.provider.refreshed.clone())
        })
    }
    fn refresh(&self, _context: ExternalAuthRefreshContext) -> ExternalAuthFuture<'_, CodexAuth> {
        self.resolve()
    }
}

#[tokio::test]
async fn ephemeral_reload_rejects_raw_equal_save_during_external_resolution() {
    for guarded in [false, true] {
        let deadline = Instant::now() + Duration::from_secs(/*secs*/ 5);
        tokio::time::timeout_at(deadline, async {
            let home = tempfile::tempdir().unwrap();
            let manager = manager(&home);
            let initial = auth("initial.e30.signature");
            let provider = Arc::new(ReloadProvider {
                provider: Provider {
                    initial: initial.clone(), refreshed: auth("candidate.e30.signature"),
                    held: HeldCall::Resolve, entered: Notify::new(),
                    release: Semaphore::new(/*permits*/ 0),
                },
                calls: std::sync::atomic::AtomicUsize::new(/*v*/ 0),
            });
            manager.set_external_auth(provider.clone()).await.unwrap();
            let before = observed(&manager, &home);
            let changes = manager.auth_change_state_receiver();
            let generation = *changes.borrow();
            let request = async {
                if guarded {
                    assert!(matches!(manager.reload_if_account_id_matches(Some("account-a")).await,
                        super::ReloadOutcome::Skipped));
                } else { assert!(!manager.reload().await); }
            };
            let alter = async {
                provider.provider.entered.notified().await;
                save_auth(home.path(), before.0.as_ref().unwrap(), AuthCredentialsStoreMode::Ephemeral,
                    AuthKeyringBackendKind::default()).unwrap();
                provider.provider.release.add_permits(/*n*/ 1);
            };
            tokio::join!(request, alter);
            assert_eq!(observed(&manager, &home), before);
            assert_eq!(*changes.borrow(), generation);
            assert_eq!(manager.refresh_failure_for_auth(&initial), None);
            assert!(manager.logout().await.unwrap());
        }).await.unwrap();
    }
}

#[tokio::test]
async fn ephemeral_same_home_peer_install_fences_an_old_manager_refresh() {
    let deadline = Instant::now() + Duration::from_secs(/*secs*/ 5);
    tokio::time::timeout_at(deadline, async {
        let home = tempfile::tempdir().unwrap();
        let first = manager(&home);
        let peer = manager(&home);
        let initial = auth("initial.e30.signature");
        let old = provider(&initial, &auth("stale.e30.signature"), HeldCall::Refresh);
        first.set_external_auth(old.clone()).await.unwrap();
        let owner = first.inner.read().unwrap().source_revision.clone();
        let changes = first.auth_change_state_receiver();
        let generation = *changes.borrow();
        let alter = async {
            old.entered.notified().await;
            peer.set_external_auth(provider(&initial, &initial, HeldCall::Refresh)).await.unwrap();
            old.release.add_permits(/*n*/ 1);
        };
        let (result, ()) = tokio::join!(first.refresh_token_from_authority(), alter);
        assert!(result.is_err());
        assert_eq!(first.inner.read().unwrap().source_revision, owner);
        assert_eq!(*changes.borrow(), generation);
        let expected = initial.get_current_auth_json();
        assert_eq!(observed(&first, &home), (expected.clone(), expected.clone()));
        assert_eq!(observed(&peer, &home), (expected.clone(), expected));
        assert!(peer.logout().await.unwrap());
        assert!(!first.logout().await.unwrap());
    }).await.unwrap();
}

#[tokio::test]
async fn ephemeral_logout_reports_persistent_cleanup_failure_after_local_revocation() {
    let home = tempfile::tempdir().unwrap();
    let mut manager = manager(&home);
    Arc::get_mut(&mut manager).unwrap().auth_credentials_store_mode = AuthCredentialsStoreMode::File;
    let initial = auth("initial.e30.signature");
    manager.set_external_auth(provider(&initial, &initial, HeldCall::Refresh)).await.unwrap();
    let source = manager.inner.read().unwrap().source_revision.clone();
    // Actual File cleanup fails: the auth.json path is a directory, not a removable auth file.
    std::fs::create_dir(home.path().join("auth.json")).unwrap();
    assert!(manager.logout().await.is_err());
    assert_eq!(observed(&manager, &home), (None, None));
    assert!(!manager.has_external_auth());
    assert_ne!(manager.inner.read().unwrap().source_revision, source);
    assert!(home.path().join("auth.json").is_dir());
}
