//! Conditional process-local source/cache/storage publication. Persistent stores remain legacy.
use super::AuthDotJson;
use super::AuthManager;
use super::AuthPolicySnapshot;
use super::CachedAuth;
use super::ChatgptAuth;
use super::ChatgptAuthState;
use super::CodexAuth;
use super::auth_reload::AuthLoadError;
use super::auth_reload::AuthLoadUpdate;
use super::auth_reload::CacheChange;
use super::auth_reload::CachePolicy;
use super::auth_source::AuthOwnerUpdate;
use crate::auth::storage::EphemeralAuthStorage;
use crate::auth::storage::EphemeralMutation;
use crate::auth::storage::EphemeralSnapshot;
use crate::auth::storage::PreparedEphemeralMutation;
use std::fmt;
use std::sync::Arc;
use std::sync::Mutex;

pub(super) enum PublicationKind {
    Credentials,
    NativeRecord,
}

/// Prepared without manager/policy locks. The map guard is acquired last by the owner commit.
pub(super) struct EphemeralPublication {
    pub(super) storage: EphemeralAuthStorage,
    pub(super) prepared: PreparedEphemeralMutation,
    pub(super) state: Option<Arc<Mutex<Option<AuthDotJson>>>>,
    pub(super) kind: PublicationKind,
}
impl fmt::Debug for EphemeralPublication {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("EphemeralPublication(..)")
    }
}

pub(super) struct EphemeralAuthority {
    pub(super) owner: CachedAuth,
    pub(super) policy: AuthPolicySnapshot,
    pub(super) snapshot: EphemeralSnapshot,
    pub(super) storage: EphemeralAuthStorage,
    state: Option<Arc<Mutex<Option<AuthDotJson>>>>,
    pub(super) base: Option<AuthDotJson>,
}
impl EphemeralAuthority {
    pub(super) fn publication(
        &self,
        mutation: EphemeralMutation,
        kind: PublicationKind,
    ) -> Result<EphemeralPublication, AuthLoadError> {
        Ok(EphemeralPublication {
            storage: self.storage.clone(),
            prepared: self.storage.prepare(&self.snapshot.ticket, mutation)
                .map_err(AuthLoadError::Storage)?,
            state: self.state.clone(),
            kind,
        })
    }

    pub(super) fn native_auth(&self, original: &ChatgptAuth) -> Result<CodexAuth, AuthLoadError> {
        let auth = self.base.clone().ok_or(AuthLoadError::CredentialsChanged)?;
        Ok(self.native_with_json(original, auth))
    }

    pub(super) fn native_with_json(&self, original: &ChatgptAuth, auth: AuthDotJson) -> CodexAuth {
        CodexAuth::Chatgpt(ChatgptAuth {
            state: ChatgptAuthState {
                auth_dot_json: Arc::new(Mutex::new(Some(auth))),
                client: original.state.client.clone(),
            },
            storage: Arc::clone(&original.storage),
        })
    }
}

pub(super) fn state_matches(
    expected: &Option<Arc<Mutex<Option<AuthDotJson>>>>,
    auth: Option<&CodexAuth>,
) -> bool {
    match expected {
        None => true,
        Some(expected) => matches!(auth, Some(CodexAuth::Chatgpt(auth))
            if Arc::ptr_eq(expected, &auth.state.auth_dot_json)),
    }
}

impl AuthManager {
    pub(super) fn capture_ephemeral(
        &self,
        expected: &CachedAuth,
        storage: EphemeralAuthStorage,
        native: Option<&ChatgptAuth>,
    ) -> Result<EphemeralAuthority, AuthLoadError> {
        let policy = self.auth_policy_snapshot().map_err(AuthLoadError::Policy)?;
        let snapshot = storage.snapshot().map_err(AuthLoadError::Storage)?;
        let state = native.map(|auth| Arc::clone(&auth.state.auth_dot_json));
        let state_value = match &state {
            Some(state) => state.lock().map_err(|_| AuthLoadError::CacheUnavailable)?.clone(),
            None => None,
        };
        if native.is_some() && snapshot.value.is_some() && snapshot.value != state_value {
            return Err(AuthLoadError::CredentialsChanged);
        }
        let base = snapshot.value.clone().or(state_value);
        let prepared = storage.prepare(&snapshot.ticket, EphemeralMutation::Check)
            .map_err(AuthLoadError::Storage)?;
        let cached = self.inner.read().map_err(|_| AuthLoadError::CacheUnavailable)?;
        if cached.source_revision != expected.source_revision {
            return Err(AuthLoadError::SourceChanged);
        }
        if cached.revision != expected.revision || !state_matches(&state, cached.auth.as_ref()) {
            return Err(AuthLoadError::CredentialsChanged);
        }
        let policy_guard = self.workspace_policy.lock_current(&policy.stamp())
            .map_err(AuthLoadError::Policy)?;
        let storage_guard = storage.lock_prepared(prepared).map_err(AuthLoadError::Storage)?;
        drop(storage_guard);
        drop(policy_guard);
        drop(cached);
        Ok(EphemeralAuthority { owner: expected.clone(), policy, snapshot, storage, state, base })
    }

    pub(super) fn publish_ephemeral(
        &self,
        authority: &EphemeralAuthority,
        auth: CodexAuth,
        mutation: EphemeralMutation,
        kind: PublicationKind,
    ) -> Result<CacheChange, AuthLoadError> {
        super::validate_auth_restrictions(
            Some(authority.policy.allowed_login_methods()), authority.policy.effective_chatgpt_workspaces(), &auth,
        ).map_err(|error| AuthLoadError::Source(std::io::Error::other(error)))?;
        let publication = authority.publication(mutation, kind)?;
        self.replace_auth_owner_with_ephemeral(
            AuthOwnerUpdate::Cache(AuthLoadUpdate::Replace(Some(auth))),
            CachePolicy::Captured {
                policy: &authority.policy.stamp(),
                revision: &authority.owner.revision,
                source: &authority.owner.source_revision,
            },
            Some(publication),
        )
    }
}


pub(super) struct DerivedIdentity {
    pub(super) auth: super::AgentIdentityAuth,
    pub(super) record: Option<super::AgentIdentityAuthRecord>,
}

impl AuthManager {
    pub(super) fn check_ephemeral_authority(&self, authority: &EphemeralAuthority) -> Result<CacheChange, AuthLoadError> {
        self.replace_auth_owner_with_ephemeral(
            AuthOwnerUpdate::Cache(AuthLoadUpdate::Preserve { attempted: None, failure: None }),
            CachePolicy::Captured { policy: &authority.policy.stamp(), revision: &authority.owner.revision, source: &authority.owner.source_revision },
            Some(authority.publication(EphemeralMutation::Check, PublicationKind::Credentials)?),
        )
    }

    pub(super) fn commit_ephemeral_identity(
        &self,
        authority: &EphemeralAuthority,
        original: &ChatgptAuth,
        derived: DerivedIdentity,
    ) -> std::io::Result<super::AgentIdentityAuth> {
        if let Some(record) = derived.record {
            let mut base = authority.base.clone().ok_or_else(|| std::io::Error::other(AuthLoadError::CredentialsChanged))?;
            base.agent_identity = Some(super::AgentIdentityStorage::Record(record));
            let auth = authority.native_with_json(original, base.clone());
            self.publish_ephemeral(authority, auth, EphemeralMutation::Replace(base), PublicationKind::NativeRecord)
                .map_err(std::io::Error::other)?;
        } else {
            self.check_ephemeral_authority(authority).map_err(std::io::Error::other)?;
        }
        Ok(derived.auth)
    }
}


pub(super) struct LogoutAuthority {
    owner: CachedAuth,
    storage: EphemeralAuthStorage,
    snapshot: EphemeralSnapshot,
}

impl AuthManager {
    pub(super) fn capture_logout(&self) -> Result<LogoutAuthority, AuthLoadError> {
        let owner = self.inner.read().map_err(|_| AuthLoadError::CacheUnavailable)?.clone();
        let storage = EphemeralAuthStorage::new(self.codex_home.clone());
        let snapshot = storage.snapshot().map_err(AuthLoadError::Storage)?;
        let prepared = storage.prepare(&snapshot.ticket, EphemeralMutation::Check).map_err(AuthLoadError::Storage)?;
        let current = self.inner.read().map_err(|_| AuthLoadError::CacheUnavailable)?;
        if current.source_revision != owner.source_revision { return Err(AuthLoadError::SourceChanged); }
        if current.revision != owner.revision { return Err(AuthLoadError::CredentialsChanged); }
        let guard = storage.lock_prepared(prepared).map_err(AuthLoadError::Storage)?;
        drop(guard);
        drop(current);
        Ok(LogoutAuthority { owner, storage, snapshot })
    }

    pub(super) fn commit_logout(&self, authority: LogoutAuthority) -> Result<CacheChange, AuthLoadError> {
        let publication = EphemeralPublication {
            prepared: authority.storage.prepare(&authority.snapshot.ticket, EphemeralMutation::Delete).map_err(AuthLoadError::Storage)?,
            storage: authority.storage,
            state: None,
            kind: PublicationKind::Credentials,
        };
        self.replace_auth_owner_with_ephemeral(AuthOwnerUpdate::Logout,
            CachePolicy::LogoutCaptured { revision: &authority.owner.revision, source: &authority.owner.source_revision },
            Some(publication))
    }

    pub(super) async fn reload_after_logout(&self, committed: &CacheChange) {
        let matches = self.inner.read().is_ok_and(|current|
            current.revision == committed.revision && current.source_revision == committed.source);
        if !matches { return; }
        if let Ok(loaded) = self.load_auth().await
            && loaded.revision == committed.revision && loaded.source == committed.source
        {
            let _ = self.commit_auth_load(loaded);
        }
    }
}

impl LogoutAuthority {
    pub(super) fn record(&self) -> Option<AuthDotJson> {
        self.owner.auth.as_ref().and_then(CodexAuth::get_current_auth_json)
    }
}

pub(super) fn removed(outcome: Option<crate::auth::storage::EphemeralOutcome>) -> std::io::Result<bool> {
    match outcome {
        Some(crate::auth::storage::EphemeralOutcome::Deleted { removed }) => Ok(removed),
        Some(crate::auth::storage::EphemeralOutcome::Checked | crate::auth::storage::EphemeralOutcome::Replaced) | None =>
            Err(std::io::Error::other("ephemeral logout did not settle deletion")),
    }
}

/// Standalone native auth has no manager owner to publish into. Its own state and actual
/// Ephemeral backend still require a pre-derivation ticket; this is not manager authorization.
pub(super) struct StandaloneIdentity {
    storage: EphemeralAuthStorage,
    snapshot: EphemeralSnapshot,
    state: Arc<Mutex<Option<AuthDotJson>>>,
    previous: Option<AuthDotJson>,
    base: AuthDotJson,
}
impl StandaloneIdentity {
    pub(super) fn capture(auth: &ChatgptAuth, storage: EphemeralAuthStorage) -> std::io::Result<(Self, CodexAuth)> {
        let snapshot = storage.snapshot().map_err(std::io::Error::other)?;
        let previous = auth.state.auth_dot_json.lock().map_err(|_| std::io::Error::other(AuthLoadError::CacheUnavailable))?.clone();
        if snapshot.value.is_some() && snapshot.value != previous {
            return Err(std::io::Error::other(AuthLoadError::CredentialsChanged));
        }
        // Preserve native identity's existing absent-store fallback using the captured state.
        let base = snapshot.value.clone().or_else(|| previous.clone())
            .ok_or_else(|| std::io::Error::other("auth data is not available"))?;
        let frozen = CodexAuth::Chatgpt(ChatgptAuth {
            state: ChatgptAuthState { auth_dot_json: Arc::new(Mutex::new(Some(base.clone()))), client: auth.state.client.clone() },
            storage: Arc::clone(&auth.storage),
        });
        Ok((Self { storage, snapshot, state: Arc::clone(&auth.state.auth_dot_json), previous, base }, frozen))
    }

    pub(super) fn publish(self, record: Option<super::AgentIdentityAuthRecord>) -> std::io::Result<()> {
        let (mutation, next) = match record {
            Some(record) => {
                let mut next = self.base;
                next.agent_identity = Some(super::AgentIdentityStorage::Record(record));
                (EphemeralMutation::Replace(next.clone()), Some(next))
            }
            None => (EphemeralMutation::Check, None),
        };
        let prepared = self.storage.prepare(&self.snapshot.ticket, mutation).map_err(std::io::Error::other)?;
        let mut state = self.state.lock().map_err(|_| std::io::Error::other(AuthLoadError::CacheUnavailable))?;
        if *state != self.previous { return Err(std::io::Error::other(AuthLoadError::CredentialsChanged)); }
        let map = self.storage.lock_prepared(prepared).map_err(std::io::Error::other)?;
        let retired = next.map(|next| std::mem::replace(&mut *state, Some(next)));
        map.commit();
        drop(state);
        drop(retired);
        Ok(())
    }
}
