//! Process-local credential revisions for the complete conditional caller cohort.
use super::AuthDotJson;
use super::AuthStorageBackend;
use super::compute_store_key;
use once_cell::sync::Lazy;
use std::collections::HashMap;
use std::fmt;
use std::path::PathBuf;
use std::sync::Arc;
use std::sync::Mutex;
use std::sync::MutexGuard;

// Bound absent-domain tracking independently of existing credential retention. Admission scans
// at most this many entries; raw load/save/delete never depend on available ticket capacity.
const ABSENT_TICKET_LIMIT: usize = 4096;
static STORE: Lazy<Arc<Mutex<State>>> = Lazy::new(|| Arc::new(Mutex::new(State::default())));

struct Revision;
struct Entry {
    revision: Arc<Revision>,
    value: Arc<AuthDotJson>,
}
#[derive(Default)]
struct State {
    present: HashMap<String, Entry>,
    absent: HashMap<String, Arc<Revision>>,
}

/// Opaque retained identity: equality of values or a later re-created absence is not authority.
#[derive(Clone)]
pub(in crate::auth) struct EphemeralTicket {
    key: String,
    revision: Arc<Revision>,
}

pub(in crate::auth) struct EphemeralSnapshot {
    pub(in crate::auth) ticket: EphemeralTicket,
    pub(in crate::auth) value: Option<AuthDotJson>,
}

pub(in crate::auth) enum EphemeralMutation {
    Check,
    Replace(AuthDotJson),
    Delete,
}

#[derive(Debug, PartialEq, Eq)]
pub(in crate::auth) enum EphemeralOutcome {
    Checked,
    Replaced,
    Deleted { removed: bool },
}

#[derive(Debug, thiserror::Error, PartialEq, Eq)]
pub(in crate::auth) enum EphemeralError {
    #[error("ephemeral auth domain is unavailable")]
    DomainUnavailable,
    #[error("ephemeral auth domain changed")]
    DomainChanged,
    #[error("ephemeral auth revision changed")]
    StaleRevision,
    #[error("failed to lock ephemeral auth storage")]
    StoreUnavailable,
    #[error("ephemeral auth absence ticket capacity exhausted")]
    CapacityExceeded,
    #[error("ephemeral auth storage allocation failed")]
    AllocationFailed,
}

/// Prepared outside owner/policy guards; it performs no filesystem work when locked.
pub(in crate::auth) struct PreparedEphemeralMutation {
    home: PathBuf,
    ticket: EphemeralTicket,
    operation: PreparedOperation,
    revision: Arc<Revision>,
}

enum PreparedOperation {
    Check,
    Replace(Arc<AuthDotJson>),
    Delete,
}

/// A checked map reservation, intended for manager -> policy -> map commit order.
/// After creation, commit is infallible; no callbacks or await are accepted. Future callers
/// must perform only owned cache swaps before commit, and never drop trait-backed auth here.
pub(in crate::auth) struct EphemeralCommit<'a> {
    state: MutexGuard<'a, State>,
    prepared: PreparedEphemeralMutation,
}

impl EphemeralCommit<'_> {
    pub(in crate::auth) fn commit(self) -> EphemeralOutcome {
        let Self { mut state, prepared } = self;
        let (outcome, retired_value, retired_ticket) = match prepared.operation {
            PreparedOperation::Check => (EphemeralOutcome::Checked, None, None),
            PreparedOperation::Replace(value) =>
                state.apply(prepared.ticket.key, Some(value), prepared.revision),
            PreparedOperation::Delete =>
                state.apply(prepared.ticket.key, None, prepared.revision),
        };
        drop(state);
        drop((retired_value, retired_ticket));
        outcome
    }
}

impl State {
    fn apply(
        &mut self,
        key: String,
        value: Option<Arc<AuthDotJson>>,
        revision: Arc<Revision>,
    ) -> (EphemeralOutcome, Option<Entry>, Option<Arc<Revision>>) {
        let retired_ticket = self.absent.remove(&key);
        let (outcome, retired_value) = match value {
            Some(value) => (
                EphemeralOutcome::Replaced,
                self.present.insert(key, Entry { revision, value }),
            ),
            None => {
                let retired = self.present.remove(&key);
                (EphemeralOutcome::Deleted { removed: retired.is_some() }, retired)
            }
        };
        (outcome, retired_value, retired_ticket)
    }
}

#[derive(Clone)]
pub(in crate::auth) struct EphemeralAuthStorage {
    codex_home: PathBuf,
    store: Arc<Mutex<State>>,
}

impl fmt::Debug for EphemeralAuthStorage {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("EphemeralAuthStorage")
            .field("codex_home", &self.codex_home)
            .finish_non_exhaustive()
    }
}

impl EphemeralAuthStorage {
    pub(in crate::auth) fn new(codex_home: PathBuf) -> Self {
        Self { codex_home, store: Arc::clone(&STORE) }
    }

    pub(in crate::auth) fn snapshot(&self) -> Result<EphemeralSnapshot, EphemeralError> {
        let key = compute_store_key(&self.codex_home).map_err(|_| EphemeralError::DomainUnavailable)?;
        let next_revision = Arc::new(Revision);
        // Declared before the guard so an early return also releases the map before retirement.
        let mut retired_ticket = None;
        let mut state = self.store.lock().map_err(|_| EphemeralError::StoreUnavailable)?;
        let (revision, value) = if let Some(entry) = state.present.get(&key) {
            (Arc::clone(&entry.revision), Some(Arc::clone(&entry.value)))
        } else if let Some(revision) = state.absent.get(&key) {
            (Arc::clone(revision), None)
        } else {
            if state.absent.len() >= ABSENT_TICKET_LIMIT {
                let reclaim = state.absent.iter()
                    .find(|(_, revision)| Arc::strong_count(revision) == 1)
                    .map(|(key, _)| key.clone())
                    .ok_or(EphemeralError::CapacityExceeded)?;
                retired_ticket = state.absent.remove(&reclaim);
            }
            state.absent.try_reserve(1).map_err(|_| EphemeralError::AllocationFailed)?;
            state.absent.insert(key.clone(), Arc::clone(&next_revision));
            (next_revision, None)
        };
        drop(state);
        drop(retired_ticket);
        Ok(EphemeralSnapshot {
            ticket: EphemeralTicket { key, revision },
            value: value.as_deref().cloned(),
        })
    }

    pub(in crate::auth) fn prepare(
        &self,
        ticket: &EphemeralTicket,
        mutation: EphemeralMutation,
    ) -> Result<PreparedEphemeralMutation, EphemeralError> {
        let key = compute_store_key(&self.codex_home).map_err(|_| EphemeralError::DomainUnavailable)?;
        if key != ticket.key {
            return Err(EphemeralError::DomainChanged);
        }
        let operation = match mutation {
            EphemeralMutation::Check => PreparedOperation::Check,
            EphemeralMutation::Replace(value) => PreparedOperation::Replace(Arc::new(value)),
            EphemeralMutation::Delete => PreparedOperation::Delete,
        };
        Ok(PreparedEphemeralMutation {
            home: self.codex_home.clone(),
            ticket: ticket.clone(),
            operation,
            revision: Arc::new(Revision),
        })
    }

    pub(in crate::auth) fn lock_prepared(
        &self,
        prepared: PreparedEphemeralMutation,
    ) -> Result<EphemeralCommit<'_>, EphemeralError> {
        if prepared.home != self.codex_home {
            return Err(EphemeralError::DomainChanged);
        }
        let mut state = self.store.lock().map_err(|_| EphemeralError::StoreUnavailable)?;
        let current = state.present.get(&prepared.ticket.key).map(|entry| &entry.revision)
            .or_else(|| state.absent.get(&prepared.ticket.key));
        if !current.is_some_and(|revision| Arc::ptr_eq(revision, &prepared.ticket.revision)) {
            return Err(EphemeralError::StaleRevision);
        }
        if matches!(prepared.operation, PreparedOperation::Replace(_)) {
            state.present.try_reserve(1).map_err(|_| EphemeralError::AllocationFailed)?;
        }
        Ok(EphemeralCommit { state, prepared })
    }
}

impl AuthStorageBackend for EphemeralAuthStorage {
    fn ephemeral_storage(&self) -> Option<EphemeralAuthStorage> {
        Some(self.clone())
    }

    fn load(&self) -> std::io::Result<Option<AuthDotJson>> {
        let key = compute_store_key(&self.codex_home)?;
        let state = self.store.lock().map_err(|_| std::io::Error::other(EphemeralError::StoreUnavailable))?;
        let value = state.present.get(&key).map(|entry| Arc::clone(&entry.value));
        drop(state);
        Ok(value.as_deref().cloned())
    }

    fn save(&self, auth: &AuthDotJson) -> std::io::Result<()> {
        let key = compute_store_key(&self.codex_home)?;
        let value = Arc::new(auth.clone());
        let revision = Arc::new(Revision);
        let mut state = self.store.lock().map_err(|_| std::io::Error::other(EphemeralError::StoreUnavailable))?;
        state.present.reserve(1);
        let (_, retired_value, retired_ticket) = state.apply(key, Some(value), revision);
        drop(state);
        drop((retired_value, retired_ticket));
        Ok(())
    }

    fn delete(&self) -> std::io::Result<bool> {
        let key = compute_store_key(&self.codex_home)?;
        let mut state = self.store.lock().map_err(|_| std::io::Error::other(EphemeralError::StoreUnavailable))?;
        // Removing an absent ticket invalidates it too. No tombstone or admission is needed.
        let retired_value = state.present.remove(&key);
        let retired_ticket = state.absent.remove(&key);
        let removed = retired_value.is_some();
        drop(state);
        drop((retired_value, retired_ticket));
        Ok(removed)
    }
}

#[cfg(test)]
#[path = "ephemeral_storage_tests.rs"]
mod tests;
