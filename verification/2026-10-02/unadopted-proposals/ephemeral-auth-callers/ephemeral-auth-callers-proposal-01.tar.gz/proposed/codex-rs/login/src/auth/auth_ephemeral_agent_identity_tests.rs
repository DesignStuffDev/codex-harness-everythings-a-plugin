//! Unrun manager-child proposal; adopt only with the complete Ephemeral caller B slice.
//! Task-registration payload follows auth_tests::chatgpt_auth_task_registration_retry_exhaustion_is_fallback_eligible.
use super::AgentIdentityAuthPolicy;
use super::AuthManager;
use super::CodexAuth;
use super::load_auth_dot_json;
use super::logout;
use super::save_auth;
use crate::auth::storage::AgentIdentityAuthRecord;
use crate::auth::storage::AgentIdentityStorage;
use crate::auth::storage::AuthDotJson;
use crate::token_data::IdTokenInfo;
use crate::token_data::TokenData;
use anyhow::Context;
use anyhow::ensure;
use chrono::Utc;
use codex_config::types::AuthCredentialsStoreMode;
use codex_config::types::AuthKeyringBackendKind;
use codex_protocol::account::PlanType;
use codex_protocol::auth::AuthMode;
use codex_protocol::protocol::SessionSource;
use pretty_assertions::assert_eq;
use std::sync::Arc;
use std::time::Duration;
use tempfile::TempDir;
use tokio::io::AsyncReadExt;
use tokio::io::AsyncWriteExt;
use tokio::net::TcpListener;
use tokio::sync::oneshot;
use tokio::time::Instant;

#[derive(Clone, Copy)]
enum OwnerChange {
    Unchanged,
    EqualReload,
    Logout,
}
fn observed(manager: &AuthManager, home: &TempDir) -> anyhow::Result<(Option<AuthDotJson>, Option<AuthDotJson>)> {
    Ok((
        load_auth_dot_json(home.path(), AuthCredentialsStoreMode::Ephemeral,
            AuthKeyringBackendKind::default())?,
        manager.auth_cached().as_ref().and_then(CodexAuth::get_current_auth_json),
    ))
}

#[tokio::test]
async fn ephemeral_agent_identity_public_caller_checks_state_and_preserves_issued_snapshots() -> anyhow::Result<()> {
    for change in [OwnerChange::Unchanged, OwnerChange::EqualReload, OwnerChange::Logout] {
        let deadline = Instant::now() + Duration::from_secs(/*secs*/ 5);
        tokio::time::timeout_at(deadline, async {
            let home = tempfile::tempdir()?;
            let listener = TcpListener::bind("127.0.0.1:0").await?;
            let endpoint = format!("http://{}", listener.local_addr()?);
            let key = codex_agent_identity::generate_agent_key_material()
                .map_err(std::io::Error::other)?;
            let initial = AuthDotJson {
                auth_mode: Some(AuthMode::Chatgpt),
                openai_api_key: None,
                tokens: Some(TokenData {
                    id_token: IdTokenInfo {
                        chatgpt_user_id: Some("user-a".to_string()),
                        chatgpt_account_id: Some("account-a".to_string()),
                        ..Default::default()
                    },
                    access_token: "test-access-token".to_string(),
                    refresh_token: "test-refresh-token".to_string(),
                    account_id: Some("account-a".to_string()),
                }),
                last_refresh: Some(Utc::now()),
                agent_identity: Some(AgentIdentityStorage::Record(AgentIdentityAuthRecord {
                    agent_runtime_id: "agent-runtime".to_string(),
                    agent_private_key: key.private_key_pkcs8_base64,
                    account_id: "account-a".to_string(),
                    chatgpt_user_id: "user-a".to_string(),
                    email: None,
                    plan_type: PlanType::Unknown,
                    chatgpt_account_is_fedramp: false,
                    task_id: None,
                })),
                personal_access_token: None,
                bedrock_api_key: None,
                bedrock_access_keys: None,
            };
            save_auth(home.path(), &initial, AuthCredentialsStoreMode::Ephemeral,
                AuthKeyringBackendKind::default())?;
            let route = crate::test_support::transport_default_auth_route_config();
            let auth = CodexAuth::from_auth_dot_json(
                home.path(), initial.clone(), AuthCredentialsStoreMode::Ephemeral,
                /*chatgpt_base_url*/ None, AuthKeyringBackendKind::default(),
                /*agent_identity_authapi_base_url*/ None, &route,
            ).await?;
            let mut manager = AuthManager::from_auth_for_testing_with_agent_identity_authapi_base_url(auth, endpoint);
            let unique = Arc::get_mut(&mut manager).unwrap();
            unique.codex_home = home.path().to_path_buf();
            unique.auth_credentials_store_mode = AuthCredentialsStoreMode::Ephemeral;
            let issued = manager.auth_cached().context("initial cached auth")?;
            let revision = manager.inner.read().unwrap().revision.clone();
            let changes = manager.auth_change_state_receiver();
            let (entered_tx, entered_rx) = oneshot::channel();
            let (release_tx, release_rx) = oneshot::channel();

            // Own this finite server inline: no spawned task, held blocking worker, or sleep.
            let server = async move {
                let (mut stream, _) = listener.accept().await?;
                let mut headers = Vec::new();
                while !headers.ends_with(b"\r\n\r\n") {
                    ensure!(headers.len() < 8192, "fixture request headers exceeded bound");
                    headers.push(stream.read_u8().await?);
                }
                let headers = std::str::from_utf8(&headers)?;
                assert_eq!(headers.lines().next(), Some("POST /v1/agent/agent-runtime/task/register HTTP/1.1"));
                let length = headers.lines().filter_map(|line| line.split_once(':'))
                    .find(|(name, _)| name.eq_ignore_ascii_case("content-length"))
                    .context("task request content length")?.1.trim().parse::<usize>()?;
                ensure!(length <= 65536, "fixture task request exceeded bound");
                let mut body = vec![0; length];
                stream.read_exact(&mut body).await?;
                let _: serde_json::Value = serde_json::from_slice(&body)?;
                entered_tx.send(()).map_err(|_| anyhow::anyhow!("request observer dropped"))?;
                release_rx.await?;
                let body = r#"{"task_id":"task-complete"}"#;
                let response = format!(
                    "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{body}", body.len(),
                );
                stream.write_all(response.as_bytes()).await?;
                stream.shutdown().await?;
                Ok::<(), anyhow::Error>(())
            };
            let scenario = async {
                let alter = async {
                    entered_rx.await?;
                    match change {
                        OwnerChange::Unchanged => {}
                        OwnerChange::EqualReload => {
                            assert!(!manager.reload().await);
                            let current = manager.auth_cached().context("reloaded auth")?;
                            let (CodexAuth::Chatgpt(old), CodexAuth::Chatgpt(new)) = (&issued, &current) else {
                                anyhow::bail!("fixture expected native ChatGPT auth");
                            };
                            assert!(!Arc::ptr_eq(&old.state.auth_dot_json, &new.state.auth_dot_json));
                            assert_eq!(current.get_current_auth_json(), Some(initial.clone()));
                            assert_eq!(manager.inner.read().unwrap().revision, revision);
                        }
                        OwnerChange::Logout => {
                            assert!(manager.logout().await?);
                            assert_eq!(observed(&manager, &home)?, (None, None));
                        }
                    }
                    let published = (observed(&manager, &home)?, *changes.borrow());
                    release_tx.send(()).map_err(|_| anyhow::anyhow!("held response dropped"))?;
                    Ok::<_, anyhow::Error>(published)
                };
                let (result, published) = tokio::join!(
                    manager.agent_identity_auth(AgentIdentityAuthPolicy::ChatGptAuth, SessionSource::Cli),
                    alter,
                );
                let published = published?;
                match change {
                    OwnerChange::Unchanged => {
                        let registered = result?.context("registered task")?;
                        assert_eq!(registered.record().task_id.as_deref(), Some("task-complete"));
                        let mut expected = initial.clone();
                        expected.agent_identity = Some(AgentIdentityStorage::Record(registered.record().clone()));
                        assert_eq!(observed(&manager, &home)?, (Some(expected.clone()), Some(expected)));
                    }
                    OwnerChange::EqualReload | OwnerChange::Logout => {
                        assert!(result.is_err());
                        assert_eq!((observed(&manager, &home)?, *changes.borrow()), published);
                    }
                }
                // Successful publication replaces cached state; previously issued clones stay snapshots.
                assert_eq!(issued.get_current_auth_json(), Some(initial.clone()));
                logout(home.path(), AuthCredentialsStoreMode::Ephemeral,
                    AuthKeyringBackendKind::default())?;
                Ok::<(), anyhow::Error>(())
            };
            tokio::try_join!(server, scenario)?;
            Ok::<(), anyhow::Error>(())
        }).await??;
    }
    Ok(())
}
