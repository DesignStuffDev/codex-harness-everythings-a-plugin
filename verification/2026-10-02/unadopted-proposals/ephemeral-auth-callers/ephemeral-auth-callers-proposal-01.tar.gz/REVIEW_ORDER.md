# Review and adoption order

First inspect frozen primitive A, then review B’s five units in numeric order. Each unit is a review partition, not a standalone build/activation state. A may be tested separately as an unactivated primitive checkpoint, but no source/cache/storage guarantee exists until the complete caller set is adopted and tested. Do not add broad unused-API allowances to make partial activation look complete.

1. Backend capability and Check mode, including its focused primitive regression.
2. Conditional owner/publication helpers and installation source integration.
3. Actual manager caller wiring, request derivation/persistence split and logout/reload lifecycle.
4. Public external-provider race tests and mixed-store error behavior.
5. Native identity and native HTTP integration tests, plus discovery declaration.

The full B production change is larger than a single preferred small patch because it must close all participating writers before activation. Every new production module remains under 500 lines. The existing large manager retains its public orchestration signatures; new publication custody lives in auth_ephemeral.rs. Review units keep ordinary review size bounded without pretending partial cohort activation is sound.

Apply SOURCE.patch only after the exact prerequisite A plus current42 preimages match PATCH_INPUTS.json; alternatively use COMPLETE_FROM_CURRENT42.patch on exact current42. No fuzz, source overwrite or automatic acceptance. Root must revalidate all hashes after any intervening formatting/lint change; a changed preimage requires an explicit mechanical rebase. New .rs discovery uses existing source globs/module declarations and requires no include_str or new dependency.
