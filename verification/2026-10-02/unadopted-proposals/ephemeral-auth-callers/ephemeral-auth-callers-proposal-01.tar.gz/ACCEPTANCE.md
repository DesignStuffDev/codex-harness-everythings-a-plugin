# Required acceptance — none executed for this proposal

Existing current42 results belong to current42, not A/B. Compilation/lint/source review is not runtime proof. New assertions preserve meaningful existing state, compare whole credential payloads where accessible, and use actual provider or complete loopback HTTP request barriers instead of sleeps.

Proposed additions:

- A: eight primitive tests, retained unchanged except B adds one separate Check regression covering present/absent Check stability and later raw invalidation.
- B external callers: held success on both refresh APIs across equal provider replacement/same-Arc ABA; held install versus raw equal save/absent delete; logout while refresh held; public reload and the production guarded internal reload helper versus raw equal save; two managers on one home with peer install; real File cleanup failure after local logout.
- Native identity: actual held task-registration HTTP, successful publication/fresh acquisition/old clone stability; equal-value native reload supersession; logout supersession. Initial runtime registration still needs a separate held case.
- Native token/revoke integration: both public refresh APIs × unchanged/equal-save/delete-recreate/manager logout (8 cases); standalone/manager revoke versus equal save (2). Existing serialized auth endpoint overrides and transport fixture are reused. Each HTTP case uses a single absolute 5-second setup/request/assertion deadline, bounded request body, inline owned futures/sockets and no detached jobs. No proxy/DNS/CA or sandbox changes.

After full source review/adoption and formatting, root should source-bind a fresh candidate and resource admission. Preserve the current tested baseline and all old proof artifacts first. Use repo `just test` entrypoints, no direct cargo test. Existing grouped CLI+login selections preserve the established feature context; CLI tests excluded by filter are not counted as passing:

1. `just test -p codex-cli -p codex-login --lib -E 'package(codex-login) & test(ephemeral_)'`
2. `just test -p codex-cli -p codex-login --lib -E 'package(codex-login)' --test-threads=1` (retains reload/source/policy/failure and lower identity reuse regressions).
3. `just test -p codex-cli -p codex-login --test all -E 'package(codex-login) & test(ephemeral_http::)' --test-threads=1`
4. `just test -p codex-cli -p codex-login --lib --test all -E 'package(codex-login)' --test-threads=1`
5. Scoped `just fix -p codex-login`, required formatting and exact post-source accounting per repository workflow. No complete workspace suite is authorized by this proposal; root checks applicable prior user approval before one.

Unimplemented acceptance gaps to close before calling the full boundary accepted: cancellation while responses are held; native permanent/error response versus raw mutation; direct absent native storage rejection; actual async post-logout reload supersession; initial identity runtime registration; domain remapping/poison handling; capacity caller error propagation. Existing primitive capacity tests do not substitute for public caller coverage. The mixed File cleanup and same-home tests above were added after the earlier HTTP review’s gap inventory and are themselves unrun. Existing persistent/agent-identity and provider suites remain required regressions.

Then rebuild the current production host and exercise the installed auth adapter plus ordinary headless and separately installed GUI flows; old host proof cannot establish A/B behavior. Verify native refresh, replacement, logout, cancellation and recovery with exact source/binary binding. In-app Browser availability remains a root/environment concern; Chromium fallback or deterministic fixtures must be labeled. No independently installed component, persistent CAS, full UI, transport shutdown or updater acceptance is claimed here.
