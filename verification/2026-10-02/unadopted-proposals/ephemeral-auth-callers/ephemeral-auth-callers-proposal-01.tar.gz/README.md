# Unadopted Ephemeral caller activation proposal B

Status: source-only proposal. No formatter, compiler, lint, tests, real host, or installed-plugin acceptance has run for A or B. Root owns any future adoption. The active repository was not edited. Source is based on formatted refresh cohort 42e3899a688183ae740926d188204ea1222d24f79db1e4b9cb37d51aa046dc59 plus separately preserved primitive A (manifest 5be1110fb16b54e547f0ed26828fdfd8ac38c2ebb8b34b26c479982fb4c93a2f).

Wording correction for frozen A: its phrase “conditional APIs are compiled private code” was inaccurate. It means **private source proposed for compilation**. A remains byte-for-byte preserved; no prior acceptance is inferred.

`SOURCE.patch` is B relative to current42 + exact A. `COMPLETE_FROM_CURRENT42.patch` is the same final source relative to current42 alone, including A. Choose one path, never apply both. `PATCH_INPUTS.json` records both bases and final source identities. `review-units/` divides B for review; these units are not separately deployable or independently compilable milestones. Review every unit before applying the complete cohort. Partial manager activation is prohibited.

The proposal closes participating process-local Ephemeral storage publication paths. It does not extract/install an auth component, implement persistent CAS, revoke handed-out credentials, close HTTP transports, or claim whole auth completion. Read CONTRACT.md, CALLER_COHORT.md and ACCEPTANCE.md for limits and pending gates.

No dependencies, public wire schemas, UI, credentials, network grants, repository instructions, license files or sandbox handling were changed. All new fixtures use synthetic tokens. These files are recovery artifacts inside this VM; this proposal alone establishes no external backup.
