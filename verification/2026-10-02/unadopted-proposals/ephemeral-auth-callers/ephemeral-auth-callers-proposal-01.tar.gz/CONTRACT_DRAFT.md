# Complete caller activation — draft contract, not an adoption candidate

Base: current42e3899 formatted refresh source plus separately preserved primitive A. No compiler or runtime validation. All review patches must be present before conditional caller activation; partial application is not a strong-write guarantee.

Required refinements discovered at actual callers:

- Detect Ephemeral through the actual ChatgptAuth storage object and ObservedStorage delegation, not configured manager mode. Ephemeral data takes precedence over configured persistent data.
- Add private Check-only reservations to A. They retain and validate a storage ticket without advancing it, supporting cache-only auth and coherent source/policy capture. Existing A remains preserved byte-for-byte.
- Capture native immutable JSON/state identity before request/registration awaits. Agent identity currently captures auth before its bootstrap semaphore; recapture afterward. Both existing-record task registration and new runtime/task registration carry the same authority.
- Equal-credential reload replaces the state Arc without rotating source/cache stamps. Validate exact selected Arc; do not authorize a retained old object from stamps alone. Native identity publication must advance cache revision even if token bytes match.
- Manager reload needs the same Ephemeral witness through its async load; otherwise raw save/delete may be followed by stale cache publication. Returned credentials remain snapshots, not dispatch grants.
- Logout must atomically delete Ephemeral and clear this manager's cache/source/install intent, including no-provider/absent cases. Revoke capture precedes its await; post-logout reload uses the exact successor owner stamp. Persistent cleanup remains explicitly legacy and cannot be done while local owner/policy/map guards are held.

Selected publication behavior under review: derive from immutable JSON and publish a fresh current native cache object together with storage; old handed-out auth clones remain snapshots. This differs from existing in-place agent-record updates and needs explicit compatibility review/tests. Never quietly update an old Arc after current owner replacement.

Unsolved/under-review obligations stay visible until code/tests close them: native record derivation return-vs-persistence split, owner commit preparation without auth-state reentry, full reload witness propagation, mixed-store cleanup errors and post-logout reload, and exact public-caller race tests. No installed component/runtime acceptance is implied by the private capability prerequisite.
