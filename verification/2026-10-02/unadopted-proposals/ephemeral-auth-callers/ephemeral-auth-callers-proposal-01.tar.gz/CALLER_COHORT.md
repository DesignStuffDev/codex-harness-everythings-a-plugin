# Actual writer and reader cohort

| Existing source/symbol | Proposed handling | Limit |
| --- | --- | --- |
| auth_source.rs::install_external_auth / install admission | Pre-provider store ticket; same existing InstallContext; checked source/cache/policy and Replace or Check publication | No install-intent redesign |
| manager.rs::refresh_token / refresh_token_from_authority / refresh_external_auth | Actual selected provider captured before await; conditional successful and permanent-failure publication | Issued network requests are not revoked |
| manager.rs::refresh_and_persist_chatgpt_token | Actual Ephemeral snapshot before request; patch captured JSON, publish fresh cache/store | File/Keyring/Auto path remains legacy |
| manager.rs::load_auth and public reload and its guarded internal caller | Store Check ticket carried through async resolution into LoadedAuth commit | Initial free AuthConfig reads remain snapshots, not dispatch capabilities |
| manager.rs::agent_identity_auth | Recapture after permit; immutable derivation; current-owner conditional native-record commit | Returned AgentIdentityAuth has existing lifetime |
| CodexAuth::ensure_managed_chatgpt_agent_identity | Standalone capture before await; own state/store checked commit | No manager authority; existing same-object reuse retained |
| persist_tokens / persist_agent_identity_record | Explicitly reject unguarded Ephemeral path; persistent behavior retained | No durable-save fencing |
| AuthManager::{logout,logout_with_revoke}, finish_logout | Owner/store capture; local atomic revocation; legacy configured-store cleanup; exact successor reload | Persistent cleanup may fail after local commit |
| free logout_with_revoke / login restriction logout_with_message | Capture before load/revoke await; conditional Ephemeral delete once, then configured-store cleanup | No manager owner exists for these standalone APIs |
| save_auth / logout / login_with_chatgpt_auth_tokens / initial API-key/access-token/browser/device writes | Same public raw behavior through version-advancing Ephemeral backend | A raw new writer may intentionally replace post-logout auth |
| storage_telemetry.rs::ObservedStorage | Capability forwarding reaches the actual backend | Existing raw load/save/delete telemetry retained; conditional operations do not fabricate raw-operation metrics |
| set_cached_auth / record_permanent_refresh_failure_if_unchanged | Existing test-only mutation helpers remain in tests | No production writer bypass found by bounded search |

Original upstream paths/symbols come from openai/codex@d42056091aded7feb1d88ac7e83972108b2aa478. auth_source/auth_reload and exact policy/cache ownership are intentional custom predecessor work, not upstream symbols. The proposed private auth_ephemeral module and Check mode are new custom code. Exact current42 and A byte mappings appear in PATCH_INPUTS.json; this is provenance, not a byte-level upstream merge or installed-family count. Apache-2.0 LICENSE/NOTICE are untouched; no third-party implementation was copied.

Compatibility audit source anchors: model-provider/src/auth.rs::resolve_auth_provider (252), auth_provider_from_auth (307–325), AuthManagerAuthProvider (133–168); provider.rs (313–315,557–565). Token/account reads do not expose identity records. Native lower-helper reuse tests auth_tests.rs (615–647) remain unchanged and required. Test method/API signatures and wire protocol are unchanged; new transient typed failures can surface through existing io/refresh error handling.
