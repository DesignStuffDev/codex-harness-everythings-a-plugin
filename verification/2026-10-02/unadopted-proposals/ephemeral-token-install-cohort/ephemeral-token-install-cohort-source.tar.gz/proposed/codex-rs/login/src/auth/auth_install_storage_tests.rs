use super::*;
use crate::auth::{load_auth_dot_json, logout, save_auth};
use crate::{AuthCredentialsStoreMode, AuthKeyringBackendKind};
use pretty_assertions::assert_eq;

#[derive(Clone, Copy)]
enum Change { Unchanged, EqualSave, DeleteRecreate, AbsentDelete, PeerInstall, Cancel, KeyOnly }

#[tokio::test]
async fn token_install_owns_storage_and_cache_or_publishes_neither() {
    for change in [Change::Unchanged, Change::EqualSave, Change::DeleteRecreate,
        Change::AbsentDelete, Change::PeerInstall, Change::Cancel, Change::KeyOnly] {
        tokio::time::timeout(Duration::from_secs(/*secs*/ 5), async {
            let home = tempfile::tempdir().unwrap();
            let mut manager = AuthManager::from_optional_auth_for_testing(/*auth*/ None);
            Arc::get_mut(&mut manager).unwrap().codex_home = home.path().to_path_buf();
            let mode = AuthCredentialsStoreMode::Ephemeral;
            let kind = AuthKeyringBackendKind::default();
            let initial = CodexAuth::from_external_chatgpt_tokens(
                "initial.e30.signature", "account-a", /*chatgpt_plan_type*/ None,
            ).unwrap().get_current_auth_json().unwrap();
            if !matches!(change, Change::AbsentDelete) {
                save_auth(home.path(), &initial, mode, kind).unwrap();
            }
            let token_auth = CodexAuth::from_external_chatgpt_tokens(
                "candidate.e30.signature", "account-a", /*chatgpt_plan_type*/ None,
            ).unwrap();
            let expected = token_auth.get_current_auth_json();
            let reply = if matches!(change, Change::KeyOnly) { Reply::Key("key") }
                else { Reply::Tokens(token_auth.clone()) };
            let candidate = provider(reply, Timing::Held);
            let mut pending = Box::pin(manager.set_external_auth(candidate.clone()));
            tokio::select! {
                result = &mut pending => panic!("completed before provider release: {result:?}"),
                () = candidate.entered.notified() => {}
            }
            match change {
                Change::EqualSave | Change::KeyOnly => save_auth(home.path(), &initial, mode, kind).unwrap(),
                Change::DeleteRecreate => {
                    assert!(logout(home.path(), mode, kind).unwrap());
                    save_auth(home.path(), &initial, mode, kind).unwrap();
                }
                Change::AbsentDelete => assert!(!logout(home.path(), mode, kind).unwrap()),
                Change::PeerInstall => {
                    let mut peer = AuthManager::from_optional_auth_for_testing(/*auth*/ None);
                    Arc::get_mut(&mut peer).unwrap().codex_home = home.path().to_path_buf();
                    peer.set_external_auth(provider(Reply::Tokens(token_auth.clone()), Timing::Ready)).await.unwrap();
                }
                Change::Unchanged | Change::Cancel => {}
            }
            let stored = load_auth_dot_json(home.path(), mode, kind).unwrap();
            let cached = manager.auth_cached().and_then(|auth| auth.get_current_auth_json());
            let before = {
                let owner = manager.inner.read().unwrap();
                (owner.source_revision.clone(), owner.revision.clone(), *manager.auth_change_state_receiver().borrow())
            };
            if matches!(change, Change::Cancel) {
                drop(pending);
            } else {
                candidate.release.add_permits(/*n*/ 1);
                let result = pending.await;
                if matches!(change, Change::Unchanged | Change::KeyOnly) {
                    result.unwrap();
                    let installed: Arc<dyn ExternalAuth> = candidate.clone();
                    assert!(Arc::ptr_eq(&manager.external_auth_provider().unwrap(), &installed));
                    if matches!(change, Change::Unchanged) {
                        assert_eq!(load_auth_dot_json(home.path(), mode, kind).unwrap(), expected);
                        // The installed payload is independent of a provider's retained snapshot.
                        let CodexAuth::ChatgptAuthTokens(original) = &token_auth else { unreachable!() };
                        *original.state.auth_dot_json.lock().unwrap() = None;
                        assert_eq!(manager.auth_cached().unwrap().get_current_auth_json(), expected);
                    } else {
                        assert_eq!(load_auth_dot_json(home.path(), mode, kind).unwrap(), stored);
                        assert_eq!(manager.auth_cached().unwrap().api_key(), Some("key"));
                    }
                    return;
                }
                let error = result.unwrap_err();
                assert_eq!(error.to_string(), "ephemeral auth revision changed");
            }
            assert_eq!(load_auth_dot_json(home.path(), mode, kind).unwrap(), stored);
            assert_eq!(manager.auth_cached().and_then(|auth| auth.get_current_auth_json()), cached);
            assert!(!manager.has_external_auth());
            let owner = manager.inner.read().unwrap();
            assert_eq!((owner.source_revision.clone(), owner.revision.clone(),
                *manager.auth_change_state_receiver().borrow()), before);
            assert_eq!(candidate.classified.load(Ordering::SeqCst), 0);
            drop(owner);
            if matches!(change, Change::Cancel) {
                manager.set_external_auth(provider(Reply::Tokens(token_auth.clone()), Timing::Ready)).await.unwrap();
                assert_eq!(load_auth_dot_json(home.path(), mode, kind).unwrap(), expected);
                assert_eq!(manager.auth_cached().unwrap().get_current_auth_json(), expected);
            }
        }).await.unwrap();
    }
}
