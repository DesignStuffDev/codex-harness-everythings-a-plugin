//! Process-local install tickets; raw writers invalidate authority but remain unconditional.
use super::AuthDotJson;
use super::AuthStorageBackend;
use super::compute_store_key;
use once_cell::sync::Lazy;
use std::collections::HashMap;
use std::path::PathBuf;
use std::sync::{Arc, Mutex, MutexGuard, Weak};

const TICKET_LIMIT: usize = 4096;
static STORE: Lazy<Arc<Mutex<State>>> = Lazy::new(|| Arc::new(Mutex::new(State::default())));
struct Revision;
#[derive(Default)]
struct State {
    values: HashMap<String, Arc<AuthDotJson>>,
    tickets: HashMap<String, Weak<Revision>>,
}
pub(in crate::auth) struct InstallTicket {
    key: String,
    revision: Arc<Revision>,
}
pub(in crate::auth) struct PreparedInstall {
    home: PathBuf,
    ticket: InstallTicket,
    value: Arc<AuthDotJson>,
}
#[derive(Debug, thiserror::Error)]
pub(in crate::auth) enum InstallStorageError {
    #[error("ephemeral auth domain is unavailable")]
    DomainUnavailable,
    #[error("ephemeral auth domain changed")]
    DomainChanged,
    #[error("ephemeral auth revision changed")]
    StaleRevision,
    #[error("failed to lock ephemeral auth storage")]
    StoreUnavailable,
    #[error("ephemeral auth ticket capacity exhausted")]
    CapacityExceeded,
    #[error("ephemeral auth storage allocation failed")]
    AllocationFailed,
}

pub(in crate::auth) struct InstallCommit<'a> {
    state: MutexGuard<'a, State>,
    prepared: PreparedInstall,
}
impl InstallCommit<'_> {
    /// Infallible after reservation: no auth reads, callbacks or trait-backed drops.
    pub(in crate::auth) fn commit(self) {
        let Self { mut state, prepared } = self;
        state.tickets.remove(&prepared.ticket.key);
        let retired = state.values.insert(prepared.ticket.key, prepared.value);
        drop(state);
        drop(retired);
    }
}

#[derive(Clone)]
pub(in crate::auth) struct EphemeralAuthStorage {
    codex_home: PathBuf,
    store: Arc<Mutex<State>>,
}
impl std::fmt::Debug for EphemeralAuthStorage {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("EphemeralAuthStorage").finish_non_exhaustive()
    }
}
impl EphemeralAuthStorage {
    pub(in crate::auth) fn new(codex_home: PathBuf) -> Self {
        Self { codex_home, store: Arc::clone(&STORE) }
    }
    pub(in crate::auth) fn ticket(&self) -> Result<InstallTicket, InstallStorageError> {
        let key = compute_store_key(&self.codex_home)
            .map_err(|_| InstallStorageError::DomainUnavailable)?;
        let mut state = self.store.lock().map_err(|_| InstallStorageError::StoreUnavailable)?;
        if let Some(revision) = state.tickets.get(&key).and_then(Weak::upgrade) {
            return Ok(InstallTicket { key, revision });
        }
        // Bounded scan. Retained tickets cannot be evicted; raw values are never evicted.
        state.tickets.retain(|_, revision| revision.strong_count() != 0);
        if state.tickets.len() >= TICKET_LIMIT {
            return Err(InstallStorageError::CapacityExceeded);
        }
        state.tickets.try_reserve(1).map_err(|_| InstallStorageError::AllocationFailed)?;
        let revision = Arc::new(Revision);
        state.tickets.insert(key.clone(), Arc::downgrade(&revision));
        Ok(InstallTicket { key, revision })
    }
    pub(in crate::auth) fn prepare_install(
        &self,
        ticket: InstallTicket,
        value: AuthDotJson,
    ) -> Result<PreparedInstall, InstallStorageError> {
        let key = compute_store_key(&self.codex_home)
            .map_err(|_| InstallStorageError::DomainUnavailable)?;
        if key != ticket.key {
            return Err(InstallStorageError::DomainChanged);
        }
        Ok(PreparedInstall { home: self.codex_home.clone(), ticket, value: Arc::new(value) })
    }
    pub(in crate::auth) fn reserve_install(
        &self,
        prepared: PreparedInstall,
    ) -> Result<InstallCommit<'_>, InstallStorageError> {
        if prepared.home != self.codex_home {
            return Err(InstallStorageError::DomainChanged);
        }
        let mut state = self.store.lock().map_err(|_| InstallStorageError::StoreUnavailable)?;
        let current = state.tickets.get(&prepared.ticket.key).and_then(Weak::upgrade);
        if !current.is_some_and(|revision| Arc::ptr_eq(&revision, &prepared.ticket.revision)) {
            return Err(InstallStorageError::StaleRevision);
        }
        state.values.try_reserve(1).map_err(|_| InstallStorageError::AllocationFailed)?;
        Ok(InstallCommit { state, prepared })
    }
}

impl AuthStorageBackend for EphemeralAuthStorage {
    fn load(&self) -> std::io::Result<Option<AuthDotJson>> {
        let key = compute_store_key(&self.codex_home)?;
        let state = self.store.lock().map_err(|_| std::io::Error::other(InstallStorageError::StoreUnavailable))?;
        let value = state.values.get(&key).cloned();
        drop(state);
        Ok(value.as_deref().cloned())
    }
    fn save(&self, auth: &AuthDotJson) -> std::io::Result<()> {
        let key = compute_store_key(&self.codex_home)?;
        let value = Arc::new(auth.clone());
        let mut state = self.store.lock().map_err(|_| std::io::Error::other(InstallStorageError::StoreUnavailable))?;
        // Every raw write invalidates, even if the complete value is equal.
        state.tickets.remove(&key);
        let retired = state.values.insert(key, value);
        drop(state);
        drop(retired);
        Ok(())
    }
    fn delete(&self) -> std::io::Result<bool> {
        let key = compute_store_key(&self.codex_home)?;
        let mut state = self.store.lock().map_err(|_| std::io::Error::other(InstallStorageError::StoreUnavailable))?;
        // An absent deletion also invalidates outstanding tickets; no tombstone is retained.
        state.tickets.remove(&key);
        let retired = state.values.remove(&key);
        let removed = retired.is_some();
        drop(state);
        drop(retired);
        Ok(removed)
    }
}

#[cfg(test)]
#[path = "ephemeral_install_store_tests.rs"]
mod tests;
