use super::*;
use pretty_assertions::assert_eq;

#[test]
fn install_ticket_capacity_keeps_live_authority_and_recovers_after_cancellation() {
    let home = tempfile::tempdir().unwrap();
    let store = Arc::new(Mutex::new(State::default()));
    let storage = EphemeralAuthStorage { codex_home: home.path().to_path_buf(), store };
    let first = storage.ticket().unwrap();
    let same = storage.ticket().unwrap();
    assert!(Arc::ptr_eq(&first.revision, &same.revision));
    let mut retained = vec![first, same];
    for index in 1..TICKET_LIMIT {
        let peer = EphemeralAuthStorage {
            codex_home: home.path().join(index.to_string()), store: Arc::clone(&storage.store),
        };
        retained.push(peer.ticket().unwrap());
    }
    let extra = EphemeralAuthStorage {
        codex_home: home.path().join("extra"), store: Arc::clone(&storage.store),
    };
    assert!(matches!(extra.ticket(), Err(InstallStorageError::CapacityExceeded)));
    let value: AuthDotJson = serde_json::from_value(serde_json::json!({"OPENAI_API_KEY": "raw"})).unwrap();
    extra.save(&value).unwrap();
    assert_eq!(extra.load().unwrap(), Some(value));
    assert!(extra.delete().unwrap());
    assert!(matches!(extra.ticket(), Err(InstallStorageError::CapacityExceeded)));
    // Raw absent deletion does not require ticket capacity and invalidates a live ticket.
    assert!(!storage.delete().unwrap());
    assert!(!storage.delete().unwrap());
    let admitted = extra.ticket().unwrap();
    assert!(matches!(storage.ticket(), Err(InstallStorageError::CapacityExceeded)));
    drop(admitted);
    let current = storage.ticket().unwrap();
    assert!(!Arc::ptr_eq(&retained[0].revision, &current.revision));
    drop(current);
    drop(retained.pop());
    let peer = EphemeralAuthStorage {
        codex_home: home.path().join("1"), store: Arc::clone(&storage.store),
    };
    assert!(Arc::ptr_eq(&retained[2].revision, &peer.ticket().unwrap().revision));
    assert_eq!(storage.load().unwrap(), None);
}

#[test]
fn abandoned_reservation_does_not_publish_or_revoke_a_peer_ticket() {
    let home = tempfile::tempdir().unwrap();
    let storage = EphemeralAuthStorage {
        codex_home: home.path().to_path_buf(), store: Arc::new(Mutex::new(State::default())),
    };
    let first = storage.ticket().unwrap();
    let peer = storage.ticket().unwrap();
    let value: AuthDotJson = serde_json::from_value(serde_json::json!({"OPENAI_API_KEY": "winner"})).unwrap();
    let prepared = storage.prepare_install(first, value.clone()).unwrap();
    drop(storage.reserve_install(prepared).unwrap());
    assert_eq!(storage.load().unwrap(), None);
    let prepared = storage.prepare_install(peer, value.clone()).unwrap();
    storage.reserve_install(prepared).unwrap().commit();
    assert_eq!(storage.load().unwrap(), Some(value));
}
