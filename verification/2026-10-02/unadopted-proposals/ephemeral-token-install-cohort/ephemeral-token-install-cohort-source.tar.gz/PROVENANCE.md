# Exact source and upstream mapping

Base: formatted refresh source42e3899a688183ae740926d188204ea1222d24f79db1e4b9cb37d51aa046dc59, candidate R/p03-auth-refresh-adoption-01/CANDIDATE_FORMATTED.json (hash in PATCH_INPUTS.json). Existing changed-path bytes are preserved under preimage and matched to the active checkout while root held source frozen. New files are absent from that checkout. This is exact current-path binding, not a new full-tree hash or upstream-revision integration.

Upstream remains Apache-2.0 openai/codex@d42056091aded7feb1d88ac7e83972108b2aa478. LICENSE/NOTICE are unchanged and no third-party dependency or source was added.

| Original/current native symbol | Proposed location and intentional change |
| --- | --- |
| login/src/auth/storage.rs::EPHEMERAL_AUTH_STORE and EphemeralAuthStorage::{new,with_store,load,save,delete} | ephemeral_install_store.rs::{State,EphemeralAuthStorage}; concrete raw adapters keep key derivation/factory behavior but invalidate retained ticket identities. Generic callback helper is removed. |
| storage.rs::compute_store_key / create_auth_storage_with_store | Remain native and unchanged; all existing Ephemeral raw callers use the same revised backend. |
| custom auth_source.rs::install_external_auth / InstallContext / AuthOwnerUpdate::Install | Capture pre-resolve ticket, freeze exact external token payload, carry PreparedInstall, keep existing admitted source/cache/policy checks. Public and startup entrypoints converge here. |
| custom auth_reload.rs::replace_auth_owner | Reserve storage after owner/policy checks and before owned swaps; commit while manager/policy custody remains held, release map before wakeups and trait drops. |
| storage_telemetry.rs::telemetry | Visibility widened only to crate::auth so native conditional install reuses the actual existing logical-save observer; no public crate API or new metrics schema. |
| auth_install_tests.rs existing Provider / installer barriers | Add a token-valued reply to the existing fixture and a sibling test module; all original cases/assertions remain. |

The broad frozen A/B snapshots informed the lifecycle contract, but this is a separate complete slice against current42, not a partial application of B. Current proof binaries and published source remain parent-owned and unchanged. Source-level ownership work does not add another independently replaceable family; eventual auth/storage component interfaces still need versioning, peer dependency routing and real separate-package acceptance.
