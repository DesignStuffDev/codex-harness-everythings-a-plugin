# Root-owned validation after adoption

Nothing below has run for this proposal. Existing current42 production/CLI/runtime results do not cover these bytes.

1. Check every PATCH_INPUTS preimage against the intended source; apply all eight paths atomically as one source cohort. Preserve the current build/proofs before output reuse. Run required formatting and record the resulting source fingerprint and changed-line count; scoped lint can legitimately alter the final count.
2. Use the existing grouped CLI+login feature closure and repo `just test` entrypoint, after actual disk/RAM admission:

   `just test -p codex-cli -p codex-login --lib -E 'package(codex-login) & (test(auth::manager::auth_install_tests::) | test(auth::manager::auth_source_tests::) | test(auth::storage::ephemeral_install_store::tests::))'`

   New public-caller test `token_install_owns_storage_and_cache_or_publishes_neither` has seven cases: unchanged token install, equal raw save, delete/recreate, absent delete, a same-home peer install, canceled owned install followed by successful admission, and nonpersisting key installation despite intervening raw mutation. It compares complete stored/cache payloads, exact source/cache revisions, selected provider and change events as relevant. The positive token case also tests isolation from a provider's retained mutable snapshot. A single five-second timeout bounds each case; readiness is the actual resolver's positive entry signal, not elapsed time or a sleep. No background task or server is introduced.

   The isolated store tests prove live-ticket capacity, raw save/delete at capacity, release/recovery, shared ticket identity, and reserve-then-drop without publication or revoking a retained peer ticket. They are not process/backend/plugin runtime tests.
3. Preserve all original installation tests: latest admitted intent, equal credentials, canceled/failed successor, policy/cache/source ABA, workload public rejection/private startup, provider error classification and reentrant provider destruction. Run the complete affected login suite and existing model-provider consumer regression under the established feature/budget plan. No assertion skip or CA/proxy/DNS/sandbox change is part of this proposal:

   `just test -p codex-cli -p codex-login --lib --test all -E 'package(codex-login)' --test-threads=1`

   Scoped `just fix` follows repository instructions; no complete-workspace run is implied.
4. New source needs a rebuilt production CLI/host and the real selected-auth installation/refresh consumer gate. Reexercise actual storage, migration, plugin install/replace/remove, streaming, cancellation and GUI session/shutdown/recovery against that new build. Use in-app Browser if available; label a real Chromium fallback separately. This source-only worker did neither. Do not relabel older42 runtime evidence.

Explicit untested small cases: captured storage-error bypass for nonpersisting providers (current KeyOnly scenario exercises stale valid ticket bypass), poisoned storage, and filesystem key/remap changes. No compiler has confirmed the staged types/privacy. These should be assessed before landing; the source plan does not declare them passed. Test coverage of the broader stale refresh, logout awaited reload, native identity and durable backends remains in their separate future cohorts.
