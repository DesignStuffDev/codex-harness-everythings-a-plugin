use super::*;
use pretty_assertions::assert_eq;
use std::sync::mpsc;
use std::time::Duration;
use tempfile::TempDir;

fn value(label: &str) -> AuthDotJson {
    AuthDotJson {
        auth_mode: None,
        openai_api_key: Some(label.to_string()),
        tokens: None,
        last_refresh: None,
        agent_identity: None,
        personal_access_token: None,
        bedrock_api_key: None,
        bedrock_access_keys: None,
    }
}

fn isolated(home: &TempDir) -> EphemeralAuthStorage {
    EphemeralAuthStorage {
        codex_home: home.path().to_path_buf(),
        store: Arc::new(Mutex::new(State::default())),
    }
}

#[test]
fn ephemeral_public_adapters_share_revisions_and_preserve_raw_results() -> anyhow::Result<()> {
    let home = tempfile::tempdir()?;
    let storage = EphemeralAuthStorage::new(home.path().to_path_buf());
    let before = storage.snapshot()?;
    crate::auth::save_auth(
        home.path(), &value("first"),
        codex_config::types::AuthCredentialsStoreMode::Ephemeral,
        codex_config::types::AuthKeyringBackendKind::default(),
    )?;
    assert_eq!(storage.load()?, Some(value("first")));
    let stale = storage.prepare(&before.ticket, EphemeralMutation::Replace(value("old")))?;
    assert!(matches!(storage.lock_prepared(stale), Err(EphemeralError::StaleRevision)));
    assert!(crate::auth::logout(
        home.path(), codex_config::types::AuthCredentialsStoreMode::Ephemeral,
        codex_config::types::AuthKeyringBackendKind::default(),
    )?);
    assert!(!storage.delete()?);
    assert_eq!(storage.load()?, None);
    Ok(())
}

#[test]
fn ephemeral_absent_tickets_share_until_absent_delete() -> anyhow::Result<()> {
    let home = tempfile::tempdir()?;
    let storage = isolated(&home);
    let first = storage.snapshot()?;
    let second = storage.snapshot()?;
    assert!(Arc::ptr_eq(&first.ticket.revision, &second.ticket.revision));
    assert_eq!((first.value, second.value), (None, None));
    assert!(!storage.delete()?);
    let next = storage.snapshot()?;
    assert!(!Arc::ptr_eq(&first.ticket.revision, &next.ticket.revision));
    let stale = storage.prepare(&first.ticket, EphemeralMutation::Replace(value("old")))?;
    assert!(matches!(storage.lock_prepared(stale), Err(EphemeralError::StaleRevision)));
    assert_eq!(storage.load()?, None);
    Ok(())
}

#[test]
fn ephemeral_equal_write_and_delete_recreate_reject_old_authority() -> anyhow::Result<()> {
    let home = tempfile::tempdir()?;
    let storage = isolated(&home);
    storage.save(&value("same"))?;
    let first = storage.snapshot()?;
    storage.save(&value("same"))?;
    let stale = storage.prepare(&first.ticket, EphemeralMutation::Delete)?;
    assert!(matches!(storage.lock_prepared(stale), Err(EphemeralError::StaleRevision)));
    let second = storage.snapshot()?;
    assert!(storage.delete()?);
    storage.save(&value("same"))?;
    for ticket in [&first.ticket, &second.ticket] {
        let stale = storage.prepare(ticket, EphemeralMutation::Delete)?;
        assert!(matches!(storage.lock_prepared(stale), Err(EphemeralError::StaleRevision)));
    }
    assert_eq!(storage.load()?, Some(value("same")));
    Ok(())
}

#[test]
fn ephemeral_paused_conditional_writer_cannot_replace_new_raw_value() -> anyhow::Result<()> {
    let home = tempfile::tempdir()?;
    let storage = isolated(&home);
    let peer = storage.clone();
    let (ready_tx, ready_rx) = mpsc::channel();
    let (release_tx, release_rx) = mpsc::channel();
    std::thread::scope(|scope| -> anyhow::Result<()> {
        let writer = scope.spawn(move || -> anyhow::Result<bool> {
            let snapshot = peer.snapshot()?;
            let prepared = peer.prepare(&snapshot.ticket, EphemeralMutation::Replace(value("old")))?;
            ready_tx.send(())?;
            release_rx.recv_timeout(Duration::from_secs(5))?;
            Ok(matches!(peer.lock_prepared(prepared), Err(EphemeralError::StaleRevision)))
        });
        ready_rx.recv_timeout(Duration::from_secs(5))?;
        storage.save(&value("winner"))?;
        release_tx.send(())?;
        assert!(writer.join().expect("writer did not panic")?);
        Ok(())
    })?;
    assert_eq!(storage.load()?, Some(value("winner")));
    Ok(())
}

#[test]
fn ephemeral_one_conditional_commit_wins_and_delete_invalidates_peers() -> anyhow::Result<()> {
    let home = tempfile::tempdir()?;
    let storage = isolated(&home);
    let snapshot = storage.snapshot()?;
    let first = storage.prepare(&snapshot.ticket, EphemeralMutation::Replace(value("winner")))?;
    let second = storage.prepare(&snapshot.ticket, EphemeralMutation::Replace(value("loser")))?;
    assert_eq!(storage.lock_prepared(first)?.commit(), EphemeralOutcome::Replaced);
    assert!(matches!(storage.lock_prepared(second), Err(EphemeralError::StaleRevision)));
    let current = storage.snapshot()?;
    let deletion = storage.prepare(&current.ticket, EphemeralMutation::Delete)?;
    assert_eq!(storage.lock_prepared(deletion)?.commit(), EphemeralOutcome::Deleted { removed: true });
    let absence = storage.snapshot()?;
    let deletion = storage.prepare(&absence.ticket, EphemeralMutation::Delete)?;
    assert_eq!(storage.lock_prepared(deletion)?.commit(), EphemeralOutcome::Deleted { removed: false });
    let stale = storage.prepare(&absence.ticket, EphemeralMutation::Replace(value("old")))?;
    assert!(matches!(storage.lock_prepared(stale), Err(EphemeralError::StaleRevision)));
    assert_eq!(storage.load()?, None);
    Ok(())
}

#[test]
fn ephemeral_abandoned_preparation_and_reservation_leave_value_unchanged() -> anyhow::Result<()> {
    let home = tempfile::tempdir()?;
    let storage = isolated(&home);
    storage.save(&value("initial"))?;
    let snapshot = storage.snapshot()?;
    drop(storage.prepare(&snapshot.ticket, EphemeralMutation::Delete)?);
    let prepared = storage.prepare(&snapshot.ticket, EphemeralMutation::Delete)?;
    drop(storage.lock_prepared(prepared)?);
    assert_eq!(storage.load()?, Some(value("initial")));
    let next = storage.prepare(&snapshot.ticket, EphemeralMutation::Replace(value("next")))?;
    assert_eq!(storage.lock_prepared(next)?.commit(), EphemeralOutcome::Replaced);
    assert_eq!(storage.load()?, Some(value("next")));
    Ok(())
}

#[test]
fn ephemeral_absence_capacity_preserves_raw_writers_and_recovers_released_ticket() -> anyhow::Result<()> {
    let home = tempfile::tempdir()?;
    let storage = isolated(&home);
    storage.save(&value("retained"))?;
    let mut tickets = Vec::new();
    for index in 0..ABSENT_TICKET_LIMIT {
        let peer = EphemeralAuthStorage {
            codex_home: home.path().join(index.to_string()),
            store: Arc::clone(&storage.store),
        };
        tickets.push(peer.snapshot()?.ticket);
    }
    let extra = EphemeralAuthStorage {
        codex_home: home.path().join("extra"),
        store: Arc::clone(&storage.store),
    };
    assert!(matches!(extra.snapshot(), Err(EphemeralError::CapacityExceeded)));
    assert_eq!(extra.load()?, None);
    extra.save(&value("raw"))?;
    assert_eq!(extra.load()?, Some(value("raw")));
    assert!(extra.delete()?);
    assert!(!extra.delete()?);
    assert!(matches!(extra.snapshot(), Err(EphemeralError::CapacityExceeded)));
    drop(tickets.remove(0));
    let admitted = extra.snapshot()?;
    assert_eq!(admitted.value, None);
    assert_eq!(storage.load()?, Some(value("retained")));
    let prepared = extra.prepare(&admitted.ticket, EphemeralMutation::Replace(value("new")))?;
    assert_eq!(extra.lock_prepared(prepared)?.commit(), EphemeralOutcome::Replaced);
    // An untouched live ticket remains usable after reclaiming a different released ticket.
    let peer = EphemeralAuthStorage {
        codex_home: home.path().join("1"),
        store: Arc::clone(&storage.store),
    };
    let prepared = peer.prepare(&tickets[0], EphemeralMutation::Replace(value("peer")))?;
    assert_eq!(peer.lock_prepared(prepared)?.commit(), EphemeralOutcome::Replaced);
    Ok(())
}

#[test]
fn ephemeral_resolved_domain_isolation_and_aliases() -> anyhow::Result<()> {
    let home = tempfile::tempdir()?;
    let storage = isolated(&home);
    let snapshot = storage.snapshot()?;
    let other_home = tempfile::tempdir()?;
    let other = EphemeralAuthStorage { codex_home: other_home.path().to_path_buf(), store: Arc::clone(&storage.store) };
    assert!(matches!(other.prepare(&snapshot.ticket, EphemeralMutation::Delete), Err(EphemeralError::DomainChanged)));
    other.save(&value("other"))?;
    let alias = EphemeralAuthStorage { codex_home: home.path().join("."), store: Arc::clone(&storage.store) };
    let aliased = alias.snapshot()?;
    assert!(Arc::ptr_eq(&snapshot.ticket.revision, &aliased.ticket.revision));
    let prepared = alias.prepare(&aliased.ticket, EphemeralMutation::Replace(value("home")))?;
    assert_eq!(alias.lock_prepared(prepared)?.commit(), EphemeralOutcome::Replaced);
    assert_eq!((storage.load()?, other.load()?), (Some(value("home")), Some(value("other"))));
    Ok(())
}
