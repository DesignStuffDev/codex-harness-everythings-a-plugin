# Validation and adoption obligations

No test, Rust compiler, formatter, cache, process or Git action was performed by this worker. Apply only after parent review and fresh source/resource binding. SOURCE.patch is generated against exact preimages; newly added paths must still be absent. storage_telemetry.rs is pinned unchanged and all existing storage tests remain in place.

Eight proposed tests exercise:

1. Actual exported save_auth/logout with the real Ephemeral adapter, preserving values/removal results and invalidating a prior ticket.
2. Shared absent snapshots, absent delete, successor identity and rejection of the old conditional writer.
3. Equal save and delete/recreate same-value ABA rejection.
4. A causal two-thread sequence: prepared old writer signals ready; raw winner commits; only then old writer is released and rejected. Channel deadlines bound barriers; existing nextest timeout remains the deadlock guard, not a claimed custom bounded thread join.
5. Single winning conditional commit and both present/absent conditional deletion invalidating peers.
6. Dropped preparation and dropped checked map reservation cause no mutation; the original authority remains usable.
7. Fill the actual 4,096-entry cap with live tickets, reject an extra admission, preserve raw writes/deletes and present values, release one ticket and successfully reclaim/admit while another live ticket remains valid.
8. Different-home isolation and canonical dot-alias ticket sharing, using unchanged compute_store_key behavior.

After adoption/root formatting, the current grouped feature approach can be retained with a new exact source/ELF/resource binding:

```
just test -p codex-cli -p codex-login --lib -E 'package(codex-login) & test(auth::storage::ephemeral_storage::tests::)'
just test -p codex-cli -p codex-login --lib --test all -E 'package(codex-login)' --test-threads=1
```

Confirm test discovery; this is a proposed filter, not an executed command. Preserve retries, networking/sandbox guards, process ownership and prior proof archives. Run required scoped formatting/lint per AGENTS; no direct cargo test or complete workspace suite. No new include macros or fixtures are used. Existing defs.bzl source glob covers the two Rust modules; BUILD.bazel/Cargo files do not change.

This unactivated private API may produce dead-code diagnostics before Stage B names its conditional types. No blanket allow was added. Root should report actual diagnostics and choose coherent adoption scope; do not call the primitive a complete component or silently suppress a required caller.

Current proposal has no new rendered UI path; raw poison wording stays identical. Conditional errors are private/unactivated; when Stage B exposes an error in user-visible output, add the repository-required behavior/snapshot coverage at that real caller rather than a static error-string test.

Full current-host/UI/plugin runtime gates still require a rebuilt host after Stage B. Old 7a/78d runtime results do not validate this source. Cross-process/durable CAS, whole login-flow cancellation and independently installed auth storage remain open.
