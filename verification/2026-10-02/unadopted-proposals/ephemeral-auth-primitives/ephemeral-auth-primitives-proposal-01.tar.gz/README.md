# Private Ephemeral primitive — unadopted source proposal

The three-path patch replaces the native Ephemeral map implementation with retained revision tickets and a bounded absence tracker. Raw adapters keep their existing value/removal behavior. Eight proposed tests cover causal stale-writer rejection, equal-value/absence ABA, capacity/recovery, cancellation of a prepared commit, domain aliases and the actual exported raw adapters.

**No tests, compilation or formatting have run. No manager conditional-write activation, public wire API, durable backend fix or independently installed component is claimed.** This is the private Stage A prerequisite authorized after design02; complete caller activation remains Stage B.

Read CONTRACT_REFINEMENT.md, PATCH_INPUTS.json, SOURCE.patch and VALIDATION_PLAN.md. Exact preimages and proposed afterimages are included. All writes are confined to this new recovery proposal directory; original design and refresh proposals remain unchanged. This VM artifact is not an externally durable backup.
