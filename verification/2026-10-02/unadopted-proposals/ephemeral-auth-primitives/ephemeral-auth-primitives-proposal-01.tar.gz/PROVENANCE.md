# Source provenance

Base source: recorded 0742356b9ff442a4d38f6704928930602f92df0fdfe89bfb250897fda470729f reload cohort. Exact storage.rs and unchanged storage_telemetry.rs preimages are preserved; this proposal depends only on those paths, not the still-unadopted permanent-refresh-failure afterimages. Do not overwrite manager or auth_reload source when applying it.

Upstream: openai/codex@d42056091aded7feb1d88ac7e83972108b2aa478, Apache-2.0. Native original symbols storage.rs::EPHEMERAL_AUTH_STORE, EphemeralAuthStorage::{new,with_store,load,save,delete}, create_auth_storage_with_store and compute_store_key map to the new ephemeral_storage.rs module and its unchanged factory path. The old generic map callback helper is replaced by concrete operations; key derivation remains in storage.rs unchanged.

Intentional custom changes: retained revisions, bounded absent snapshots, typed conditional errors, prepared checked commit custody, payload cloning outside the map, and bookkeeping on all raw mutations. storage_telemetry remains the actual wrapper and receives the same public trait methods. No copied third-party code or new license is introduced. LICENSE/NOTICE remain untouched.

This is exact current-preimage provenance, not a reconstructed upstream file-byte comparison or proof of an independently replaceable installed family. Stage B source/cache/policy integration and future storage plugin contracts remain separate.
