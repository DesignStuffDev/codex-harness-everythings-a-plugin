# Causal post-logout awaited reload — source-only test proposal

Against exact sealed A+B, adds one test with two cases beneath the existing auth_tests.rs module. The unchanged control proves the valid JWT/JWKS/task fixture actually yields a native identity through logout's awaited reload. The second case holds the actual task response after local logout, installs a successor through the public API, then verifies all successor publication identities survive completion of the old request. Earlier one-case draft files remain as *.review1.

No production hooks, sandbox flags, sleeps, proxy/CA changes, detached test tasks or existing assertion weakening. No compilation or test run occurred. All setup, network handling and assertions fit the one absolute five-second deadline per case. The complete source cohort and this exact source must be adopted and bound before root can claim acceptance.

Root-owned scoped command after resource admission: `just test -p codex-cli -p codex-login --lib -E 'package(codex-login) & test(post_logout_native_reload_cannot_replace_a_new_external_install)' --test-threads=1`. Keep the current feature context and regression gates; no direct cargo test or complete workspace suite is authorized by this proposal.
