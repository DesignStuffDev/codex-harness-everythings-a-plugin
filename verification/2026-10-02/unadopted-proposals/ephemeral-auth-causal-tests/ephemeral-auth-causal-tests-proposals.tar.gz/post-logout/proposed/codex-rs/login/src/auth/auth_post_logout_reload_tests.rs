//! Proposal against complete A+B; exercises logout's real awaited native reload.
use super::AuthManager;
use super::CODEX_ACCESS_TOKEN_ENV_VAR;
use super::ChatGptEnvironment;
use super::CodexAuth;
use super::EnvVarGuard;
use super::ExternalAuth;
use super::StaticExternalAuth;
use super::WORKSPACE_ID_ALLOWED;
use super::agent_identity_record;
use super::load_auth_dot_json;
use super::logout;
use super::save_auth;
use super::signed_agent_identity_jwt;
use super::test_jwks_body;
use anyhow::Context;
use anyhow::ensure;
use codex_config::types::AuthCredentialsStoreMode;
use codex_config::types::AuthKeyringBackendKind;
use pretty_assertions::assert_eq;
use serde_json::json;
use std::sync::Arc;
use std::time::Duration;
use tokio::io::AsyncReadExt;
use tokio::io::AsyncWriteExt;
use tokio::net::TcpListener;
use tokio::net::TcpStream;
use tokio::time::Instant;

async fn receive(listener: &TcpListener, request_line: &str) -> anyhow::Result<(TcpStream, Vec<u8>)> {
    let (mut stream, _) = listener.accept().await?;
    let mut bytes = Vec::new();
    loop {
        ensure!(bytes.len() <= 73_728, "bounded HTTP request");
        if let Some(end) = bytes.windows(4).position(|part| part == b"\r\n\r\n") {
            ensure!(end <= 8192, "bounded HTTP headers");
            let headers = std::str::from_utf8(&bytes[..end])?;
            ensure!(headers.lines().next() == Some(request_line), "expected native request");
            let length = headers.lines().find_map(|line| {
                let (name, value) = line.split_once(':')?;
                name.eq_ignore_ascii_case("content-length").then(|| value.trim().parse::<usize>())
            }).transpose()?.unwrap_or(0);
            ensure!(length <= 65_536, "bounded HTTP body");
            if bytes.len() >= end + 4 + length {
                return Ok((stream, bytes[end + 4..end + 4 + length].to_vec()));
            }
        } else {
            ensure!(bytes.len() <= 8192, "bounded HTTP headers");
        }
        let mut chunk = [0; 1024];
        let read = stream.read(&mut chunk).await?;
        ensure!(read != 0, "complete native request");
        bytes.extend_from_slice(&chunk[..read]);
    }
}

async fn reply(mut stream: TcpStream, value: serde_json::Value) -> anyhow::Result<()> {
    let body = serde_json::to_vec(&value)?;
    let headers = format!(
        "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n",
        body.len(),
    );
    stream.write_all(headers.as_bytes()).await?;
    stream.write_all(&body).await?;
    stream.shutdown().await?;
    Ok(())
}

#[derive(Clone, Copy)]
enum DuringReload { Unchanged, InstallSuccessor }

#[tokio::test]
#[serial_test::serial(codex_auth_env)]
async fn post_logout_native_reload_cannot_replace_a_new_external_install() -> anyhow::Result<()> {
    for change in [DuringReload::Unchanged, DuringReload::InstallSuccessor] {
        let deadline = Instant::now() + Duration::from_secs(/*secs*/ 5);
        tokio::time::timeout_at(deadline, async {
            let home = tempfile::tempdir()?;
            let listener = TcpListener::bind("127.0.0.1:0").await?;
            let endpoint = format!("http://{}", listener.local_addr()?);
            let record = agent_identity_record(WORKSPACE_ID_ALLOWED);
            let jwt = signed_agent_identity_jwt(&record, json!(record.plan_type))?;
            let _authapi = EnvVarGuard::set("CODEX_AGENT_IDENTITY_AUTHAPI_BASE_URL", &endpoint);
            let _jwks = EnvVarGuard::set("CODEX_AGENT_IDENTITY_JWKS_BASE_URL", &format!("{endpoint}/api/codex"));
            let _access_token = EnvVarGuard::set(CODEX_ACCESS_TOKEN_ENV_VAR, &jwt);
            let initial = CodexAuth::from_external_chatgpt_tokens(
                "initial.e30.signature", WORKSPACE_ID_ALLOWED, /*chatgpt_plan_type*/ None,
            )?;
            // The existing Ephemeral credential wins over the synthetic env JWT at startup.
            save_auth(home.path(), &initial.get_current_auth_json().context("initial auth")?,
                AuthCredentialsStoreMode::Ephemeral, AuthKeyringBackendKind::default())?;
            let manager = AuthManager::shared(
                home.path().to_path_buf(), /*enable_codex_api_key_env*/ false,
                AuthCredentialsStoreMode::Ephemeral, /*forced_chatgpt_workspace_id*/ None,
                Some(ChatGptEnvironment::Staging.chatgpt_base_url().to_string()),
                AuthKeyringBackendKind::default(),
                crate::test_support::transport_default_auth_route_config(),
            ).await;
            manager.set_external_auth(Arc::new(StaticExternalAuth(initial))).await?;
            let old_source = manager.inner.read().unwrap().source_revision.clone();
            let changes = manager.auth_change_state_receiver();
            let successor_auth = CodexAuth::from_external_chatgpt_tokens(
                "successor.e30.signature", WORKSPACE_ID_ALLOWED, /*chatgpt_plan_type*/ None,
            )?;
            let expected = successor_auth.get_current_auth_json().context("successor auth")?;
            let successor: Arc<dyn ExternalAuth> = Arc::new(StaticExternalAuth(successor_auth));

            // Both HTTP requests belong to logout -> reload_after_logout -> native load_auth.
            // The complete task request proves the JWT signature was already verified.
            let server = async {
                let (stream, body) = receive(&listener, "GET /api/codex/agent-identities/jwks HTTP/1.1").await?;
                ensure!(body.is_empty(), "JWKS GET has no body");
                reply(stream, test_jwks_body()).await?;
                let request_line = format!("POST /v1/agent/{}/task/register HTTP/1.1", record.agent_runtime_id);
                let (held, body) = receive(&listener, &request_line).await?;
                let payload: serde_json::Value = serde_json::from_slice(&body)?;
                ensure!(payload.get("signature").is_some(), "signed task-registration request");
                assert_eq!(manager.auth_cached(), None);
                assert_eq!(load_auth_dot_json(home.path(), AuthCredentialsStoreMode::Ephemeral,
                    AuthKeyringBackendKind::default())?, None);
                ensure!(!manager.has_external_auth(), "local owner was cleared before native reload");
                assert_ne!(manager.inner.read().unwrap().source_revision, old_source);

                let published = match change {
                    DuringReload::Unchanged => None,
                    DuringReload::InstallSuccessor => {
                        // Install through the public caller while the old response is withheld.
                        manager.set_external_auth(Arc::clone(&successor)).await?;
                        let current = manager.inner.read().unwrap();
                        Some((current.source_revision.clone(), current.revision.clone(), *changes.borrow()))
                    }
                };
                reply(held, json!({ "task_id": "post-logout-task" })).await?;
                Ok::<_, anyhow::Error>(published)
            };
            let request = async { manager.logout().await.map_err(anyhow::Error::from) };
            let (removed, published) = tokio::try_join!(request, server)?;
            ensure!(removed, "logout removed the original Ephemeral credential");
            match published {
                Some(published) => {
                    assert_eq!(load_auth_dot_json(home.path(), AuthCredentialsStoreMode::Ephemeral,
                        AuthKeyringBackendKind::default())?, Some(expected.clone()));
                    assert_eq!(manager.auth_cached().as_ref().and_then(CodexAuth::get_current_auth_json), Some(expected));
                    ensure!(Arc::ptr_eq(&manager.external_auth_provider().context("successor source")?, &successor));
                    let current = manager.inner.read().unwrap();
                    assert_eq!((current.source_revision.clone(), current.revision.clone(), *changes.borrow()), published);
                }
                None => {
                    // Logout swallows reload errors: this control proves the same fixture loads.
                    assert_eq!(load_auth_dot_json(home.path(), AuthCredentialsStoreMode::Ephemeral,
                        AuthKeyringBackendKind::default())?, None);
                    ensure!(!manager.has_external_auth());
                    let Some(CodexAuth::AgentIdentity(loaded)) = manager.auth_cached() else {
                        anyhow::bail!("unchanged logout must publish the native reload result");
                    };
                    let mut expected_record = record.clone();
                    expected_record.task_id = Some("post-logout-task".to_string());
                    assert_eq!(loaded.record(), &expected_record);
                    assert_eq!(loaded.run_task_id(), "post-logout-task");
                }
            }
            // Raw cleanup avoids starting another env-backed reload after the finite server exits.
            assert_eq!(logout(home.path(), AuthCredentialsStoreMode::Ephemeral, AuthKeyringBackendKind::default())?,
                matches!(change, DuringReload::InstallSuccessor));
            Ok::<(), anyhow::Error>(())
        }).await.context("post-logout native reload deadline")??;
    }
    Ok(())
}
