//! Unrun real-caller proposal. Reuses the existing serialized auth endpoint fixture.
use super::EnvGuard;
use super::build_tokens;
use chrono::Utc;
use codex_config::types::AuthCredentialsStoreMode;
use codex_login::AuthDotJson;
use codex_login::AuthKeyringBackendKind;
use codex_login::AuthManager;
use codex_login::REFRESH_TOKEN_URL_OVERRIDE_ENV_VAR;
use codex_login::REVOKE_TOKEN_URL_OVERRIDE_ENV_VAR;
use codex_login::load_auth_dot_json;
use codex_login::logout;
use codex_login::save_auth;
use codex_protocol::auth::AuthMode;
use pretty_assertions::assert_eq;
use std::sync::Arc;
use std::time::Duration;
use tempfile::TempDir;
use tokio::io::AsyncReadExt;
use tokio::io::AsyncWriteExt;
use tokio::net::TcpListener;
use tokio::net::TcpStream;
use tokio::time::Instant;

async fn fixture(home: &TempDir) -> (Arc<AuthManager>, AuthDotJson) {
    let initial = AuthDotJson {
        auth_mode: Some(AuthMode::Chatgpt),
        openai_api_key: None,
        tokens: Some(build_tokens("initial-access", "initial-refresh")),
        last_refresh: Some(Utc::now()),
        agent_identity: None,
        personal_access_token: None,
        bedrock_api_key: None,
        bedrock_access_keys: None,
    };
    save(home, &initial);
    let manager = AuthManager::shared(
        home.path().to_path_buf(), /*enable_codex_api_key_env*/ false,
        AuthCredentialsStoreMode::Ephemeral, /*forced_chatgpt_workspace_id*/ None,
        /*chatgpt_base_url*/ None, AuthKeyringBackendKind::default(),
        codex_login::test_support::transport_default_auth_route_config(),
    ).await;
    (manager, initial)
}
fn save(home: &TempDir, value: &AuthDotJson) {
    save_auth(home.path(), value, AuthCredentialsStoreMode::Ephemeral,
        AuthKeyringBackendKind::default()).unwrap();
}
fn stored(home: &TempDir) -> Option<AuthDotJson> {
    load_auth_dot_json(home.path(), AuthCredentialsStoreMode::Ephemeral,
        AuthKeyringBackendKind::default()).unwrap()
}
async fn receive(listener: &TcpListener, path: &str) -> (TcpStream, serde_json::Value) {
    let (mut socket, _) = listener.accept().await.unwrap();
    let mut bytes = Vec::new();
    loop {
        assert!(bytes.len() < 65_536);
        let mut chunk = [0; 1024];
        let read = socket.read(&mut chunk).await.unwrap();
        assert_ne!(read, 0);
        bytes.extend_from_slice(&chunk[..read]);
        if let Some(end) = bytes.windows(4).position(|part| part == b"\r\n\r\n") {
            let headers = std::str::from_utf8(&bytes[..end]).unwrap();
            assert_eq!(headers.lines().next().unwrap(), format!("POST {path} HTTP/1.1"));
            let length = headers.lines().find_map(|line| {
                let (name, value) = line.split_once(':')?;
                name.eq_ignore_ascii_case("content-length").then(|| value.trim().parse::<usize>().unwrap())
            }).unwrap();
            assert!(length < 65_536);
            if bytes.len() >= end + 4 + length {
                return (socket, serde_json::from_slice(&bytes[end + 4..end + 4 + length]).unwrap());
            }
        }
    }
}
async fn reply(mut socket: TcpStream, body: &str) {
    socket.write_all(format!("HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{body}", body.len()).as_bytes()).await.unwrap();
    socket.shutdown().await.unwrap();
}
#[derive(Clone, Copy)]
enum Change { Unchanged, EqualSave, DeleteRecreate, ManagerLogout }

#[serial_test::serial(auth_env)]
#[tokio::test]
async fn ephemeral_native_refresh_carries_its_pre_request_storage_revision() {
    for guarded in [false, true] {
        for change in [Change::Unchanged, Change::EqualSave, Change::DeleteRecreate, Change::ManagerLogout] {
            let deadline = Instant::now() + Duration::from_secs(/*secs*/ 5);
            tokio::time::timeout_at(deadline, async {
                let home = tempfile::tempdir().unwrap();
                let listener = TcpListener::bind(("127.0.0.1", 0)).await.unwrap();
                let _endpoint = EnvGuard::set(REFRESH_TOKEN_URL_OVERRIDE_ENV_VAR,
                    format!("http://{}/oauth/token", listener.local_addr().unwrap()));
                let (manager, initial) = fixture(&home).await;
                let issued = manager.auth_cached().unwrap();
                let request = async {
                    if guarded { manager.refresh_token().await } else { manager.refresh_token_from_authority().await }
                };
                let server = async {
                    let (socket, body) = receive(&listener, "/oauth/token").await;
                    assert_eq!(body["refresh_token"], "initial-refresh");
                    match change {
                        Change::Unchanged => (),
                        Change::EqualSave => save(&home, &initial),
                        Change::DeleteRecreate => {
                            assert!(logout(home.path(), AuthCredentialsStoreMode::Ephemeral,
                                AuthKeyringBackendKind::default()).unwrap());
                            save(&home, &initial);
                        }
                        Change::ManagerLogout => { assert!(manager.logout().await.unwrap()); }
                    }
                    reply(socket, r#"{"access_token":"new-access","refresh_token":"new-refresh"}"#).await;
                };
                let (result, ()) = tokio::join!(request, server);
                match change {
                    Change::Unchanged => {
                        result.unwrap();
                        let committed = stored(&home).unwrap();
                        assert_eq!(committed.tokens.as_ref().unwrap().access_token, "new-access");
                        assert_eq!(committed.tokens.as_ref().unwrap().refresh_token, "new-refresh");
                        assert_eq!(manager.auth_cached().unwrap().get_token_data().unwrap(), committed.tokens.unwrap());
                    }
                    Change::EqualSave | Change::DeleteRecreate => {
                        assert!(result.is_err());
                        assert_eq!(stored(&home), Some(initial.clone()));
                        assert_eq!(manager.auth_cached().unwrap().get_token_data().unwrap(), initial.tokens.clone().unwrap());
                    }
                    Change::ManagerLogout => {
                        assert!(result.is_err());
                        assert_eq!(stored(&home), None);
                        assert_eq!(manager.auth_cached(), None);
                    }
                }
                assert_eq!(issued.get_token_data().unwrap(), initial.tokens.unwrap());
                logout(home.path(), AuthCredentialsStoreMode::Ephemeral, AuthKeyringBackendKind::default()).unwrap();
            }).await.unwrap();
        }
    }
}

#[serial_test::serial(auth_env)]
#[tokio::test]
async fn ephemeral_revoke_logout_does_not_delete_a_later_equal_save() {
    for managed in [false, true] {
        let deadline = Instant::now() + Duration::from_secs(/*secs*/ 5);
        tokio::time::timeout_at(deadline, async {
            let home = tempfile::tempdir().unwrap();
            let listener = TcpListener::bind(("127.0.0.1", 0)).await.unwrap();
            let _refresh = EnvGuard::set(REFRESH_TOKEN_URL_OVERRIDE_ENV_VAR,
                format!("http://{}/oauth/token", listener.local_addr().unwrap()));
            let _revoke = EnvGuard::set(REVOKE_TOKEN_URL_OVERRIDE_ENV_VAR,
                format!("http://{}/oauth/revoke", listener.local_addr().unwrap()));
            let (manager, initial) = fixture(&home).await;
            let route = codex_login::test_support::transport_default_auth_route_config();
            let request = async {
                if managed { manager.logout_with_revoke().await } else {
                    codex_login::logout_with_revoke(home.path(), AuthCredentialsStoreMode::Ephemeral,
                        AuthKeyringBackendKind::default(), &route).await
                }
            };
            let server = async {
                let (socket, body) = receive(&listener, "/oauth/revoke").await;
                assert_eq!(body["token"], "initial-refresh");
                save(&home, &initial);
                reply(socket, "{}").await;
            };
            let (result, ()) = tokio::join!(request, server);
            assert!(result.is_err());
            assert_eq!(stored(&home), Some(initial.clone()));
            assert_eq!(manager.auth_cached().unwrap().get_token_data().unwrap(), initial.tokens.unwrap());
            logout(home.path(), AuthCredentialsStoreMode::Ephemeral, AuthKeyringBackendKind::default()).unwrap();
        }).await.unwrap();
    }
}

#[derive(Clone, Copy)]
enum CancellationPath { Guarded, Direct }
impl CancellationPath {
    async fn refresh(self, manager: &AuthManager) -> Result<(), codex_login::RefreshTokenError> {
        match self {
            Self::Guarded => manager.refresh_token().await,
            Self::Direct => manager.refresh_token_from_authority().await,
        }
    }
}

#[serial_test::serial(auth_env)]
#[tokio::test]
async fn ephemeral_canceled_native_refresh_releases_caller_custody_without_publication() {
    for path in [CancellationPath::Guarded, CancellationPath::Direct] {
        let deadline = Instant::now() + Duration::from_secs(/*secs*/ 5);
        tokio::time::timeout_at(deadline, async {
            let home = tempfile::tempdir().unwrap();
            let listener = TcpListener::bind(("127.0.0.1", 0)).await.unwrap();
            let _endpoint = EnvGuard::set(REFRESH_TOKEN_URL_OVERRIDE_ENV_VAR,
                format!("http://{}/oauth/token", listener.local_addr().unwrap()));
            let (manager, initial) = fixture(&home).await;
            let issued = manager.auth_cached().unwrap();
            let changes = manager.auth_change_state_receiver();
            let generation = *changes.borrow();
            let mut canceled = Box::pin(path.refresh(&manager));
            let (held_socket, request) = tokio::select! {
                result = &mut canceled => panic!("refresh completed before held response: {result:?}"),
                request = receive(&listener, "/oauth/token") => request,
            };
            assert_eq!(request["refresh_token"], "initial-refresh");
            // Drop the actual owned future, not a JoinHandle or merely a pin reference.
            drop(canceled);
            assert_eq!(stored(&home), Some(initial.clone()));
            assert_eq!(manager.auth_cached().unwrap().get_token_data().unwrap(), initial.tokens.clone().unwrap());
            assert_eq!(*changes.borrow(), generation);

            // The next actual public call must reach the server while the first response is
            // still held: this establishes semaphore/caller-custody recovery without a sleep.
            let mut next = Box::pin(path.refresh(&manager));
            let (next_socket, request) = tokio::select! {
                result = &mut next => panic!("next refresh completed before response: {result:?}"),
                request = receive(&listener, "/oauth/token") => request,
            };
            assert_eq!(request["refresh_token"], "initial-refresh");
            assert_eq!(stored(&home), Some(initial.clone()));
            assert_eq!(*changes.borrow(), generation);
            drop(held_socket);
            reply(next_socket, r#"{"access_token":"accepted-access","refresh_token":"accepted-refresh"}"#).await;
            next.await.unwrap();
            let committed = stored(&home).unwrap();
            let expected_tokens = super::build_tokens("accepted-access", "accepted-refresh");
            assert_eq!(committed.tokens, Some(expected_tokens.clone()));
            assert_eq!(manager.auth_cached().unwrap().get_token_data().unwrap(), expected_tokens);
            assert_eq!(issued.get_token_data().unwrap(), initial.tokens.unwrap());
            assert_eq!(changes.borrow().generation, generation.generation + 1);
            assert_eq!(changes.borrow().owner_generation, generation.owner_generation);
            logout(home.path(), AuthCredentialsStoreMode::Ephemeral, AuthKeyringBackendKind::default()).unwrap();
        }).await.unwrap();
    }
}
