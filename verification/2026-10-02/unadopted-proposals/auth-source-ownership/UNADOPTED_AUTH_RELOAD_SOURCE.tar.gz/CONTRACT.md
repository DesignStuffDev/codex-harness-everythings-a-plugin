# Native reload source-owner contract (proposal only)

Capture one existing CachedAuth snapshot under its credential read lock, including the selected external provider Arc, source revision, cache revision, credentials and permanent failure. Capture local policy before this snapshot; the existing commit revalidates it. No native lock survives an await or external callback.

Carry the existing retained AuthSourceRevision in LoadedAuth and CachePolicy::Captured. At commit, under the credential write lock, check source revision and cache revision before the existing workspace-policy commit guard. Retired trait-backed values still drop after all locks. Install continues using its existing InstallContext; do not introduce a second install ledger or change latest-admitted install behavior. A pending install intent alone does not revoke the currently committed source.

Both reload and guarded reload preserve their existing false/Skipped result on stale publication. Replacement and Preserve/failure candidates are fenced equally. Equal-credential source replacement and A-to-B-to-A source transitions invalidate old candidates even when credential notifications are unchanged. Native-source candidates must also remain bound to their captured source lineage.

Scope: compiled native authority prerequisite, not independently installed auth/catalog. Refresh ownership, conditional ephemeral/durable persistence, initial acquisition/request dispatch and retry lifetimes, gateway settlement and model cache/mirror publication remain separate open gates. No public API, component wire, dependency or policy change. These changes do not undo effects performed inside an external resolve implementation.

Planned causal tests: both reload paths during equal-credential source replacement and source ABA; old source permanent failure cannot poison equal restored credentials; a native loaded candidate cannot overwrite a newly installed source with equal cached credentials; unchanged source still reloads; observer cancellation causes no late reload commit. Source capture/commit proofs do not claim HTTP, socket, process shutdown or persistence proof.

Root owns adoption and all Rust checks. No compilers, tests, formatters, repository edits or cache operations are permitted in this proposal task.
