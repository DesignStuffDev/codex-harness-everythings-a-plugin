# Auth reload source ownership — isolated proposal 01

Staged for root review only: 259 additions/11 deletions over five Rust paths. No checkout edits, compiler, formatter, tests, cache mutation or Git writes occurred. Root accepted CONTRACT.md before source editing. Current exact preimages were checked again at seal. SOURCE.patch is the adoption unit; full proposed files are review artifacts, not instructions to overwrite current source.

Existing AuthSourceRevision now accompanies LoadedAuth into conditional publication. The native resolver selects source/credentials/failure/cache identity from one existing CachedAuth snapshot. Both normal and account-guarded reload reject stale source results and failure metadata even when replacement credentials are identical. Latest-install ordering, policy/cache fences, current acquisition, and notification behavior remain preserved contracts.

Five new test functions cover ten internal scenarios. They have not run. GATES.md defines focused and scoped regression commands and exact limits; STATIC_REVIEW.md records source review. Root alone decides resource-safe adoption and verification. Unchanged-source success coverage remains in the existing suite.

PROVENANCE.json maps the pinned official manager source and earlier custom modules; PREIMAGES.json binds the current files and root Stage B candidate reference. Existing Apache-2.0 LICENSE/NOTICE remain in the repository. No new dependency, public API, wire contract, user-visible diagnostic or persistence format is introduced.

This remains a compiled-native authority prerequisite, not installed auth/catalog or another extracted family. LIMITS.md records refresh, conditional persistence, mutable token, request-dispatch, broker/model composition and lifecycle gates still open. Earlier production results do not validate this proposal.
