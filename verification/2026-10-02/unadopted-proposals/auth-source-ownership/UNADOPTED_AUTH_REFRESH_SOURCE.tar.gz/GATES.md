# Adoption and verification — proposed, not run

Apply only after reviewed reload-source proposal01 has been adopted and checked; this proposal's manager preimage is that sealed proposal, not root's frozen Stage B checkout. Rebase mechanically after any formatting/lint transition and re-pin exact preimages. SOURCE.patch is the full three-path follow-up. Do not fuzzy-apply or overwrite the active repository from proposed/.

Four new unit-test functions contain twelve internal scenarios, not twelve separate runner tests:

- Both public refresh methods across current source, equal-credential replacement and same-Arc ABA: original returned error, positive current-source fast-path behavior, actual selected-provider subsequent call, cache revision and notification preservation (six scenarios).
- Both public methods across cache ABA and policy ABA with the same source (four scenarios).
- Dropping the actual public refresh future while its callback is held releases the refresh semaphore; a subsequent current-source operation works and records its own failure (one scenario).
- Two managers on the same home keep independent failure authority. Header credentials are used, so this is not a store transaction test (one scenario).

All concurrency uses directly owned futures and one five-second bound per held scenario. No spawned task, native process, server or blocking worker is held. Setup uses actual source installation; fixture values are synthetic. This does not establish native ChatGPT HTTP failure behavior, request dispatch safety or transport cleanup.

Root-scoped sequence, subject to fresh resource/source preflight and unchanged strict runner:

1. If a causal red gate is useful, add only the new test module and declaration to the accepted reload baseline; do not move the old test-seeding helper until applying the production change. Expected failures are the old-source and cache/policy publication tests; these expected results have NOT been observed.
2. Adopt the complete follow-up, required formatting, exact source/binary pinning, then `just test -p codex-login --lib -E 'test(auth::manager::auth_refresh_failure_tests::)'`.
3. Run `just test -p codex-login` for existing refresh modes, Permanent/Transient handling, reload/current acquisition, install ordering, cancellation and storage compatibility. Also preserve existing model-provider/retained endpoint regression obligations for the combined auth checkpoint. No filtered/compiled-only result counts as a package pass.
4. Run scoped `just fix -p codex-login` and required `just fmt`; preserve meaningful source transitions and do not repeat tests solely for style. No workspace-wide suite is admitted by this proposal.
5. Bind any later actual host/installed plugin/GUI gates to the new combined source and binaries. Prior Stage B production results cannot validate these proposals. No Browser, inference, backend, persistence, cross-process or independent-package acceptance has run here.

No new dependencies, public API/wire changes or Bazel metadata are needed. The new sibling test file is linked from the already-discovered login library through cfg(test); the old fixture helper remains only within the existing cfg(test) auth_source_tests module.
