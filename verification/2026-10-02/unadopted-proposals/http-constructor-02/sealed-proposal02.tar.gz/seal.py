from pathlib import Path
import hashlib,json,difflib,subprocess,os
P=Path(__file__).resolve().parent
REPO=Path('/workspace/codex-harness-everythings-a-plugin')
R=Path('/workspace/recovery-backups/20260930T165936Z')
OLD=Path('/tmp/p03-http-native-constructor-proposal-01')
REV='d42056091aded7feb1d88ac7e83972108b2aa478'
def sha(data): return hashlib.sha256(data).hexdigest()
def dump(name,obj): (P/name).write_text(json.dumps(obj,indent=2)+'\n')
def row(path,base):
 data=(base/path).read_bytes();return {'path':path,'sha256':sha(data),'bytes':len(data)}
after={str(f.relative_to(P/'source')):f.read_bytes() for f in (P/'source').rglob('*') if f.is_file()}
before={}
for path in sorted(after):
 src=REPO/path;pre=P/'preimage'/path
 if pre.exists():
  assert src.is_file() and src.read_bytes()==pre.read_bytes(), f'changed preimage {path}'
  before[path]=pre.read_bytes()
 else:
  assert not src.exists(),f'new path already exists: {path}'
  before[path]=None
assert 'codex-rs/utils/process/src/process_shutdown_tests.rs' not in after
oldbinding=json.loads((OLD/'SOURCE_BINDING.json').read_text())
refs=oldbinding['reference_inputs']
for item in refs:
 assert row(item['path'],REPO)['sha256']==item['sha256'],f'changed reference {item["path"]}'
watchdog=row('codex-rs/utils/process/src/process_shutdown_tests.rs',REPO)
assert watchdog['sha256']=='9d568bf72a934a4190073a2884574980c1e5945010e0851cc5a2d67be88dec4b'
watchdog['purpose']='reference-only already adopted/formatted/tested root prerequisite; not patched by proposal02'
refs.append(watchdog)
candidate=R/'p03-runtime-drop-test-adoption-01/CANDIDATE.json'
assert sha(candidate.read_bytes())=='f8558f717ad43dcf6987592eaf2c2af63341ae6a2f50c3aeb74463bba483f75c'
tokio=Path('/workspace/toolchains/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/tokio-1.52.3')
librefs=[]
for rel in ['src/runtime/runtime.rs','src/runtime/scheduler/current_thread/mod.rs','src/runtime/blocking/pool.rs','src/runtime/task/harness.rs']:
 item=row(rel,tokio);item['path']=str(tokio/rel);item['purpose']='pinned installed library source reviewed only; no behavior test result';librefs.append(item)
env=os.environ.copy();env.update(GIT_NO_LAZY_FETCH='1',GIT_NO_REPLACE_OBJECTS='1',GIT_OPTIONAL_LOCKS='0')
head=subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],env=env,text=True).strip()
upstream=[]
for path in sorted(after):
 lines=subprocess.check_output(['git','-C','/tmp/codex-upstream-source','ls-tree',REV,'--',path],env=env,text=True).splitlines()
 item={'path':path,'revision':REV,'exists':bool(lines)}
 if lines:
  mode,kind,oid_name=lines[0].split(' ',2);oid,name=oid_name.split('\t');assert name==path and kind=='blob'
  data=subprocess.check_output(['git','-C','/tmp/codex-upstream-source','cat-file','blob',oid],env=env)
  assert (P/'upstream'/path).read_bytes()==data
  item.update(git_blob=oid,sha256=sha(data),bytes=len(data))
 else:item['reason']='new custom path absent at pinned upstream revision'
 upstream.append(item)
dump('UPSTREAM_PREIMAGES.json',upstream)
dump('SOURCE_BINDING.json',{
 'status':'UNADOPTED_UNEXECUTED_PROPOSAL',
 'reference_current_checkout_commit':head,
 'reference_source_cohort':{'path':str(candidate),'sha256':sha(candidate.read_bytes()),'source_count':8936,'source_map_sha256':'8d2daf261bf0be11e1de3344b08e3bc8b6cff3065b91c5363ad8e7832bf07660','meaning':'Root watchdog-test checkpoint6446edf; metadata identity, not a test result for proposal02. Selected source/reference paths were freshly compared; no extra full-tree map computed.'},
 'historical_production_reference':{'source_map_sha256':'f05b8b9f19a7d8a9a78691970549c30fc0660b5c64769c03d94dc5292c523328','cli_sha256':'bbed687d4c1a59f64c8b071ad0e5a328520d3db18d5e3dc37c8f064d196c9853','meaning':'Historical source-specific runtime evidence only; ELF not rehashed or validated for this proposal.'},
 'preserved_proposal01_manifest':{'path':str(OLD/'MANIFEST.json'),'sha256':sha((OLD/'MANIFEST.json').read_bytes()),'status':'native adoption blocked by confirmed cross-runtime cleanup defect; preserved unchanged'},
 'upstream_revision':REV,'reference_inputs':refs,'library_source_references':librefs,
 'exact_patch_preimages':[{'path':path,'sha256':sha(before[path]) if before[path] is not None else None,'bytes':len(before[path]) if before[path] is not None else None,'new_path':before[path] is None} for path in sorted(after)]})
owner='codex-rs/http-client/src/constructor_custody.rs'
owner_tests=['codex-rs/http-client/src/constructor_custody_tests.rs','codex-rs/http-client/src/constructor_cross_runtime_tests.rs']
module_suffix=b'\n#[cfg(test)]\n#[path = "constructor_custody_tests.rs"]\nmod tests;\n\n#[cfg(test)]\n#[path = "constructor_cross_runtime_tests.rs"]\nmod cross_runtime_tests;\n'
assert after[owner].endswith(module_suffix)
a_paths=sorted(path for path in after if path.startswith('codex-rs/http-client/'))
b_paths=sorted(set(after)-set(a_paths));assert len(a_paths)==7 and len(b_paths)==11
a1_after={path:data for path,data in after.items() if path in a_paths and path not in owner_tests}
a1_after[owner]=after[owner][:-len(module_suffix)]+b'\n'
a2_before={owner:a1_after[owner],**{p:None for p in owner_tests}}
a2_after={path:after[path] for path in a2_before}
stages={}
def stage(name,old,new,meaning):
 chunks=[];added=removed=0;bindings=[]
 for path in sorted(new):
  pre=old[path];post=new[path];assert pre!=post
  diff=list(difflib.unified_diff((pre or b'').decode().splitlines(keepends=True),post.decode().splitlines(keepends=True),fromfile='a/'+path if pre is not None else '/dev/null',tofile='b/'+path,n=3))
  added+=sum(line.startswith('+') and not line.startswith('+++') for line in diff)
  removed+=sum(line.startswith('-') and not line.startswith('---') for line in diff)
  chunks.append(f'diff --git a/{path} b/{path}\n')
  if pre is None:chunks.append('new file mode 100644\n')
  chunks.extend(diff)
  bindings.append({'path':path,'before_sha256':sha(pre) if pre is not None else None,'after_sha256':sha(post)})
 data=''.join(chunks).encode();(P/(name+'.patch')).write_bytes(data)
 stages[name]={'paths':len(new),'added':added,'removed':removed,'patch_sha256':sha(data),'meaning':meaning,'bindings':bindings}
stage('stage-A-native-pool',before,{p:after[p] for p in a_paths},'Complete native A acceptance unit: actual pool activation and all14 proposed HTTP tests. B not activated.')
stage('stage-A1-native-pool-review',before,a1_after,'Review/apply subdivision only: real production pool activation and3 direct pool tests. A2 required before claiming full A validation.')
stage('stage-A2-owner-cross-runtime-review',a2_before,a2_after,'Sequential exact A1-to-full-A subdivision:8 owner/deadline and3 cross-runtime tests; no production semantics beyond A1.')
stage('stage-B-process-final',before,{p:after[p] for p in b_paths},'Separate executable aggregation/diagnostic integration, depends on full A; existing watchdog test reference only.')
stage('combined',before,after,'Full unvalidated A+B proposal; not recommended as a single adoption step.')
dump('STAGES.json',stages)
for path in a_paths:
 if path not in owner_tests: continue
 assert (P/'source'/path).read_text().count('#[test]')+(P/'source'/path).read_text().count('#[tokio::test') in [3,8]
assert sum((P/'source'/path).read_text().count('#[test]')+(P/'source'/path).read_text().count('#[tokio::test') for path in a_paths)==14
(P/'PATCH_REVIEW.md').write_text('# Exact proposal02 patch subdivision\n\n'+ '\n'.join(f'- {name}: {v["paths"]} paths, +{v["added"]}/-{v["removed"]}; {v["meaning"]}' for name,v in stages.items())+'\n\nApply either full A or sequential A1 then A2, never both alternatives. A1 and A2 are review-size boundaries; full A is the required validation unit. B is disjoint from A and remains separately unadopted until reviewed validation/resources permit. Source after-images represent combined A+B, not a partially adopted checkout. Parent owner is354 authored lines; primary Task leaf141. The aggregate increase above800 is disclosed and chiefly due14 regressions, not hidden as separate completion claims. None was built/formatted/tested here.\n')
# Recheck source bytes after metadata generation; fail closed on concurrent adoption.
for path,data in before.items():
 assert ((REPO/path).read_bytes() if (REPO/path).exists() else None)==data,f'preimage changed while sealing {path}'
for item in refs: assert row(item['path'],REPO)['sha256']==item['sha256']
files=[row(str(f.relative_to(P)),P) for f in sorted(P.rglob('*')) if f.is_file() and f.name!='MANIFEST.json' or f.is_file() and f.parent!=P and f.name=='MANIFEST.json']
assert sum(x['bytes'] for x in files)<10*1024*1024
manifest={'status':'SEALED_UNADOPTED_UNEXECUTED_PROPOSAL','source_preimages_verified_unchanged':True,'staging_only_not_external_backup':True,'tests_executed':False,'formatter_or_compiler_run':False,'proposal01_preserved':True,'total_file_bytes':sum(x['bytes'] for x in files),'files':files}
dump('MANIFEST.json',manifest)
print(json.dumps({'directory':str(P),'manifest_sha256':sha((P/'MANIFEST.json').read_bytes()),'files':len(files),'bytes':manifest['total_file_bytes'],'source_binding_sha256':sha((P/'SOURCE_BINDING.json').read_bytes()),'stages':{k:{a:b for a,b in v.items() if a!='bindings'} for k,v in stages.items()}},indent=2))
