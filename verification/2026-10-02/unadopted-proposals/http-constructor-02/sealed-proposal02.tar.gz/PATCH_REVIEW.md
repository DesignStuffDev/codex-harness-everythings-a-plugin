# Exact proposal02 patch subdivision

- stage-A-native-pool: 7 paths, +1112/-19; Complete native A acceptance unit: actual pool activation and all14 proposed HTTP tests. B not activated.
- stage-A1-native-pool-review: 5 paths, +702/-19; Review/apply subdivision only: real production pool activation and3 direct pool tests. A2 required before claiming full A validation.
- stage-A2-owner-cross-runtime-review: 3 paths, +410/-0; Sequential exact A1-to-full-A subdivision:8 owner/deadline and3 cross-runtime tests; no production semantics beyond A1.
- stage-B-process-final: 11 paths, +68/-20; Separate executable aggregation/diagnostic integration, depends on full A; existing watchdog test reference only.
- combined: 18 paths, +1180/-39; Full unvalidated A+B proposal; not recommended as a single adoption step.

Apply either full A or sequential A1 then A2, never both alternatives. A1 and A2 are review-size boundaries; full A is the required validation unit. B is disjoint from A and remains separately unadopted until reviewed validation/resources permit. Source after-images represent combined A+B, not a partially adopted checkout. Parent owner is354 authored lines; primary Task leaf141. The aggregate increase above800 is disclosed and chiefly due14 regressions, not hidden as separate completion claims. None was built/formatted/tested here.
