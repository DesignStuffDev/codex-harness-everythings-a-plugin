// Append to constructor_cross_runtime_tests.rs; reuse that module's imports and probe.
#[tokio::test(flavor = "current_thread")]
async fn canceled_cleanup_after_successful_disposal_is_settled() {
    #[derive(Debug)]
    struct CountedProbe(DisposalProbe, Arc<AtomicUsize>);
    impl std::fmt::Display for CountedProbe {
        fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
            std::fmt::Display::fmt(&self.0, formatter)
        }
    }
    impl std::error::Error for CountedProbe {}
    impl Drop for CountedProbe {
        fn drop(&mut self) {
            self.1.fetch_add(1, Ordering::AcqRel);
        }
    }

    let registry = Registry::new(/*capacity*/ 1);
    let lease = PoolLease::with_registry(Arc::clone(&registry));
    let drops = Arc::new(AtomicUsize::new(/*v*/ 0));
    let (disposed_tx, disposed_rx) = oneshot::channel();
    let probe = CountedProbe(DisposalProbe(Some(disposed_tx)), Arc::clone(&drops));
    let ticket = lease.start(move || {
        Err(BuildRouteAwareHttpClientError::CustomCa(BuildCustomCaTransportError::ReadCaFile {
            source_env: "CONSTRUCTOR_TEST_FIXTURE",
            path: "not-read-fixture.pem".into(),
            source: std::io::Error::other(probe),
        }).into())
    }).unwrap();
    let original = Arc::clone(&ticket.0);
    let deadline = tokio::time::Instant::now() + Duration::from_secs(/*secs*/ 5);
    tokio::time::timeout_at(deadline, original.native.join()).await.unwrap();
    let disposal_permit = original.disposal.poller.try_acquire().unwrap();
    drop(ticket);

    // Cleanup can attach disposal, but cannot pass its disposal.join() while
    // this test retains the sole poller permit.
    tokio::time::timeout_at(deadline, poll_fn(|cx| {
        let record = lock(&original.disposal.record);
        match &*record {
            Record::AwaitingHandle => {
                original.disposal.attachment_waker.register(cx.waker());
                Poll::Pending
            }
            Record::Running(_) => Poll::Ready(()),
            Record::Joined(_) | Record::SpawnFailed { .. } => {
                panic!("disposal must be attached and remain unobserved")
            }
        }
    })).await.unwrap();
    tokio::time::timeout_at(deadline, disposed_rx).await.unwrap().unwrap();
    tokio::time::timeout_at(deadline, poll_fn(|cx| original.disposal.poll_join(cx)))
        .await.unwrap();
    assert!(original.disposal.succeeded());
    assert_eq!(drops.load(Ordering::Acquire), 1);

    {
        let record = lock(&original.cleanup.record);
        let Record::Running(handle) = &*record else {
            panic!("cleanup must still be awaiting the disposal poller permit");
        };
        handle.abort();
    }
    drop(disposal_permit);
    tokio::time::timeout_at(deadline, original.cleanup.join()).await.unwrap();
    assert!(original.cleanup.cancelled.load(Ordering::Acquire));

    let expected = HttpConstructionObservation {
        retained: 0,
        pending: 0,
        failed: 0,
        joined: 1,
        cancelled: 1,
        recovery_attempts: 0,
    };
    assert_eq!(registry.wait_until(deadline.into_std()).await, expected);
    // Re-observation neither retries disposal nor counts its cancellation twice.
    assert_eq!(registry.wait_until(deadline.into_std()).await, expected);
    assert_eq!(drops.load(Ordering::Acquire), 1);
}
