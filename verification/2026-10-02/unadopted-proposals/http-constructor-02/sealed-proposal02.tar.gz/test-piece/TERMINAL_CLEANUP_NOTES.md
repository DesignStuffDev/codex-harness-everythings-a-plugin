# Additional terminal-cleanup test fragment

`terminal_cleanup_append.rs` appends one test to the combined proposal's
`constructor_cross_runtime_tests.rs`. It reuses that module's imports and
`DisposalProbe`; it is not a separate module. The original two-test source,
patch, notes, and manifest under this test-piece remain unchanged.

The test reserves the disposal task's sole poller permit before abandoning the
ticket. It positively observes disposal attachment, payload destruction, and
the exact disposal task's successful join. Cleanup remains blocked acquiring
that permit, so aborting its exact handle cannot race successful cleanup.
After releasing the permit and positively joining canceled cleanup, the receipt
must compact the job with one cancellation and no recovery attempt. A counted
payload and repeated receipt assert one destructor invocation and stable totals.

This tests the deliberate contract: successfully disposed output plus terminal,
positively joined canceled cleanup is settled custody. No process close is used.
No compiler, formatter, or test execution was performed.
