# Cross-runtime constructor recovery tests

Staged source only: no repository edits, compilation, tests, formatter, or runtime execution. Proposal 01 remains untouched.

Add `constructor_cross_runtime_tests.rs` as a child test module of `constructor_custody.rs`, using an explicit `#[path = "constructor_cross_runtime_tests.rs"]` attribute. This piece adds only that new file; owner production changes and module registration belong to the parent.

Two isolated capacity-one cases exercise actual separate Tokio runtimes:

1. Native output is positively joined on current-thread runtime A, then its ticket is dropped and the root future immediately returns without another await. A's queued async cleanup is canceled at runtime destruction. Runtime B's ordinary admission must trigger output disposal and make capacity reusable.
2. A's native output is positively joined, then its sole blocking worker is held by a channel. The test positively observes disposal-handle attachment, establishing queued disposal before `shutdown_background`. It releases and joins the held worker, then passively joins the canceled old disposal/cleanup handles on B. Ordinary B admission must recover and restore capacity.

The payload is a synthetic `BuildCustomCaTransportError::ReadCaFile` containing an owned `io::Error` source with a destructor signal. No CA file is read and no native panic is induced. Before B admission each case verifies the original output has not yet been disposed. The admission helper waits for the destructor signal before any registry observation or process-final operation, then passively joins the exact replacement tasks before demanding successful second admission. This avoids confusing destructor entry with completed disposal/cleanup.

Tests assume proposal-02 retains `Task::join`, `Job::{native,disposal,cleanup}`, `Task::{record,attachment_waker}`, and existing `Record` variants as agreed. They use `Registry::new`, `PoolLease::with_registry`, ordinary `PoolLease::start`, and `ConstructionTicket::wait`. No registry close or process-global mutation is used. Receipt fields other than `is_complete` are not assumed. Five-second waits bound fixture failures; no sleep establishes readiness.

Parent must statically bind these tests to its final recovery state machine before adoption. They are intended to fail proposal 01, whose captured runtime handle and sticky cleanup-start flag cannot recover the abandoned output after A stops.
