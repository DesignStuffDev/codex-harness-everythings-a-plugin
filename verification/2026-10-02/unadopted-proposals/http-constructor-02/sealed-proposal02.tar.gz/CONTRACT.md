# Native route-aware constructor custody: corrected proposal 02

Unadopted, unbuilt and unexecuted source proposal. Proposal01 is preserved unchanged; its cross-runtime cleanup-retention bug blocks native adoption. The unrelated watchdog test from01 was independently adopted/tested by root at checkpoint6446edf. It is an unchanged prerequisite, not included in this patch.

## Native contract

The existing `RouteAwareClientPool::client_for_url_with_resolver` blocking constructor remains the real implementation. Route selection, managed policy, auth, redirects, native/custom CA/TLS selection, serialized build permit, 16-entry cache and existing timeout expectations are preserved. A native constructor now captures cache/factory/build settings and a publication fence, never a public pool clone.

Public pool clones share a lease. A request timeout alone permits late cache publication/reuse while a public pool remains open. The last public lease closes only its local publication fence. Embedded processor A teardown does not acquire global HTTP/process-final authority, and existing manager catalog coalescing/accepted selectors remain unchanged.

A bounded process registry (256 retained records) owns exact native handles and their original typed results. A non-clone ticket joins in place and transfers the result with no later await. Native Build and BuildTask errors retain their original types. Local closed/capacity/runtime/ownership errors have a separate public Construction variant and no invented network-failure classification.

Cancellation marks a ticket abandoned. One retained async cleanup supervisor joins the exact native handle and admits a separately retained blocking disposer. Only the blocking disposer takes/destroys an abandoned client or error/panic payload; failed admission leaves the value retained. Canceled observers never remove/drop owned handles.

## Cross-runtime recovery

A Job does not retain its creator's Runtime Handle. Cleanup uses the current live runtime. Ordinary admission and observation drive compaction/recovery, so an old canceled cleanup does not require process-final shutdown to recover capacity.

Recovery is serialized per Job. It may replace an auxiliary generation only after positively polling/joining its prior cancellation (or a completed unit supervisor whose disposer was canceled). A running disposer is retained and observed in place. A queued canceled disposer is retried only after that exact cancellation and the old supervisor are joined. The original native result/handle is never reset. Spawn failure and panic uncertainty are never silently reset.

If there is no current runtime, custody remains retained for later admission/observation. One observation attempts cleanup once; it does not spin retries on a shutting-down runtime. B's first admission can temporarily report CapacityExceeded while it initiates asynchronous disposal of A's old result; a later retry can reuse capacity after exact disposal/cleanup joins. No new global runtime, OS reaper thread or processor-close behavior is introduced.

Receipts distinguish pending custody, panic/spawn failure, observed cancellations and recovery attempts. Canceled native tasks still deliver/dispose their exact JoinError. A positively joined cleanup cancellation AFTER separately successful disposal is settled custody: all exact handles are terminal, the output is gone, and the cancellation is recorded. It does not require duplicate disposal. Failed/panicked or unconfirmed records stay bounded/quarantined; clean terminal records compact while their counters persist.

## Process and transport boundary

The registry retains the FIRST process-close deadline. Repeated process-close objects/observers cannot renew it. Executable aggregation observes native constructors and existing curated/featured owners concurrently under the caller's existing deadline. No fresh grace interval is added.

This bounds async observation only. Running blocking constructors/disposers can outlive it, and Tokio Runtime::drop can still wait. The existing independent 200/205-second executable watchdog remains armed through arg0's native main/runtime join. Library A-to-B gains no such kill authority. Constructor join is not reqwest/Hyper task joining, socket closure, OS proxy resolver shutdown, synchronous Rustls fallback custody or durable storage confirmation. Those require separate process/native/EOF evidence.

No dependency, network policy, proxy, DNS, account, endpoint, persistent format or installed component wire protocol change is proposed. This is a native lifecycle prerequisite, not an independently installed HTTP plugin or a newly extracted functional family.
