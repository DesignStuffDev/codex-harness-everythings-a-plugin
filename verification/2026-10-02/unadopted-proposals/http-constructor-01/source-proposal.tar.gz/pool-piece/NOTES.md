# Native route-aware constructor integration — pool piece

Status: staged source only. No checkout edits, Rust compilation, tests, formatter, or linter execution. Parent supplied source checkpoint `f05b8b9f / 8936`; this piece binds the actual input bytes independently in `MANIFEST.json`.

## Scope

- Adds one shared `PoolLease` per original route-aware pool lineage; derived Clone and existing connection-cache sharing remain unchanged.
- Checks admission before route resolution, after resolution before either cache, and after acquiring the existing constructor mutex.
- Routes the actual native constructor through `PoolLease::start` and consumes the exact ticket result. Native `Build` and `BuildTask` errors remain intact; new typed `Construction` errors classify as no transport failure class.
- Moves only the factory, route class, fallback mode, builder, cache, build permit, route, and publication fence into the native closure. No pool/public-lease clone is captured.
- Preserves the existing build permit through construction and publication. Open public peers still permit successful publication after request cancellation.
- Publishes the route cache under the owner fence. Evicted and replaced clients leave both locks before destruction on the owned blocking constructor.
- Introduces no processor close, application cohort, new timing budget, policy bypass, or changed route-cache eviction rule.

## Owner dependency

The parent-provided `constructor_custody` module and public re-export of `HttpConstructionError` must land with this integration. This piece assumes the frozen `PoolLease::{new,with_registry,ensure_open,publication_fence,start}`, `ConstructionTicket::wait`, `PublicationFence::publish_if_open`, and isolated `Registry::{new,begin_close,wait_until}` contracts. Exact native-handle retention and abandoned-result disposal are supplied by that owner, not reimplemented here.

The synchronous rustls fallback constructor and platform proxy-resolution blocking task remain separate work. Constructor observations do not establish socket closure, reqwest-internal task joins, domain-task completion, or remote/durable effects. Existing cached clients are not purged by this patch.

## Focused tests staged, not run

The new sibling module has three tests:

1. Actual native construction returns its joined result and populates the route cache.
2. A canceled queued native construction publishes while a public peer survives, and cannot publish after the last public lease is dropped.
3. An isolated process-registry close rejects existing cached use and prevents a queued native construction from publishing its second route.

The latter two saturate a one-thread blocking pool with a channel barrier, poll the actual constructor once, and verify its build permit was acquired before cancellation/closure. Five-second waits are fixture failure bounds, not readiness sleeps or production budgets. Tests do not close the global registry.

`route_aware_client_pool_tests.rs` is preserved solely as an exact preimage: it is not in the patch. In particular, `managed_request_timeout_covers_queued_transport_construction` remains byte-for-byte unchanged and must pass after adoption. Proposed future scope is this new module plus that existing regression, followed by the required HTTP-client checks; no result is claimed here.
