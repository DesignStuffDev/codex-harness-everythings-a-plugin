# Review and serial adoption plan

This proposal is not a build, test, installed-component proof, upstream update pass, or P03 exit. The 17 proposed source/test/snapshot paths replace the actual native constructor's bare awaited blocking handle and add executable process-final observation. No repository file has been changed by this worker. No Rust command or runtime has been run for the proposal.

## Contract/compatibility review

`RouteAwareClientPoolError` gains a public `Construction(HttpConstructionError)` variant. Existing Build and BuildTask values retain their original nested native errors. This is a source-level exhaustive-match compatibility change for compiled Rust consumers and must be recorded in the coordinated host/component compatibility notes before publishing. The current repository's only exhaustive match on these variants is updated in `RouteAwareRequestError::failure_class`; no HTTP or network-policy classification is invented for local custody failures. No component wire schema, config, database, dependency, auth, endpoint or network-policy change is proposed.

The private pool lease deliberately preserves public clone lifetime and current manager selector coalescing. It does not add a processor-close method. Current `PluginsConfigInput::remote_plugin_service_config` lazily shares a selector; `RemotePluginServiceConfig::PartialEq` ignores selector identity; the catalog queue coalescer retains an old service config. A later processor/cohort boundary must define accepted queued work transfer explicitly before closing any such shared pool. Merely adding a cohort identity to the coalescing key would change behavior and is not this patch.

Construction has domain ownership in codex-http-client. The existing PluginStartupProcessShutdown is an executable composition seam and now aggregates all route-aware constructors. This intentionally does not move HTTP/cache/marketplace knowledge into the generic process-supervisor kernel. Embedded App Server replacement does not call the global fence. Existing manager accepted work remains alive until process-final authority closes the process. After closure, already-issued transport/client operations may still exist; constructor publication/selection fencing is not a universal request/socket cancellation guarantee.

The cleanup task and its blocking output disposer are registry-owned too. A canceled observer cannot take/drop any handle. If runtime destruction cancels the cleanup task, it retains native/disposal custody as an incomplete bounded record; this slice does not claim it can restart an already failed supervisor or join every external HTTP runtime. Process escalation, transport EOF and durability remain independent evidence.

## Focused native checks to run after root review/adoption

1. Use the repository's `just fmt` and `just test -p codex-http-client --lib` entrypoints, with the normal strict/source-binding runner. The 10 proposed HTTP tests are 7 in-memory native-custody concurrency/error/disposal tests plus 3 tests invoking the actual pool constructor/cache with isolated registries. One additional utils-process test checks independent watchdog expiry while a real Tokio runtime has unfinished blocking work. They make no external requests. They are not real-host or installed-component acceptance results.
2. Keep all existing `route_aware_client_pool_tests.rs` byte-identical, especially `managed_request_timeout_covers_queued_transport_construction`. Its requirement that an OPEN public pool can finish a timed-out build and reuse its route cache must still pass. Existing routing, managed policy, redirect credentials, TLS fallback and timeout tests must pass.
3. Run scoped `just test -p codex-core-plugins --lib` and the source-appropriate App Server integration test subset required by the ledger. Existing same-home curated/featured A-to-B replacement must pass unchanged. Constructor process-final changes must not be exercised as embedded teardown.
4. The executable aggregate changed, so rebuild the production CLI/manager and run current-source actual-host installed storage/migrations, GUI/session/recovery, launch normal/forced shutdown, held Git/API/auxiliary HTTP and featured postchecks with pinned binaries and unchanged strict/observer assertions. Receipt `http_constructor_process_shutdown_observed` should explicitly report native joined/retained/pending/failed counts. Exact current production source/binary binding is required; existing bbed/f05b host results do not validate the new constructor code.
5. Include the CLI/exec/TUI focused consumer checks still blocked by test-feature compilation ENOSPC. Successful production build or old focused receipts do not substitute for those tests. Do not retry with unchanged inadequate disk margins.
6. Run `just test -p codex-utils-process` for the proposed watchdog/runtime boundary test and existing deadline semantics. It is isolated test-clock evidence, not a production hard-exit pass.
7. Run scoped `just fix -p codex-http-client -p codex-core-plugins` with the repository workflow. Preserve any auto-fix transition and complete the applicable required format/lint checks. No complete workspace suite is authorized by this proposal.

## Real-host and failure gates still open

A bounded held native-constructor fixture at the real executable composition seam should prove process close rejects new construction, already accepted native construction stays owned, deadline expiry is unclean, and abandoned output disposal remains owned until it finishes. The new isolated native tests verify those mechanics but are not this whole-host gate. Current held HTTP EOF tests may not hold a constructor specifically, so their pass must not be described as direct proof of queued-builder deadline behavior.

No independently installed HTTP component has been created here. Future supervised native HTTP/provider components can own their reqwest internals inside a process boundary; this proposal does not require speculative Hyper changes or claim universal in-process transport joining. OS proxy resolver and synchronous Rustls fallback constructors remain separate inventory entries. Installed dependency/replacement contracts and the other P03 exits remain open.

## Source publication and staging

Root must compare every exact preimage in SOURCE_BINDING.json before applying the patch. Old R prototypes and current accepted work remain untouched. Run no commands from this proposal automatically. Preserve source, patch, manifest and audit notes as a new checkpoint before adoption. All files are ordinary staging artifacts under /tmp/p03-http-native-constructor-proposal-01, below the explicitly authorized 10 MiB cap; they are not an externally durable backup.


## Coherent serial review split

The full proposal is 868 added / 39 removed lines across 17 paths and exceeds the repository's 800-line review guideline. Preserve it as one contract but review/adopt serially:

- `stage-A-native-pool.patch`: 4 paths, 586 added / 19 removed lines before repository formatting. Activates real native pool constructor custody and cancellation disposal, includes 7 focused owner tests, and retains existing pool behavior/regression tests. The domain process-close API exists but executable aggregation is not activated yet. This is real native integration; it is not an independently installed HTTP component or complete process-final acceptance.
- `stage-B-process-final.patch`: 14 paths, 282 added / 20 removed lines, applies on A's exact after-images. Activates executable aggregation under the shared deadline, adds the 3 actual pool tests and independent runtime/watchdog test, and updates truthful caller diagnostics. CLI/TUI reuse four existing error-precedence tests with the actual production diagnostic and named snapshots. Four `.snap` files are **manual proposed expectations**, not generated/accepted test artifacts. Root must run and review them with the normal insta workflow; no snapshot output is claimed verified here.

The pool file is the only path touched by both stages; B adds its new test module declaration. If A's root-required formatting/lint changes that preimage, rebase B mechanically against its new hash rather than applying with fuzz or overwriting full-file after-images. `source/` contains the combined final proposed after-images, not the A-only tree. `STAGES.json` records each exact before/after hash and both patches. Do not publish A as proof that process-final integration B passed.

No formatter has run in this worker. Reported counts are exact authored patch counts, not a claim of post-rustfmt line counts. Root's formatter/linter may produce a preserved mechanical transition.
