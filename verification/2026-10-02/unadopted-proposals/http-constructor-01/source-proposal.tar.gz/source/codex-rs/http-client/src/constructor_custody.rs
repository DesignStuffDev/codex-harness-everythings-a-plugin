//! Own the route-aware native constructor, not reqwest's internal runtime or sockets.

use std::any::Any;
use std::future::Future;
use std::future::poll_fn;
use std::panic::AssertUnwindSafe;
use std::panic::catch_unwind;
use std::pin::Pin;
use std::sync::Arc;
use std::sync::Mutex;
use std::sync::MutexGuard;
use std::sync::OnceLock;
use std::sync::atomic::AtomicBool;
use std::sync::atomic::Ordering;
use std::task::Context;
use std::task::Poll;
use std::time::Instant;
use tokio::runtime::Handle;
use tokio::sync::Semaphore;
use tokio::sync::watch;
use tokio::task::JoinError;
use tokio::task::JoinHandle;

use crate::RouteAwareClientPoolError;
use crate::client::TransportClient;

type BuildOutput = Result<TransportClient, RouteAwareClientPoolError>;
const MAX_RETAINED_CONSTRUCTORS: usize = 256;

fn lock<T>(value: &Mutex<T>) -> MutexGuard<'_, T> {
    value.lock().unwrap_or_else(std::sync::PoisonError::into_inner)
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, thiserror::Error)]
pub enum HttpConstructionError {
    #[error("HTTP construction admission or publication is closed")]
    Closed,
    #[error("HTTP construction custody capacity is exhausted")]
    CapacityExceeded,
    #[error("HTTP construction runtime is unavailable")]
    RuntimeUnavailable,
    #[error("HTTP construction ownership is unconfirmed")]
    OwnershipUnconfirmed,
}

enum Record<T> {
    AwaitingHandle,
    Running(JoinHandle<T>),
    Joined(Option<Result<T, JoinError>>),
    SpawnFailed { _payload: Box<dyn Any + Send> },
}

struct Task<T> {
    record: Mutex<Record<T>>,
    poller: Semaphore,
    failed: AtomicBool,
    attachment_waker: futures::task::AtomicWaker,
}

impl<T> Task<T> {
    fn new() -> Self {
        Self {
            record: Mutex::new(Record::AwaitingHandle),
            poller: Semaphore::new(/*permits*/ 1),
            failed: AtomicBool::new(false),
            attachment_waker: futures::task::AtomicWaker::new(),
        }
    }

    fn attach(&self, spawned: std::thread::Result<JoinHandle<T>>) {
        *lock(&self.record) = match spawned {
            Ok(handle) => Record::Running(handle),
            Err(payload) => {
                self.failed.store(true, Ordering::Release);
                Record::SpawnFailed { _payload: payload }
            }
        };
        self.attachment_waker.wake();
    }

    fn poll_join(&self, cx: &mut Context<'_>) -> Poll<()> {
        let mut record = lock(&self.record);
        match &mut *record {
            Record::Running(handle) => match Pin::new(handle).poll(cx) {
                Poll::Pending => return Poll::Pending,
                Poll::Ready(result) => {
                    self.failed.store(result.is_err(), Ordering::Release);
                    *record = Record::Joined(Some(result));
                }
            },
            Record::AwaitingHandle => {
                self.attachment_waker.register(cx.waker());
                return Poll::Pending;
            },
            Record::Joined(_) | Record::SpawnFailed { .. } => {}
        }
        Poll::Ready(())
    }

    async fn join(&self) {
        let Ok(_permit) = self.poller.acquire().await else {
            return;
        };
        poll_fn(|cx| self.poll_join(cx)).await;
    }

    fn try_join(&self) {
        let Ok(_permit) = self.poller.try_acquire() else {
            return;
        };
        let finished = match &*lock(&self.record) {
            Record::Running(handle) => handle.is_finished(),
            Record::AwaitingHandle | Record::Joined(_) | Record::SpawnFailed { .. } => false,
        };
        if finished {
            let mut cx = Context::from_waker(futures::task::noop_waker_ref());
            let _ = self.poll_join(&mut cx);
        }
    }

    fn take(&self) -> Option<Result<T, JoinError>> {
        match &mut *lock(&self.record) {
            Record::Joined(result) => result.take(),
            Record::AwaitingHandle | Record::Running(_) | Record::SpawnFailed { .. } => None,
        }
    }

    fn joined(&self) -> bool {
        matches!(&*lock(&self.record), Record::Joined(_))
    }
}

struct Job {
    native: Task<BuildOutput>,
    disposal: Task<()>,
    cleanup: Task<()>,
    runtime: Handle,
    abandoned: AtomicBool,
    delivered: AtomicBool,
    cleanup_started: AtomicBool,
    changes: watch::Sender<u64>,
}

impl Job {
    fn changed(&self) {
        self.changes.send_modify(|revision| *revision = revision.wrapping_add(1));
    }

    fn start_cleanup(self: &Arc<Self>) {
        if self.cleanup_started.swap(true, Ordering::AcqRel) {
            return;
        }
        let job = Arc::clone(self);
        self.cleanup.attach(catch_unwind(AssertUnwindSafe(|| self.runtime.spawn(async move {
            job.native.join().await;
            if job.native.joined() {
                let disposal_job = Arc::clone(&job);
                // Admission failure must not drop a client or panic payload on
                // this async worker. The retained blocking task takes it itself.
                job.disposal.attach(catch_unwind(AssertUnwindSafe(|| {
                    job.runtime.spawn_blocking(move || drop(disposal_job.native.take()))
                })));
                job.disposal.join().await;
            }
            job.changed();
        }))));
        self.changed();
    }

    fn failed(&self) -> bool {
        self.native.failed.load(Ordering::Acquire)
            || self.disposal.failed.load(Ordering::Acquire)
            || self.cleanup.failed.load(Ordering::Acquire)
    }

    fn settled(&self) -> bool {
        self.native.joined() && (self.delivered.load(Ordering::Acquire)
            || (self.disposal.joined() && self.cleanup.joined()))
    }

    async fn settle(self: &Arc<Self>) {
        let mut changes = self.changes.subscribe();
        self.native.join().await;
        loop {
            if self.abandoned.load(Ordering::Acquire) {
                self.start_cleanup();
                self.cleanup.join().await;
                return;
            }
            if self.delivered.load(Ordering::Acquire) {
                return;
            }
            if changes.changed().await.is_err() {
                return;
            }
        }
    }
}

pub(super) struct ConstructionTicket(Arc<Job>);

impl ConstructionTicket {
    pub(super) async fn wait(self) -> Result<Result<BuildOutput, JoinError>, HttpConstructionError> {
        self.0.native.join().await;
        let output = self.0.native.take().ok_or(HttpConstructionError::OwnershipUnconfirmed)?;
        self.0.delivered.store(true, Ordering::Release);
        self.0.changed();
        Ok(output)
    }
}

impl Drop for ConstructionTicket {
    fn drop(&mut self) {
        if !self.0.delivered.load(Ordering::Acquire) {
            self.0.abandoned.store(true, Ordering::Release);
            self.0.start_cleanup();
        }
    }
}

struct RegistryState {
    closed: bool,
    records: Vec<Arc<Job>>,
    compacted: usize,
}

pub(super) struct Registry {
    state: Mutex<RegistryState>,
    capacity: usize,
}

impl Registry {
    pub(super) fn new(capacity: usize) -> Arc<Self> {
        Arc::new(Self {
            state: Mutex::new(RegistryState {
                closed: false,
                records: Vec::new(),
                compacted: 0,
            }),
            capacity,
        })
    }

    pub(super) fn begin_close(&self) {
        lock(&self.state).closed = true;
    }

    fn compact(state: &mut RegistryState) {
        let before = state.records.len();
        state.records.retain(|job| {
            job.cleanup.try_join();
            !job.settled() || job.failed()
        });
        state.compacted += before - state.records.len();
    }

    fn observation(&self) -> HttpConstructionObservation {
        let mut state = lock(&self.state);
        Self::compact(&mut state);
        HttpConstructionObservation {
            retained: state.records.len(),
            pending: state.records.iter().filter(|job| !job.settled()).count(),
            failed: state.records.iter().filter(|job| job.failed()).count(),
            joined: state.compacted + state.records.iter().filter(|job| job.native.joined()).count(),
        }
    }

    pub(super) async fn wait_until(
        self: &Arc<Self>,
        deadline: Instant,
    ) -> HttpConstructionObservation {
        let records = lock(&self.state).records.clone();
        let waits = records.iter().map(Job::settle);
        let _ = tokio::time::timeout_at(deadline.into(), futures::future::join_all(waits)).await;
        self.observation()
    }
}

fn process_registry() -> &'static Arc<Registry> {
    static REGISTRY: OnceLock<Arc<Registry>> = OnceLock::new();
    REGISTRY.get_or_init(|| Registry::new(MAX_RETAINED_CONSTRUCTORS))
}

#[derive(Clone)]
pub(super) struct PublicationFence {
    registry: Arc<Registry>,
    closed: Arc<Mutex<bool>>,
}

impl PublicationFence {
    /// The callback is synchronous and must not reenter this fence or registry.
    pub(super) fn publish_if_open<T>(
        &self,
        publish: impl FnOnce() -> T,
    ) -> Result<T, HttpConstructionError> {
        let state = lock(&self.registry.state);
        let closed = lock(&self.closed);
        if state.closed || *closed {
            return Err(HttpConstructionError::Closed);
        }
        Ok(publish())
    }
}

struct PublicLease(PublicationFence);
impl Drop for PublicLease {
    fn drop(&mut self) {
        *lock(&self.0.closed) = true;
    }
}

#[derive(Clone)]
pub(super) struct PoolLease(Arc<PublicLease>);

impl PoolLease {
    pub(super) fn new() -> Self {
        Self::with_registry(Arc::clone(process_registry()))
    }
    pub(super) fn with_registry(registry: Arc<Registry>) -> Self {
        Self(Arc::new(PublicLease(PublicationFence {
            registry,
            closed: Arc::new(Mutex::new(false)),
        })))
    }
    pub(super) fn publication_fence(&self) -> PublicationFence {
        self.0.0.clone()
    }
    pub(super) fn ensure_open(&self) -> Result<(), HttpConstructionError> {
        self.0.0.publish_if_open(|| ())
    }
    pub(super) fn start(
        &self,
        work: impl FnOnce() -> BuildOutput + Send + 'static,
    ) -> Result<ConstructionTicket, HttpConstructionError> {
        let runtime = Handle::try_current().map_err(|_| HttpConstructionError::RuntimeUnavailable)?;
        let mut state = lock(&self.0.0.registry.state);
        let closed = lock(&self.0.0.closed);
        if state.closed || *closed {
            return Err(HttpConstructionError::Closed);
        }
        Registry::compact(&mut state);
        if state.records.len() >= self.0.0.registry.capacity {
            return Err(HttpConstructionError::CapacityExceeded);
        }
        let job = Arc::new(Job {
            native: Task::new(),
            disposal: Task::new(),
            cleanup: Task::new(),
            runtime,
            abandoned: AtomicBool::new(false),
            delivered: AtomicBool::new(false),
            cleanup_started: AtomicBool::new(false),
            changes: watch::channel(0).0,
        });
        state.records.push(Arc::clone(&job));
        job.native.attach(catch_unwind(AssertUnwindSafe(|| job.runtime.spawn_blocking(work))));
        Ok(ConstructionTicket(job))
    }
}

/// Constructor custody only: no claim about reqwest tasks, sockets or durability.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct HttpConstructionObservation {
    pub retained: usize,
    pub pending: usize,
    pub failed: usize,
    pub joined: usize,
}
impl HttpConstructionObservation {
    pub fn is_complete(self) -> bool {
        self.pending == 0 && self.failed == 0
    }
}

/// Executable-only process fence. Never use for embedded processor replacement.
pub struct HttpConstructionProcessShutdown {
    registry: Arc<Registry>,
    deadline: Instant,
}
impl HttpConstructionProcessShutdown {
    pub fn begin(deadline: Instant) -> Self {
        let registry = Arc::clone(process_registry());
        registry.begin_close();
        Self { registry, deadline }
    }
    pub async fn wait_until(&self, deadline: Instant) -> HttpConstructionObservation {
        self.registry.wait_until(deadline.min(self.deadline)).await
    }
}

#[cfg(test)]
#[path = "constructor_custody_tests.rs"]
mod tests;
