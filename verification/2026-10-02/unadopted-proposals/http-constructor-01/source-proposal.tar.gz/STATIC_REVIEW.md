# Static review only

No compiler, formatter, test, process or runtime acceptance command has run for this proposal. The checkout and all frozen R proposals are untouched. Parent current host evidence remains f05b/bbed and does not validate these after-images.

Independent pool worker prepared the real constructor patch and three new tests, then reviewed the owner. Its frozen pool-piece manifest/patch are preserved. It found no source-level custody, attachment-wakeup, error-shape, lock-order or Rust-shape blocker. The parent worker independently reviewed that pool patch against the native timeout/cache behavior and exact constructor seam.

Reviewed invariants:
- A task handle stays inside its registry-owned Task record across queued and active observer cancellation. One semaphore permit controls polling; no state/data guard crosses await.
- AwaitingHandle registration holds the record mutex while registering an AtomicWaker. Attachment takes the same mutex, installs the handle/failure, then wakes; cleanup can start before its own handle attachment without losing an observer wake.
- A ticket transfers the original joined result synchronously and marks delivery before return. Cancellation starts one retained cleanup task. Abandoned clients/panic payloads are taken only inside the separately retained blocking disposal task; failed admission leaves output in the original record.
- Clean records compact; failed/unknown records stay bounded, including failed cleanup/disposal. Runtime shutdown can cancel an async cleanup without making it clean or detaching the native/disposal handles from the registry.
- Publication locks registry then local fence then route cache. The last public lease takes only its local fence. Evicted/replaced clients are returned by the short publication callback and dropped after those locks, on the native blocking worker. A builder captures no public lease.
- Managed route/policy/auth/TLS and existing timeout test assertions remain unchanged. The added local Construction error is unclassified as network failure. Process close and late public lease semantics remain distinct; accepted catalog coalescing is unchanged.
- Core aggregate includes constructor completeness and a separate count-only trace. App Server's detailed failure message includes constructor counts; CLI/exec/TUI error precedence is unchanged. Existing CLI/TUI error tests now stage snapshot expectations for the actual production diagnostic.
- Bounded async observation is explicitly separate from runtime drop. Current executable watchdog remains independently armed through arg0 runtime/native main join. Libraries gain no process-exit authority. No production constructor hard-deadline exit has been tested.

Remaining risks require root's review and native tests: compilation and lint, exact manual snapshot rendering, post-format patch rebinding, real executable constructor/disposal timeout and receipt coverage, and whole current-source host regressions. Stage A/B public error enum addition needs compatibility notes. No installed plugin family count increases from this custody correction.
