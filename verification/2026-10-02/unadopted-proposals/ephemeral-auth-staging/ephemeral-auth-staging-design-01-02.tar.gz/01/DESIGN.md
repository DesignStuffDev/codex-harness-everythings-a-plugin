# Buildable staging exploration for sealed Ephemeral caller B

This is a source-only staging design. No repository, formatter, compiler, tests, caches or runtime changed. Original A and B remain immutable. B manifest is 3d164963c6549e6798175c2cc6c06bb84c14cd480995a980d6bc705e78ff3ef2. Exact current42 preimages plus A remain the reference; new stages do not require A for their own changed paths. P1–P3 are proposed buildable changes, not proven compiled checkpoints.

## Applicable rule and correction

AGENTS.md:125–130 says non-mechanical changes should not exceed 800 total changed lines; complex changes should be under 500. If larger, explore reviewable stages and identify the smallest coherent first stage from actual dependencies/callers. The earlier B five-unit review partition did not meet that rule. No new permission is requested or implied by this exploration.

Sealed B is 1,536 changed lines: 815 outside dedicated tests/discovery and 721 in dedicated tests/discovery. The 815 includes test declarations embedded in manager.rs; it is not a claim that every line is complex algorithm logic. No numerical compliance claim is made from module sizes or excluding tests.

## Recommended first checkpoint: P1 (98 changed lines, unformatted)

Extract the existing native identity derivation into private `managed_identity_derivation.rs`. `CodexAuth::ensure_managed_chatgpt_agent_identity` calls the new live derivation method and immediately performs exactly its existing persistence when an optional record is returned. `DerivedIdentity` belongs to this neutral module, not the future ownership module.

Mechanical portion: move binding selection, existing-record registration, fresh registration and error classification. Logic-shape adaptation: return auth plus optional record, then immediately persist in the existing caller. This is intended behavior preservation; it is not certified as a purely mechanical diff. Both old lower CodexAuth and manager production calls still use the path. No Ephemeral capability, snapshot/COW behavior, new authority, guard bypass or unused publication hook activates.

Preserve complete-record no-save reuse, missing-task registration and save, full registration and save, fallback versus hard error classification, and the direct helper’s same-clone identity visibility. The existing code already performs persistence synchronously after each relevant await; P1 does not insert an await or callback between derivation and persistence. The independent source reviewer caught two missing sibling-module imports; they are fixed in P1. Compilation is still required.

Root adoption sequence: exact preimage check → apply P1 → required formatting → new source binding/resource admission → scoped `just test` and lint. Use the established grouped CLI+login feature context, exclude unrelated package tests by filter, retain existing test assertions. Useful first command: `just test -p codex-cli -p codex-login --lib -E 'package(codex-login) & test(chatgpt_auth_)' --test-threads=1`. The important existing tests include registration with reuse/readback, transient retry, registration and task retry exhaustion, and non-retryable failure. Broader login regression remains required before publishing the preparation as verified. No ownership completion claim follows.

## Subsequent preparations

P2 (43 changed lines) extracts owned token-record assembly into private `chatgpt_token_update::apply_refresh`, called immediately from current `persist_tokens`. Preserve load-before-assembly, missing-store error, default token creation, optional response fields, invalid ID-token error before save, timestamp after parsing, unrelated record fields, save and caller reload. Mechanical statement movement plus owned argument/return adaptation; no authority change. The helper is justified by the actual persistent caller now and the later conditional caller using identical assembly, not generic unused scaffolding. Existing refresh_without_id_token and integration success/partial/error preservation tests are the gates. Run scoped `just test`, never direct cargo test.

P3 (21 changed lines, optional) extracts `external_auth_record` while the existing raw `persist_external_auth` still calls it from live install/refresh flows. Error text and raw save-before-cache behavior remain. Existing missing-token-state/preparation-failure and source/install tests are the gates. This tiny preparation can be combined with P2 if useful (64 changed lines); it is not worth a separate ownership milestone claim.

All three patches are sequential, exact-preimage design patches, not live edits. STAGE_COUNTS.json records each before/after identity and classification. Existing A is separately meaningful raw revision bookkeeping, but its proposed 497-line unformatted diff also needs actual post-format size review and tests; it is not counted as already adopted or accepted.

## Exact residual and why the current B still needs redesign

After these legitimate preparations, the reconstructed complete B residual remains 1,500 changed lines: 779 outside dedicated tests/discovery and 721 in dedicated tests/discovery. The residual artifact is explicitly NOT adoption-ready. Its later external-record helper comment still describes the preceding preparation’s raw caller; revise that comment when designing a final activation, with new counts/hashes. No source semantics depend on the comment.

The smallest complete activation of this particular design still crosses the seven production paths: actual storage capability/decorator, retained-store Check implementation, source/install selection, shared owner/cache commit, native refresh and identity derivation capture, reload witnessing, and logout/revoke/post-logout publication. These are connected by manager→policy→map ordering and exact pre-await authority. Omitting a still-legacy native read-modify-write permits an old request to overwrite newer store state. Omitting reload witnessing admits old loaded state. Omitting conditional logout/revoke permits late deletion or resurrection. Installing only the shared commit helper is not complete caller activation.

This is not a proof that every possible redesign exceeds 500 lines. It shows that the exact audited B cannot honestly be called compliant after straightforward extraction. A new smaller implementation must produce a new exact residual, or a consciously reviewed atomic exception must explicitly retain its oversized status under the exploration guidance; neither follows automatically from this note. Recommended immediate action is P1, then P2 if useful, while B remains preserved and unadopted. Do not evade the limit with one-line compression, private APIs supplied only as unused future scaffolding, broad dead_code allows, disabled features, or partial writer activation.

Test-only checkpoints can be separately reviewed, but all required new adversarial tests must run on the complete candidate before conditional-caller acceptance. Landing future-failing assertions early by disabling them is not a staging solution. Adding genuinely passing native fixture/positive tests earlier may aid reuse, but does not reduce the 779-line production residual below the complex-change guidance and is not included as a fictitious savings.

## Acceptance queue before complete conditional-caller status

1. Complete and test each behavior-preserving preparation using existing source-bound scoped gates; retain its baseline and evidence.
2. Review a newly measured complete-cohort activation (or explicitly documented oversized atomic decision); include A, every actual writer/read-publication path and unchanged security boundaries. No partial ownership status.
3. Run all staged A/B causal tests plus retained login/provider regressions on that exact source. Full package/production/installed-adapter/GUI gates remain separate, and old host proof stays old-source proof.
4. Add cancellation tests before complete acceptance: hold a real refresh response only after receiving its full request; cancel/drop the actual caller future; prove cache/store unchanged, then demonstrate a new public operation can acquire custody and commit. Own fixture sockets/futures with one deadline. Do not infer HTTP transport shutdown or global quiescence from canceled auth future.
5. Add a post-logout reload supersession test before complete acceptance: use an existing synthetic agent-identity environment/fixture route (never sandbox variables) to make the real native reload await registration after local logout; acknowledge that actual request, then install a newer manager source, complete the old response and require the newer owner/cache/store to remain. If existing fixtures cannot expose that precise phase without invasive hooks, record the missing seam and do not substitute a stamp-comparison unit test or timing sleep.
6. Finish original B gaps: native error/permanent response races, absent-store rejection, first runtime registration, capacity error propagation and poison/domain-remap behavior within the stated contract. Mixed persistent cleanup-error and same-home examples are proposed tests only, not passes.

Persistent File/Keyring/Auto CAS, cross-process coordination, request-dispatch revocation and full plugin extraction remain outside this process-local prerequisite. All scheduling and test acceptance are root-owned; this artifact author ran no tests.
