# Required checks — all future, none executed for this proposal

Use actual public AuthManager/external-provider callers and the real Ephemeral adapter. Reuse existing held-provider fixtures with causal Notify/Semaphore barriers; no arbitrary sleeps, credential dumps or weakening existing assertions. Keep tests in descriptive sibling files. A 5s absolute fixture deadline is a failure bound, not evidence of ordering; successful barriers establish ordering.

1. **Source and intent races:** hold install/refresh A, commit B with equal credentials and then reinstall the same provider Arc A; release the old result. Assert stale error, current source/cache/store unchanged, and no stale notification. Retain latest-install intent tests and both permanent-error public paths from the unadopted dependency.
2. **Storage ABA and all writer entrypoints:** hold a conditional operation; execute raw equal save, absent-delete/create/delete, and same-home second-manager mutation. The old operation rejects despite equal bytes/absence. Different homes proceed independently. Raw new explicit save after delete remains allowed.
3. **Real logout interval:** drive held refresh and actual manager logout, prove delete+clear linearization without a test-only check followed by a separate save. Cover no active provider, absent record, pending install, and post-logout stamped reload racing a later install. Conditional operations carrying pre-logout authority stay unable to republish. Explicit replacement login remains distinct: an already-running browser/device flow may initiate a new raw save after logout, as CONTRACT item 7 states; this slice does not claim that whole flow was canceled.
4. **Revoke and managed failure:** hold remote revoke, install B, release revoke; neither manager nor free Ephemeral logout may delete B. Inject configured-store deletion failure and assert error plus settled local Ephemeral revocation, no error-path reload, no rollback. Preserve workload-identity rejection and legacy successful bool results.
5. **Native RMW:** pause native token refresh and agent-record derivation before response, replace credentials through another manager/raw save, then release. Exact old Ephemeral ticket must reject; no latest-record patch, stale state publication or equality workaround. Check successful uncontended behavior too.
6. **Cancellation/locks/capacity:** cancel held provider observer before commit, exercise opposing state→store access through real callers, verify no deadlock/wakeup/drop under map, and check empty-entry compaction with live/current/stale tickets plus explicit capacity failure. A test timeout must fail; never equate dropped futures with closed HTTP transport.
7. **Telemetry and compatibility:** one logical load/save/delete attempt where expected, wrapper delegation preserved, no credentials in errors/events. Existing public synchronous replacement/delete semantics remain; test any intentionally changed logout error behavior. If user-visible messages change, add required snapshot coverage.

Root may adapt the already-approved grouped feature selection after new source/resource binding:

```
just test -p codex-cli -p codex-login --lib -E 'package(codex-login) & test(ephemeral_)'
just test -p codex-cli -p codex-login --lib --test all -E 'package(codex-login)' --test-threads=1
```

The first filter is a proposed naming convention, not a currently existing passing selection. Confirm discovered test names before execution. Keep repo `just test`, profile retries/timeouts and sandbox guards; never replace with direct cargo test. Run scoped formatting/lint per AGENTS. Broader workspace suite requires its existing separate authorization rule. No dependency changes are proposed; any eventual change requires the repository Bazel lock workflow.

Actual host follow-up must rebuild the modified source, then run selected auth/provider replacement, session recovery, storage, GUI and process shutdown regressions with exact source/ELF binding. In-app Browser remains unavailable in this cloud environment; distinguish a real Chromium fallback from Browser manual checks. This design runs no UI, network, backend, compiler or runtime checks.

Release limits: this slice still does not demonstrate durable File/Keyring/Auto CAS, dispatch-grant revocation, standalone auth/storage installation, real upstream update integration/rollback, or completion of P03/all-harness extraction.
