# Ephemeral conditional auth mutation proposal

**Design only; no patch or execution.** This is the finite caller contract for the next process-local conditional-write slice, grounded in actual source and the unadopted permanent-refresh-failure dependency. Read CONTRACT.md, IMPLEMENTATION.md and ACCEPTANCE.md in that order.

Current Ephemeral storage has a mutex but no revision. External success saves before cache/source validation; logout has a delete→clear interval; native refresh and agent identity also write the same backend. Activating only a version counter or only the external refresh path would not close that caller set. This package therefore stages the exact coherent implementation cut and tests instead of presenting a partial primitive as complete ownership.

The active checkout was not changed. `preimage/` contains targeted recorded0742 source; `unadopted-refresh-dependency/` contains separately preserved source-only proposal bytes, never current-code or passing-test evidence. The existing source candidate's status string predates the later accepted reload checks; this proposal does not re-run or relabel those checks. MANIFEST.json pins this package. It is a recovery artifact inside this VM, not an externally durable backup.
