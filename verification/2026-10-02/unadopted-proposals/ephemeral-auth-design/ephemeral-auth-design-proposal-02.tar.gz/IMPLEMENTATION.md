# Proposed implementation cut and source lineage

No source patch is staged. This is the concrete next code plan, not adopted behavior. Read `SOURCE_BINDING.json` before using the exact current preimages. The three preserved refresh afterimages are unadopted prerequisites and must be rebased/accepted separately; never overwrite newer source with them.

| Existing path/symbol | Required change / reason |
| --- | --- |
| `login/src/auth/storage.rs:543` `EPHEMERAL_AUTH_STORE`, `EphemeralAuthStorage`, `with_store` | Replace unversioned map with private versioned Ephemeral implementation. Move new logic into a sibling module; keep existing key derivation and load/save/delete adapters. All mutations, including absent delete, advance identity. |
| `storage.rs:175` `AuthStorageBackend`; `storage_telemetry.rs:73` `ObservedStorage` | Choose one named private capability/snapshot operation for native RMW callers; preserve trait-object use and wrapper delegation. Unsupported persistent conditional operations must be explicit, never silently unconditional. Emit telemetry outside map/manager/policy locks and preserve one logical operation count. |
| `auth_source.rs:80` `install_external_auth`; `:162` `commit_external_auth`; `:168` `persist_external_auth` | Replace save-before-owner-check with prepared conditional mutation combined with owner commit. Capture install ticket before resolve and refresh ticket before refresh. Preserve InstallContext intent behavior and workload-identity restriction. |
| `auth_reload.rs:127` `replace_auth_owner` | Factor the synchronous prepared commit into a small sibling owner module if needed. Keep actual equality/preparation before map and policy acquisition order. Atomic cache/source/store publication; clear-with-no-provider must support explicit logout mutation. Avoid a closure that can reenter storage. |
| `manager.rs:2996/3009` manager logout/revoke; `:1017/1030` free logout/revoke; `:1505` `logout_all_stores` | Distinguish raw backend intent from manager source revocation. Make manager Ephemeral delete+clear one commit; guard return from revoke await and final reload. Keep managed cleanup error visible without restoring revoked local auth. |
| `manager.rs:3123` `refresh_and_persist_chatgpt_token`; `:1642` `persist_tokens` | For Ephemeral, take record/revision before request and use that exact snapshot for patch/conditional save; never patch the new owner's latest loaded record with an old response. Review local auth-state publication on rejection. Persistent adapters remain legacy, not claimed transactional. |
| `manager.rs:774/963/971` agent-identity caller/helper | Carry the Ephemeral snapshot from before the record-producing await/operation. Preserve state→map order, reject changed storage, and do not publish stale state. Exact upstream call must be inspected before implementation to establish where derivation begins. |
| `manager.rs:1192` `save_auth` + login wrappers; `server.rs:833` `persist_tokens_async` | Version-advancing explicit writes continue through the common adapter. Existing spawn_blocking login lifetime is not transformed by a map CAS; do not claim it settled by cancellation. |
| `auth_acquisition.rs` / `workspace_policy.rs` | Preserve existing semantics. Reads may need a coherent ticket helper, but returned credentials are still not a request-dispatch grant. Policy poison notification must occur before map lock. |

The initial read identified no direct bypass of the global Ephemeral map outside storage.rs. The four production trait mutation entrypoints are `persist_agent_identity_record`, `save_auth`, `persist_tokens`, and raw `logout`. The native RMW paths are why only modifying external install/refresh is not a complete activation cut.

All original symbols above derive from the pinned Apache-2.0 upstream at `d42056091aded7feb1d88ac7e83972108b2aa478` except custom `auth_source`/`auth_reload` ownership adapters. Those adapters are intentional custom changes; exact current bytes and the recorded upstream audit are included. This package does not independently reconstruct upstream bytes or claim upstream equivalence.

## Reviewable implementation order

A. Add private versioned Ephemeral primitives and direct save/delete participation, plus actual storage tests; keep conditional manager activation off until B. This is a prerequisite and not a new extracted component or complete security fix.

B. In one coherent activated caller slice, integrate external install/refresh, native Ephemeral RMW, and manager/free logout paths with the above authority rules. If this exceeds the repository's 500 complex/800 total line guidance, split separate review patches but activate only after the complete slice and tests land. Prefer private modules and explicit exports; do not grow manager.rs with a generic transaction framework.

C. Verify callers, full scoped login regression and affected provider/host paths. Rebuild the production host before claiming changed-runtime GUI/plugin proof. Preserve old source-specific evidence as historical. Durable backend transactions, request-dispatch fencing, plugin wire interface and independently installed auth storage remain later gates.

## Resolved choices and remaining implementation obligations

- Choose retained revision identity; preserve home key compatibility and source/cache/policy/install semantics.
- Choose manager→policy→map order, with state reads before map and trait drops afterward.
- Choose explicit local revocation before mixed persistent cleanup; partial persistent failure is not rollback.
- Implementation must select/test a finite empty-entry admission policy and audit exact agent-record derivation before carrying tickets. Neither is declared implemented here.
- Existing public `clear_external_auth()` returns void. Preserve its cache/source-only meaning; do not imply durable settlement or change public API silently.
- File/Keyring/Auto and cross-process writers cannot be covered by this mutex. Legacy/external writers bypassing future durable generation cannot be detected using equal payloads; no guarantee is offered for them.
