# Ephemeral auth conditional mutation — proposed caller contract

DESIGN ONLY. This package contains no Rust patch and claims no new extraction or passing test. It binds reload source `0742356b…` and preserves the unadopted permanent-refresh-failure proposal as an explicit future dependency. The current implementation remains unchanged.

## Decision and smallest honest scope

Use the existing process-local Ephemeral store as the first conditional credential-write implementation. Source/policy belongs to the auth manager; value/revision belongs to storage. A coordinator inside `codex-login` combines their local commits without adding a new host responsibility or another built-in service. Do not claim File/Keyring/Auto durability, cross-process exclusion, request-dispatch authority, or separately installed auth storage from this step.

A counter plus external refresh patch is insufficient: current logout deletes before clearing the source, a managed-store error skips that clear, and native token/identity read-modify-save paths may also target Ephemeral. This proposal therefore specifies the complete caller cut before code. Land it in reviewable patches only if the final activation patch includes every relevant caller; an unactivated storage primitive is not acceptance.

## Storage contract

Keep `compute_store_key` compatibility. Resolve the actual home key before locks; snapshots carry that resolved domain. Re-resolve before commit outside locks and reject a different key; do not reinterpret the ticket for a new home. A filesystem change after resolution remains outside this process-local key contract; no filesystem identity or security guarantee is invented.

A snapshot owns an opaque `EphemeralRevision` with retained identity and a `Present(AuthDotJson)` or `Absent` value. Use fresh `Arc` identity, not credentials, mtime, pointer address without retained ownership, or a resettable numeric sequence. Every accepted mutation advances revision, including an equal save and absent delete. A stale ticket never retries using a newly captured revision.

Recommended private operation shapes (names are proposed, not existing APIs):

- `EphemeralSnapshot { domain, revision, value }`.
- `EphemeralMutation::{Replace(AuthDotJson), Delete}`.
- `PreparedAuthCommit::{CacheOnly, Ephemeral { expected, mutation }}`.
- `EphemeralCommitError::{StaleRevision, DomainChanged, StoreUnavailable, CapacityExceeded}`; manager also retains existing source/cache/policy errors.
- A typed committed outcome carries the successor revision and whether a value was removed. Preserve public `io::Result<bool>` logout compatibility through an adapter; do not add opaque boolean control arguments.

A shared map contains only current entries, never a per-operation/history ledger. Empty entries may be pruned only when their current revision has no external ticket; tickets for older revisions still cannot equal any newly allocated revision. Implement a bounded empty-entry admission/sweep policy and explicit capacity error before activation. Do not evict values or active tickets to make room. Record the chosen limit and test it; present credential retention remains a separately existing resource policy. Ticket cancellation drops observation ownership; there is no detached Ephemeral writer.

## Linearization and lock order

The verified compatible order is **manager inner write guard → workspace policy guard → Ephemeral map**. Existing `persist_agent_identity_record` holds auth state before storage; therefore manager credential equality/token extraction must finish before map acquisition. `workspace_policy::lock_current` has a poison/unavailable path that can notify watchers, so obtain it before the map too.

Prepare payloads, replacement identities, resolved keys and retired-value slots before the final map critical section. Under the map: compare the exact revision, swap the prepared value/revision and manager-owned source/cache/intent fields, retain old values, then release the map and policy. No callbacks, awaits, recursive public save/replace calls, notifications, telemetry, auth-state reads, or arbitrary trait destructors under that map. Existing manager notification order can remain after these guards. Release the manager before dropping retired trait-backed values. No partial publication if any validation fails.

The storage module should expose only a private concrete guarded operation to its sibling owner coordinator, not a generic callback API available to plugins. Public/raw save and delete acquire only the map and do not take manager/policy/auth-state locks. The implementation must explicitly prove these two orders cannot form a cycle.

Install uses existing `InstallContext` (latest intent + source + cache + policy) AND the pre-provider storage ticket. Do not replace it with a source-only check. Refresh uses committed source/cache/policy and a storage ticket, retaining the selected provider across await. A pending install does not by itself revoke an operation of the still-committed source; the actual winning commit does.

## Caller semantics and compatibility

1. External install and refresh capture their storage authority before provider await. Success validates all ownership and publishes cache/source plus any Ephemeral replacement at one local commit. Nonpersisted headers/API credentials use explicit `CacheOnly` but keep source/cache/policy checks. Their caller context separately retains and validates the pre-provider Ephemeral ticket under the same map guard; `CacheOnly` means no storage mutation, not exemption from storage-authority validation. The failure-only dependency retains its conditional permanent-error publication; it does not establish successful-write safety.
2. Exported synchronous `save_auth` and raw `logout` keep explicit replacement/delete intent at invocation. They advance the domain revision even on equal/absent writes, invalidating older conditional operations. A new explicit login after delete may succeed. This is not universal revocation of every other manager sharing a home.
3. Manager logout must atomically delete Ephemeral and clear its source/cache/install intent. The current `ClearExternal` early return when no provider is installed must not skip that storage transaction. Do not change standalone public `clear_external_auth` into a durable delete; its existing source revocation remains distinct.
4. Manager logout-with-revoke captures authority before the remote revoke await. If another source wins meanwhile, return a typed stale operation without deleting it. Raw free logout-with-revoke can fence the Ephemeral version but cannot clear a manager it does not own. Preserve workload-identity denial.
5. Recommended mixed-store ordering: commit Ephemeral revocation plus this manager's clear first, then perform configured File/Keyring/Auto cleanup outside all local guards. A configured-store failure remains an error and does not roll back/repopulate the revoked local source. This changes today's skip-clear-on-error behavior deliberately and requires tests/documentation. It does NOT make persistent cleanup transactional. After successful persistent cleanup, any reload must use the post-logout source/cache stamp so it cannot overwrite a later install. Do not introduce a reload on the error path.
6. `persist_tokens` and agent-identity mutation must preserve a snapshot from before the asynchronous operation/record derivation, not load the latest record after the response and then acquire a fresh ticket. Their Ephemeral commit rejects stale authority. Retained auth-state publication must not pretend storage success on a conflict. Persistent modes keep explicitly labeled legacy behavior pending durable coordination.
7. Initial native login wrappers and browser/device persistence remain explicit login writers, all routed through version-advancing save. This does not claim logout cancels an entire already-running browser/device flow; that larger admission/lifecycle contract requires a login-start ticket before exchange. Do not label such late explicit login a safely canceled operation.

No locks span provider/network awaits. Ephemeral commit is synchronous and short; cancellation before it makes no write, and cancellation after it cannot undo a committed write. Panic/poison is an explicit unavailable state, not recovery success. These properties do not bound provider HTTP transport or runtime exit.

## Later component contract

Keep the local revision and conditional-result vocabulary separable from the auth source contract. A future versioned credential-storage plugin owns persistence/recovery and returns opaque bounded domain/operation handles; auth owns source/policy. Kernel owns grants, framed transport, process supervision and deadlines. The existing host leaf broker forbids recursive selected-component invocation; do not bypass it to create auth→host-leaf→storage recursion. Peer dependency negotiation and durable File/Keyring/Auto transactions remain distinct roadmap gates.
