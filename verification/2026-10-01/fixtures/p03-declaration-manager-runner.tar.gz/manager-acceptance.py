"""Actual manager compatibility/rejection gate; no broker activation or builds."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, '/workspace/codex-harness-everythings-a-plugin/component-sdk/tests/file_search')
from acceptance_support import Runner, fingerprint, inventory, require, same_content, write_report

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--manager', type=Path, required=True)
parser.add_argument('--artifact-receipt', type=Path, required=True)
parser.add_argument('--worker-proof', type=Path, required=True)
parser.add_argument('--work-dir', type=Path, required=True)
args = parser.parse_args()
manager = args.manager.resolve(strict=True)
receipt_path = args.artifact_receipt.resolve(strict=True)
proof_path = args.worker_proof.resolve(strict=True)
receipt = json.loads(receipt_path.read_text())
proof = json.loads(proof_path.read_text())
build_path = Path(receipt['source_report']).resolve(strict=True)
build = json.loads(build_path.read_text())
require(build['status'] == 'finished' and build['returncode'] == 0
        and build['scoped_source_unchanged'] and build['source_before'] == build['source_after'],
        'manager build must have succeeded without source changes')
require(hashlib.sha256(build_path.read_bytes()).hexdigest() == receipt['source_report_sha256'],
        'manager build receipt source mismatch')
artifact = receipt['artifacts'][0]
manager_before = fingerprint(manager)
require(artifact['name'] == 'codex-component' and artifact['path'] == str(manager)
        and artifact['sha256'] == manager_before['sha256'] and artifact['bytes'] == manager_before['bytes'],
        'manager artifact differs from build receipt')
require(proof['passed'] and proof['evidence_kind'] == 'independent_source_build'
        and proof['source_parked_before_runtime'], 'independent native package proof missing')
require(not (Path(proof['artifact_directory']) / 'source').exists(), 'old source parking lost')
package = Path(proof['package_path']).resolve(strict=True)
package_before = inventory(package)
require(package_before == proof['package_files'], 'preserved worker package changed')
inputs_before = {str(p): fingerprint(p) for p in [receipt_path, build_path, proof_path, Path(__file__)]}
work = args.work_dir.resolve()
require(not work.exists() and Path('/workspace/codex-harness-everythings-a-plugin') not in work.parents,
        'work directory must be new and outside the checkout')
work.mkdir(mode=0o700)
home = work / 'home'
home.mkdir()
report_path = work / 'manager-acceptance.json'
report = {'passed': False, 'evidence_kind': 'real_manager_plain_package_and_inactive_service_rejection',
          'commands': [], 'manager_before': manager_before, 'inputs_before': inputs_before,
          'worker_proof': str(proof_path), 'scope': 'Actual installation/catalog only; no broker or service execution.'}
runner = Runner(work, report, report_path)
environment = dict(os.environ, CODEX_HOME=str(home))
management = [manager, '--codex-home', home]
try:
    plain = work / 'plain-package'
    shutil.copytree(package, plain)
    require(same_content(inventory(plain), package_before), 'plain install input differs')
    manifest = json.loads((plain / 'codex-component.json').read_text())
    plugin_id = manifest['id']
    require(plugin_id == 'native.file-search-local', 'unexpected preserved native package')
    runner.run('plain-install', [*management, 'install', plain], cwd=work, environment=environment)
    runner.run('plain-select', [*management, 'select', 'file_search', 'default', plugin_id], cwd=work, environment=environment)
    output, _, _ = runner.run('plain-list', [*management, 'list'], cwd=work, environment=environment)
    settings = json.loads(output)
    require(settings['selections']['file_search:default'] == plugin_id, 'plain selection missing')
    installed = home / 'components/objects' / settings['installed'][plugin_id]
    require(same_content(inventory(installed), package_before), 'installed plain package content differs')
    before_rejections = inventory(home)
    rejected = []
    for presence in ['required', 'optional']:
        source = work / ('declared-' + presence)
        shutil.copytree(package, source)
        declaration = json.loads((source / 'codex-component.json').read_text())
        declaration['components'][0]['service_requirements'] = {
            'version': 1, 'services': [{'name': 'host.diagnostic', 'version': 1,
                                      'operations': ['read'], 'presence': presence}]}
        (source / 'codex-component.json').write_text(json.dumps(declaration, indent=2) + '\n')
        _, errors, entry = runner.run('reject-' + presence, [*management, 'install', source],
                                     cwd=work, environment=environment, expected_status=1)
        require('host service requirements are not supported by this host' in errors,
                'service declaration was not rejected by the actual inactive catalog guard')
        require(inventory(home) == before_rejections, 'rejected installation changed existing catalog/package state')
        rejected.append({'presence': presence, 'status': entry['status'], 'home_unchanged': True})
    output, _, _ = runner.run('list-after-rejections', [*management, 'list'], cwd=work, environment=environment)
    require(json.loads(output) == settings, 'rejection changed existing selection')
    runner.run('plain-remove', [*management, 'remove', plugin_id], cwd=work, environment=environment)
    output, _, _ = runner.run('list-after-removal', [*management, 'list'], cwd=work, environment=environment)
    removed = json.loads(output)
    require(plugin_id not in removed['installed'] and plugin_id not in removed['enabled']
            and 'file_search:default' not in removed['selections'], 'plain removal left activation behind')
    require(same_content(inventory(installed), package_before), 'removal changed immutable package content')
    report.update(passed=True, rejections=rejected, plain_install_select_remove=True,
                  selected_catalog_unchanged_after_rejections=True, immutable_object_retained=True)
except Exception as error:
    report['error'] = f'{type(error).__name__}: {error}'
finally:
    report['manager_after'] = fingerprint(manager)
    report['inputs_after'] = {str(p): fingerprint(p) for p in [receipt_path, build_path, proof_path, Path(__file__)]}
    report['original_package_unchanged'] = inventory(package) == package_before
    if (report['manager_after'] != manager_before or report['inputs_after'] != inputs_before
            or not report['original_package_unchanged']):
        report.update(passed=False, preservation_error='bound input changed during manager acceptance')
    write_report(report_path, report)
print(report_path)
raise SystemExit(0 if report['passed'] else 1)
