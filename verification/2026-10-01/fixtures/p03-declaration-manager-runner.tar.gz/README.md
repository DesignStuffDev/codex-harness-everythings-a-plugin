# P03 declaration manager acceptance source

Exact source of the completed eight-command manager installation/catalog test.
See P03_SERVICE_DECLARATIONS_MANAGER_EVIDENCE.md and its results JSON. This
source-only archive includes no executables, state, credentials or private logs.
VM paths and artifact receipts require reviewed restaging elsewhere; preserve
all provenance, rejection and cleanup assertions. It is not a runtime bundle.
