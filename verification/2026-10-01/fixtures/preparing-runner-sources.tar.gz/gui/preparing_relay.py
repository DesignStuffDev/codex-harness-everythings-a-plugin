#!/usr/bin/env python3
"""Test-only byte-preserving relay. Staged/unexecuted; not a production plugin.

Hold exactly one genuine successful Open response selected by a private marker.
Forward every other frame unchanged, especially the same-lease release receipt.
The native lease is Ready while the host remains Preparing. See README.md.
"""

import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import selectors
import stat
import subprocess
import sys
import time

LINE_CAP = 4 * 1024 * 1024
BODY_CAP = 1024 * 1024
TOTAL_CAP = 8 * 1024 * 1024
HOLD_CAP = 2 * 1024 * 1024
MAX_ACTIVE = 64
MAX_EVENTS = 2048
OPEN = "file_search/open"
RELEASE = "file_search/release"


def require(condition, reason):
    if not condition:
        raise RuntimeError(reason)


def regular_marker(path):
    try:
        mode = path.lstat().st_mode
    except FileNotFoundError:
        return False
    require(stat.S_ISREG(mode), "control marker must be a regular file")
    return True


class Messages:
    """Observe complete bodies without changing any physical wire frame."""

    def __init__(self):
        self.active = {}
        self.reserved = 0

    def frame(self, frame):
        kind = frame.get("type")
        if kind in ("request_start", "result_start"):
            identity = frame.get("id")
            count = frame.get("bytes")
            require(type(identity) is int and identity > 0, "invalid frame id")
            require(type(count) is int and 0 <= count <= BODY_CAP, "body ceiling")
            require(identity not in self.active, "duplicate active frame id")
            require(len(self.active) < MAX_ACTIVE, "active message ceiling")
            require(self.reserved + count <= TOTAL_CAP, "assembly byte ceiling")
            self.active[identity] = [frame, bytearray(), 0]
            self.reserved += count
        elif kind == "chunk":
            header, body, chunks = self.active[frame["id"]]
            require(frame.get("index") == chunks, "chunk index mismatch")
            decoded = base64.b64decode(frame["data"], validate=True)
            require(len(decoded) <= 192 * 1024, "chunk byte ceiling")
            require(len(body) + len(decoded) <= header["bytes"], "body overflow")
            body.extend(decoded)
            self.active[frame["id"]][2] += 1
        elif kind == "end":
            header, body, chunks = self.active.pop(frame["id"])
            self.reserved -= header["bytes"]
            require(frame.get("chunks") == chunks, "end chunk count mismatch")
            require(len(body) == header["bytes"], "incomplete message body")
            value = json.loads(body)
            require(isinstance(value, dict), "message is not an object")
            return header, value
        elif kind == "error":
            raise RuntimeError("unexpected component transport error")
        else:
            require(kind in ("shutdown", "shutdown_complete"), "unknown wire frame")
        return None


class Evidence:
    def __init__(self, directory, child_pid):
        self.directory = directory
        directory.mkdir(mode=0o700)  # Fresh home per run; never overwrite evidence.
        self.events = 0
        self.child_pid = child_pid

    def write(self, name, **fields):
        self.events += 1
        require(self.events <= MAX_EVENTS, "evidence event ceiling")
        value = {"event": name, "sequence": self.events,
                 "monotonic_ns": time.monotonic_ns(),
                 "relay_pid": os.getpid(), "native_pid": self.child_pid, **fields}
        payload = json.dumps(value, sort_keys=True).encode() + b"\n"
        require(len(payload) <= 8192, "evidence row ceiling")
        path = self.directory / f"{self.events:04d}-{name}.json"
        temporary = self.directory / f".{self.events:04d}.pending"
        with temporary.open("xb") as stream:
            stream.write(payload)
        os.link(temporary, path)
        # Named single occurrence milestones. Repeated request/reply events only
        # use numbered files; no atomic replacement of earlier proof.
        if name not in ("request", "reply"):
            os.link(temporary, self.directory / (name + ".json"))
        temporary.unlink()


class Relay:
    def __init__(self, child):
        self.child = child
        self.selector = selectors.DefaultSelector()
        self.child_input_fd = self.child.stdin.fileno()
        self.child_output_fd = self.child.stdout.fileno()
        self.queues = {self.child_input_fd: bytearray(), 1: bytearray()}
        self.buffers = {0: bytearray(), self.child_output_fd: bytearray()}
        self.live_reads = set(self.buffers)
        self.readers = {fd: Messages() for fd in self.buffers}
        self.first = {fd: True for fd in self.buffers}
        self.evidence = None
        self.target = None
        self.target_identity = None
        self.target_budget = None
        self.service_limits = None
        self.shutdown_sent = False
        self.shutdown_complete = False
        self.held = bytearray()
        self.held_complete = False
        self.held_fingerprint = None
        self.held_forwarded = False
        self.forward_pending = False
        self.release_id = None
        self.release_joined = False
        self.methods = {}
        self.host_eof = False
        self.child_input_closed = False
        for fd in (*self.buffers, *self.queues):
            os.set_blocking(fd, False)
        self.started = time.monotonic()

    def enqueue(self, fd, raw):
        queue = self.queues[fd]
        require(len(queue) + len(raw) <= TOTAL_CAP, "pipe queue ceiling")
        queue.extend(raw)

    def complete(self, from_host, header, body):
        identity = header["id"]
        if from_host:
            method = header["method"]
            require(len(self.methods) < MAX_ACTIVE, "inflight request ceiling")
            require(identity not in self.methods, "duplicate inflight request id")
            self.methods[identity] = (method, body.get("identity"))
            self.evidence.write("request", wire_id=identity, method=method,
                                is_control=header["is_control"])
            if method == OPEN and self.target is None and regular_marker(
                    self.evidence.directory / "arm-next-open"):
                self.target = identity
                self.target_identity = body["identity"]
                self.target_budget = body["budget"]
                require(set(self.target_identity) == {
                    "provider_id", "lease_id", "session_epoch"}, "lease identity shape")
                self.evidence.write("target-open-sent", wire_id=identity,
                                    identity=self.target_identity)
            if method == RELEASE and body.get("identity") == self.target_identity:
                require(header["is_control"] is True, "release is not control")
                require(self.release_id is None, "duplicate target release")
                self.release_id = identity
                self.evidence.write("target-release-sent", wire_id=identity,
                                    identity=self.target_identity,
                                    open_reply_still_held=not self.held_forwarded)
        else:
            method, lease = self.methods.pop(identity)
            require(body.get("method") == method, "reply method mismatch")
            require(body.get("identity") == lease, "reply identity mismatch")
            require(body.get("contract_version") == 1, "reply contract mismatch")
            self.evidence.write("reply", wire_id=identity, method=method)
            if method == "file_search/initialize":
                require(body.get("reply", {}).get("status") == "ok",
                        "service initialization failed")
                self.service_limits = body["reply"]["result"]["limits"]
            if identity == self.target:
                require(self.service_limits is not None, "service not initialized")
                lease_limits = {key: self.service_limits[key] for key in (
                    "max_query_utf8_bytes", "max_matches", "max_frame_bytes", "max_poll_wait_ms")}
                lease_limits.update(max_pending_polls=1, max_in_flight_updates=1)
                expected_open = {"status": "ok", "result": {
                    "initial_cursor": "0", "limits": lease_limits,
                    "budget": self.target_budget}}
                require(body.get("reply") == expected_open,
                        "target Open response does not match negotiated contract")
                self.held_complete = True
                self.held_fingerprint = {"held_bytes": len(self.held),
                                         "held_sha256": hashlib.sha256(self.held).hexdigest()}
                self.evidence.write("held-open-ready", wire_id=identity,
                                    identity=self.target_identity,
                                    native_already_ready=True,
                                    open_bytes_delivered=0,
                                    **self.held_fingerprint)
            if identity == self.release_id:
                expected = {"status": "ok", "result": {
                    "operation": {"status": "ok"}, "cleanup": {"status": "joined"}}}
                require(body.get("reply") == expected, "target release not clean Joined")
                require(self.held_complete and not self.held_forwarded,
                        "target release did not complete while Open held")
                self.release_joined = True
                self.evidence.write("target-release-joined", wire_id=identity,
                                    identity=self.target_identity,
                                    operation="ok", cleanup="joined",
                                    open_reply_still_held=True)

    def line(self, fd, raw):
        require(len(raw) <= LINE_CAP, "physical line ceiling")
        value = json.loads(raw)
        require(isinstance(value, dict), "wire frame not object")
        host = fd == 0
        destination = self.child_input_fd if host else 1
        if self.first[fd]:
            self.first[fd] = False
            if host:
                require(value.get("type") == "initialize", "initialization missing")
                state = Path(value["state_dir"])
                require(state.is_absolute() and state.is_dir(), "invalid state directory")
                self.evidence = Evidence(state / "preparing-relay", self.child.pid)
                self.evidence.write("relay-started")
            else:
                require(value == {"type": "ready", "api_version": 1,
                                  "session": {"mode": "multiplexed", "version": 1}},
                        "worker persistent handshake differs")
                self.evidence.write("worker-ready")
            self.enqueue(destination, raw)
            return
        held = not host and self.target is not None and value.get("id") == self.target
        if held:
            require(not self.held_complete, "extra frame for completed held reply")
            require(len(self.held) + len(raw) <= HOLD_CAP, "held reply ceiling")
            self.held.extend(raw)
        if value.get("type") == "shutdown":
            require(host and not self.shutdown_sent and self.held_forwarded,
                    "invalid or premature physical shutdown")
            require(not self.methods and not any(r.active for r in self.readers.values()),
                    "shutdown with pending messages")
            self.shutdown_sent = True
            self.evidence.write("physical-shutdown")
        if value.get("type") == "shutdown_complete":
            require(not host and self.shutdown_sent and not self.shutdown_complete,
                    "unexpected shutdown acknowledgement")
            require(not self.methods and not any(r.active for r in self.readers.values()),
                    "shutdown acknowledgement with pending messages")
            self.shutdown_complete = True
            self.evidence.write("physical-shutdown-complete")
        result = self.readers[fd].frame(value)
        if result:
            self.complete(host, *result)
        if not held:
            self.enqueue(destination, raw)

    def release_if_requested(self):
        if self.evidence is None or self.held_forwarded or not regular_marker(
                self.evidence.directory / "release-open"):
            return
        require(self.held_complete and self.release_joined,
                "release marker requires genuine held Open and Joined release")
        require(self.held_fingerprint == {"held_bytes": len(self.held),
                                         "held_sha256": hashlib.sha256(self.held).hexdigest()},
                "held bytes changed")
        self.enqueue(1, self.held)
        self.held.clear()
        self.held_forwarded = True
        self.forward_pending = True

    def run(self):
        while True:
            require(time.monotonic() - self.started < 300, "relay absolute timeout")
            self.release_if_requested()
            if self.host_eof and not self.queues[self.child_input_fd] and not self.child_input_closed:
                self.child.stdin.close()
                self.child_input_closed = True
            registered = {key.fd for key in self.selector.get_map().values()}
            wanted = self.live_reads | {fd for fd, queue in self.queues.items() if queue}
            for fd in registered - wanted:
                self.selector.unregister(fd)
            for fd in wanted:
                mask = (selectors.EVENT_READ if fd in self.live_reads else 0)
                mask |= selectors.EVENT_WRITE if self.queues.get(fd) else 0
                if fd in registered:
                    self.selector.modify(fd, mask)
                else:
                    self.selector.register(fd, mask)
            for key, mask in self.selector.select(0.02):
                fd = key.fd
                if mask & selectors.EVENT_READ:
                    chunk = os.read(fd, 65536)
                    if not chunk:
                        require(not self.buffers[fd], "EOF inside physical frame")
                        require(not self.readers[fd].active, "EOF inside message")
                        self.live_reads.remove(fd)
                        if fd == 0:
                            self.host_eof = True
                    else:
                        buffer = self.buffers[fd]
                        buffer.extend(chunk)
                        while b"\n" in buffer:
                            end = buffer.index(b"\n") + 1
                            raw = bytes(buffer[:end])
                            del buffer[:end]
                            self.line(fd, raw)
                        require(len(buffer) <= LINE_CAP, "unterminated line ceiling")
                if mask & selectors.EVENT_WRITE:
                    queue = self.queues[fd]
                    try:
                        sent = os.write(fd, queue)
                    except BlockingIOError:
                        continue
                    del queue[:sent]
            if self.forward_pending and not self.queues[1]:
                self.forward_pending = False
                self.evidence.write("held-open-forwarded", wire_id=self.target,
                                    **self.held_fingerprint)
            status = self.child.poll()
            if status is not None and self.child_output_fd not in self.live_reads and not self.queues[1]:
                require(status == 0, "native child failed")
                require(self.target is not None and self.release_joined and self.held_forwarded,
                        "gate did not complete")
                require(not self.methods, "native exited with pending replies")
                require(self.shutdown_sent and self.shutdown_complete,
                        "native exited without physical shutdown acknowledgement")
                self.evidence.write("relay-complete", native_exit=status,
                                    forced_cleanup=False)
                return 0

    def close(self):
        # Emergency cleanup is never converted to a successful gate. The outer
        # unchanged subreaper still verifies every descendant including zombies.
        if self.child.poll() is None:
            self.child.terminate()
            try:
                self.child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.child.kill()
                self.child.wait(timeout=5)
        self.selector.close()
        for stream in (self.child.stdin, self.child.stdout):
            stream.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worker", required=True)
    args = parser.parse_args()
    relative = Path(args.worker)
    require(not relative.is_absolute() and ".." not in relative.parts,
            "worker must be package relative")
    package = Path(__file__).resolve().parent
    worker = package / relative
    require(not worker.is_symlink() and worker.is_file(), "worker must be regular")
    require(package in worker.resolve().parents, "worker escapes package")
    child = None
    relay = None
    try:
        child = subprocess.Popen([str(worker)], stdin=subprocess.PIPE,
                                 stdout=subprocess.PIPE, stderr=None,
                                 bufsize=0, start_new_session=False)
        relay = Relay(child)
        return relay.run()
    except BaseException as error:
        # Exception text may contain an untrusted payload; log only its type.
        if relay is not None and relay.evidence is not None:
            relay.evidence.write("relay-failed", error_type=type(error).__name__)
        print("Preparing relay failed; inspect private causal markers", file=sys.stderr)
        return 1
    finally:
        if relay is not None:
            relay.close()
        elif child is not None:
            # Constructor failure still owns the already spawned native child.
            child.kill()
            child.wait(timeout=5)
            child.stdin.close()
            child.stdout.close()


if __name__ == "__main__":
    sys.exit(main())
