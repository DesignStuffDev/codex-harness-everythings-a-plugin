"""Actual GUI cancellation while host Open is held; native is already Ready.

No browser routing, fabricated result, auth-header inspection, or product hooks.
The second GUI tab is a sibling one-shot consumer, not a retained session lease.
"""

import json
from pathlib import Path
import stat
import time

from file_search.acceptance_support import inventory, require
from p01_gui_acceptance import identity


def marker(manager, directory, name):
    deadline = time.monotonic() + 60
    path = directory / (name + ".json")
    while not path.exists():
        require(manager.process.poll() is None, "manager exited before relay marker")
        require(not (directory / "relay-failed.json").exists(), "relay failed")
        require(time.monotonic() < deadline, "relay marker timeout")
        time.sleep(0.02)
    require(stat.S_ISREG(path.lstat().st_mode) and path.stat().st_size <= 8192,
            "invalid relay marker file")
    value = json.loads(path.read_text())
    require(value["event"] == name, "relay marker identity changed")
    return value


def trigger(directory, name):
    with (directory / name).open("xb") as stream:
        stream.write(b"GUI Preparing acceptance\n")


def same_native(manager, saved):
    current = identity(saved["pid"])
    require(current is not None and current["state"] != "Z"
            and {k: v for k, v in current.items() if k != "state"}
            == {k: v for k, v in saved.items() if k != "state"},
            "native PID identity changed or became a zombie")
    require(any(row["pid"] == saved["pid"] and row["start_ticks"] == saved["start_ticks"]
                for row in manager.snapshot()), "native child not tracked by launcher owner")


def still_held(directory):
    require(not (directory / "release-open").exists()
            and not (directory / "held-open-forwarded.json").exists()
            and not (directory / "relay-failed.json").exists(),
            "held Open escaped or relay failed")


def sibling_query(browser, query, name, root):
    browser.command(
        f"await preparingSibling.locator('#file-query').fill({json.dumps(query)}); "
        "await preparingSibling.waitForFunction(name => [...document.querySelectorAll('#file-results button span')].some(n => n.textContent === name), "
        f"{json.dumps(name)}); "
        "if (await preparingSibling.locator('#file-search-error').isVisible()) throw new Error('Sibling search failed'); "
        f"if (await preparingSibling.locator('#file-root').innerText() !== {json.dumps(root)}) throw new Error('Sibling root changed'); "
        "if (preparingSiblingErrors.length) throw new Error('Sibling page error'); return {siblingResult:true};"
    )


def exercise(browser, manager, directory, fixture, cycle, thread_id, persisted, work, screenshot):
    root = fixture["root"]
    ready = marker(manager, directory, "worker-ready")
    native = identity(ready["native_pid"])
    require(native is not None and native["ppid"] == ready["relay_pid"],
            "native worker is not relay child")
    require(any(row["pid"] == ready["relay_pid"] for row in manager.snapshot()),
            "relay is not tracked under manager")
    same_native(manager, native)
    # A same-origin popup inherits the opener's sessionStorage by browser rules.
    # No bearer token or readiness URL is read, copied to a report, or returned.
    browser.command(
        "globalThis.preparingSiblingErrors = []; "
        "const popup = page.waitForEvent('popup'); "
        "await page.evaluate(() => {window.open('/', '_blank');}); "
        "globalThis.preparingSibling = await popup; "
        "preparingSibling.setDefaultTimeout(60000); "
        "preparingSibling.on('pageerror', () => preparingSiblingErrors.push('pageerror')); "
        "await preparingSibling.locator('#prompt').waitFor(); "
        # connect() can announce readiness before the bootstrap list/resume/load.
        # Both selected identity and actual persisted history are required: the
        # selected CSS class is set before loadTurns completes.
        "await preparingSibling.waitForFunction(({threadId, root, texts}) => "
        "document.querySelector('#connection').classList.contains('connected') && "
        "[...document.querySelectorAll('.thread.selected')].some(node => node.dataset.threadId === threadId) && "
        "document.querySelector('#cwd').value === root && "
        "texts.every(text => document.querySelector('#messages').textContent.includes(text)) && "
        "!document.querySelector('#error').textContent, "
        f"{json.dumps({'threadId': thread_id, 'root': root, 'texts': persisted})}); "
        f"await preparingSibling.locator('#cwd').fill({json.dumps(root)}); "
        "await preparingSibling.locator('#find-file').click(); "
        "await preparingSibling.locator('#file-query').fill(''); return {siblingOpened:true};"
    )
    sibling_query(browser, "p02 beta", fixture["click"], root)
    same_native(manager, native)
    # Passive observers correlate genuine browser Request objects and responses.
    # All data stays in the private driver; only bounded search bodies are read.
    browser.command(
        "globalThis.preparingGui = {rows:[], requests:new Map(), overflow:false}; "
        "preparingGui.onRequest = request => {if (!request.url().endsWith('/rpc')) return; "
        "const frame = request.postDataJSON(); if (frame?.method !== 'fuzzyFileSearch') return; "
        "if (preparingGui.rows.length >= 32) {preparingGui.overflow=true; return;} "
        "const row = {params:frame.params, done:false, failed:false}; "
        "preparingGui.rows.push(row); preparingGui.requests.set(request,row);}; "
        "preparingGui.onResponse = async response => {const row = preparingGui.requests.get(response.request()); if (!row) return; "
        "try {row.status=response.status(); row.body=await response.json(); row.done=true;} catch {row.failed=true;}}; "
        "preparingGui.onFailed = request => {const row=preparingGui.requests.get(request); if(row) row.failed=true;}; "
        "page.on('request',preparingGui.onRequest); page.on('response',preparingGui.onResponse); page.on('requestfailed',preparingGui.onFailed); "
        "if (await page.locator('#file-picker').isVisible()) await page.locator('#close-file-picker').click(); "
        f"await page.locator('#cwd').fill({json.dumps(root)}); "
        "await page.locator('#find-file').click(); await page.locator('#file-query').fill(''); "
        "globalThis.preparingOriginalDraft = await page.locator('#prompt').inputValue(); return {observerReady:true};"
    )
    trigger(directory, "arm-next-open")
    browser.command("await page.locator('#file-query').fill('p02-alpha'); return {targetTyped:true};")
    held = marker(manager, directory, "held-open-ready")
    require(held["native_already_ready"] is True and held["open_bytes_delivered"] == 0,
            "relay did not retain a genuine native-ready Open")
    browser.command(
        "const rows=preparingGui.rows.filter(row => row.params.query==='p02-alpha'); "
        "if (rows.length!==1 || rows[0].done || rows[0].failed || preparingGui.overflow) throw new Error('Original GUI search is not pending'); "
        "preparingGui.original=rows[0]; "
        f"if (JSON.stringify(rows[0].params.roots)!==JSON.stringify([{json.dumps(root)}]) || !rows[0].params.cancellationToken) throw new Error('Original root/token missing'); "
        "if (await page.locator('#file-results button').count()) throw new Error('Preparing search exposed results'); "
        "if (await page.locator('#file-search-status').innerText() !== 'Searching…') throw new Error('GUI did not remain loading'); return {originalPending:true};"
    )
    screenshot(browser, work / f"preparing-held-{cycle}.png")
    still_held(directory)
    sibling_query(browser, "p02-root-original", fixture["original"], root)
    same_native(manager, native)
    still_held(directory)
    browser.command("await page.locator('#file-query').fill(''); return {clearTriggered:true};")
    released = marker(manager, directory, "target-release-joined")
    sent = marker(manager, directory, "target-release-sent")
    require(held["sequence"] < sent["sequence"] < released["sequence"]
            and held["identity"] == sent["identity"] == released["identity"],
            "cancellation did not retire the held target lease")
    require(released["operation"] == "ok" and released["cleanup"] == "joined"
            and released["open_reply_still_held"] is True, "cleanup was not Joined while held")
    still_held(directory)
    browser.command(
        "let cancel; for (let i=0;i<1200;i++) {const matches=preparingGui.rows.filter(row => row.params.query==='' && row.params.cancellationToken===preparingGui.original.params.cancellationToken); "
        "if(matches.length>1) throw new Error('Duplicate exact-token cancellation'); cancel=matches[0]; "
        "if(cancel?.done && preparingGui.original.done) break; "
        "if(preparingGui.original.failed || cancel?.failed || preparingGui.overflow) throw new Error('GUI request failed'); "
        "await new Promise(resolve => setTimeout(resolve,25));} "
        "if(!cancel?.done || !preparingGui.original.done) throw new Error('Original and cancellation did not complete while held'); "
        "if(JSON.stringify(cancel.params.roots)!==JSON.stringify(preparingGui.original.params.roots)) throw new Error('Cancellation root changed'); "
        "for(const row of [cancel,preparingGui.original]) if(row.status!==200 || row.body.error || JSON.stringify(row.body.result)!==JSON.stringify({files:[]})) throw new Error('Retired GUI RPC did not return exact empty files'); "
        "if(!(await page.locator('#file-picker').isVisible()) || await page.locator('#file-query').inputValue()!=='' || await page.locator('#file-results button').count() || await page.locator('#file-search-error').isVisible()) throw new Error('Clear query presentation did not settle'); "
        "if(await page.locator('#prompt').inputValue()!==preparingOriginalDraft) throw new Error('Clear destroyed draft'); "
        "preparingGui.cancel=cancel; return {originalAndCancelCompletedBeforeUnhold:true};"
    )
    still_held(directory)
    sibling_query(browser, "p02 beta", fixture["click"], root)
    same_native(manager, native)
    still_held(directory)
    trigger(directory, "release-open")
    forwarded = marker(manager, directory, "held-open-forwarded")
    require(forwarded["sequence"] > released["sequence"]
            and {key: forwarded[key] for key in ("held_sha256", "held_bytes")}
            == {key: held[key] for key in ("held_sha256", "held_bytes")},
            "held reply forwarding differs or preceded Joined")
    browser.command(
        "if(await page.locator('#file-query').inputValue()!=='' || await page.locator('#file-results button').count()) throw new Error('Drained reply revived stale results'); "
        "await page.locator('#file-query').fill('p02-alpha'); "
        f"await page.waitForFunction(name => [...document.querySelectorAll('#file-results button span')].some(n => n.textContent===name), {json.dumps(fixture['keyboard'])}); "
        "const originals=preparingGui.rows.filter(row=>row.params.query==='p02-alpha'); "
        "if(originals.length!==2 || originals[1].params.cancellationToken===originals[0].params.cancellationToken) throw new Error('Replacement identity was reused'); "
        "await page.locator('#file-query').press('Escape'); "
        "await preparingSibling.locator('#file-query').press('Escape'); await preparingSibling.close(); "
        "if(preparingSiblingErrors.length) throw new Error('Sibling page error'); "
        "page.off('request',preparingGui.onRequest); page.off('response',preparingGui.onResponse); page.off('requestfailed',preparingGui.onFailed); "
        "if(await page.locator('#prompt').inputValue()!==preparingOriginalDraft) throw new Error('Replacement destroyed draft'); return {replacementAfterDrain:true};"
    )
    same_native(manager, native)
    screenshot(browser, work / f"preparing-cleared-{cycle}.png")
    return {"passed": True, "trigger": "actual browser clear query",
            "scope": "Native already Ready; host/process Preparing; genuine native Open bytes held by test-only relay",
            "held": held, "release": released, "forwarded": forwarded, "native_process": native,
            "original_and_exact_token_cancel_completed_before_unhold": True,
            "sibling": "actual second GUI tab; independent one-shot searches via same gateway/native PID, not one retained sibling lease",
            "replacement_after_original_reply_forwarded": True,
            "shutdown": "caller must use unchanged manager-only SIGINT and require physical shutdown plus all tracked PIDs absent"}


def archive_after_shutdown(manager, directory, cycle, work):
    require(manager.process.returncode == 0, "manager did not shut down normally")
    complete = marker(manager, directory, "relay-complete")
    physical = marker(manager, directory, "physical-shutdown")
    acknowledged = marker(manager, directory, "physical-shutdown-complete")
    forwarded = marker(manager, directory, "held-open-forwarded")
    require(forwarded["sequence"] < physical["sequence"] < acknowledged["sequence"] < complete["sequence"]
            and complete["native_exit"] == 0 and complete["forced_cleanup"] is False,
            "physical normal shutdown/reap not confirmed")
    require(not (directory / "relay-failed.json").exists(), "relay failure marker exists")
    require(all(not Path(f"/proc/{row['pid']}").exists() for row in manager.snapshot()),
            "tracked launcher descendants remain, including zombies")
    archive = work / f"preparing-relay-cycle-{cycle}"
    require(not archive.exists(), "relay evidence archive already exists")
    files = inventory(directory)
    directory.rename(archive)
    require(inventory(archive) == files, "relay archive changed")
    return {"passed": True, "physical_shutdown": physical, "physical_shutdown_complete": acknowledged,
            "relay_complete": complete, "marker_directory": str(archive), "marker_files": files,
            "tracked_manager_descendants_absent": True}
