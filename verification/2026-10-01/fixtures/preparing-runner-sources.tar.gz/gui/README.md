# Staged actual GUI host-Preparing clear-query acceptance

**Unexecuted.** Python syntax only is checked. No new binary/package tuple is selected or approved by this stage, and no real host, browser, installation or test runtime was launched. All authored files are outside the checkout. The exact frozen relay remains unchanged.

This is the first coherent GUI Preparing slice: actual clear-query cancellation, a usable sibling GUI consumer, original reply forwarding, followed by the existing full GUI04 regressions and actual manager Launch-only SIGINT shutdown. It deliberately does not claim every GUI retirement trigger or native constructor cancellation.

## Stage02 correction

Stage01 remains unchanged at `/tmp/p02b-gui-preparing-stage-01`; its manifest SHA256 is `bbd64285ea169fcfe8a98c31fb2438cb7f9a4e0e46e86531c40223174ffd469f` and is copied here as `STAGE01_FINAL_MANIFEST.json`. Read-only review found that `#connection.connected` can precede bootstrap `listThreads`/saved-thread `selectThread`/`loadTurns`. Stage02 waits for the known selected thread ID, exact root, all persisted history anchors including the just-completed reference response, connected state and no displayed error before interacting with the sibling picker. It does not introduce another select/click race or inspect authentication tokens. `stage01-to-stage02.patch` records the exact code correction. No host/browser execution occurred in either revision.

## Files

- `p01_gui_preparing_acceptance.py`: staged copy of the existing GUI04 runner. `runner-review.patch` contains the full delta. Original `OwnedProcess`, `Browser`, `stop_manager`, `drain_subreaper`, model/turn and signal helper definitions are AST-identical to their preserved preimages. All old GUI exercise/turn/recovery assertions remain.
- `gui_preparing_install.py`: derives an explicitly test-only package `test.file-search-preparing-relay` from the independently built immutable native package. Only manifest ID/entrypoint/args and one added relay file differ. Worker/source/licenses stay unchanged. Original proof is retained as original proof; no synthetic independent-build receipt is generated.
- `gui_preparing_gate.py`: actual UI clear, passive browser request/response observation and causal markers. No `page.route`, result replacement, controller injection, backend fake, or credential/header inspection.
- `gui_preparing_provenance.py`: preflight and end-of-run input preservation checks. Requires a prior successful normal unchanged-package GUI acceptance against the same host/full-CLI tuple, genuine independently built worker proof, successful unchanged-source full CLI build receipt and explicit binary digests.
- `preparing_relay.py`: byte-for-byte frozen relay from `/tmp/p02b-installed-preparing-runner-stage` (SHA256 `ae1b829f29d1f86b2f934bf009ab657ccd4972f89b70c2da4652d097d12f373e`). Its prior 6/6 **fake worker relay-only** fixtures do not prove this GUI stage works.
- `PREIMAGE_MANIFEST.json`, `preimages/`: exact source/helper preimages. If their original paths change, preflight refuses execution: review and restage instead of silently rebinding.
- `syntax-check.json`: Python AST/bytecode syntax and unchanged helper-definition checks only.
- `FINAL_MANIFEST.json`: content hashes for this staged artifact. No runtime success claim.

## Causal sequence in each of two cold launcher cycles

1. Preserve normal existing desktop search/reference tests (actual results, safe path insertion, relative-root validation and old response-barrier stale-display tests). Preserve reference submission and deterministic model completion.
2. Open a second actual GUI tab through a same-origin popup. The browser itself inherits opener sessionStorage; no authentication secret is extracted. It connects to the same gateway and searches through the same observed genuine native worker PID/start identity. This is a sibling **one-shot consumer**, not proof of one retained sibling lease.
3. Arm the frozen relay and type `p02-alpha` in the primary actual picker. Require `held-open-ready` from the complete genuine successful worker Open reply, with zero target reply bytes delivered. Confirm the original browser RPC is still pending and the actual picker is loading with no results. **Native is already Ready; the host/process is Preparing.**
4. While that reply remains held, exercise another actual sibling GUI search and verify the same worker identity. Clear the primary query by its real input control. Observe the actual empty `fuzzyFileSearch` request carrying the original roots/token.
5. Require the relay's genuine target Release operation `ok` / cleanup `joined`, exact lease identity and causal marker sequence. Require both the original and exact-token empty cancellation browser RPCs to finish HTTP200 with exact `{files:[]}` **before unhold**. Require clear/empty presentation and intact draft; exercise another sibling query while still held.
6. Explicitly unhold the original exact bytes only now. Require held/forwarded byte count and SHA256 equality. Exercise a replacement search with a distinct token on the same worker, confirm real results and close both pickers; sibling page errors are fatal.
7. Preserve all original GUI04 streaming, approval, tool, turn interrupt, reload, continuation and cold persisted-history assertions. Preserve a live blocked model at shutdown. Signal **only the component manager Launch PID** using unchanged `stop_manager`, with unchanged grace and failure semantics. No gateway/store/worker-first signal or direct gateway.close is used.
8. Require the relay's physical Shutdown, ShutdownComplete and normal child-reap markers in sequence; manager exit0 and all tracked manager descendants absent, including zombies. The unchanged browser close, inner child drain and outer SDK subreaper must also pass. Archive the completed relay marker directory only after shutdown so the next cold launcher can create its own fresh single-target marker directory. Preserve both archives.

The frozen relay has a 300-second absolute lifetime ceiling and one target per process. Each complete GUI cycle must fit it; a timeout is a failed run. Do not silently loosen the relay or lifecycle limits. The runner never overwrites a used fixture claim or acceptance directory.

## Required input tuple / ordering

Root owns selection and compilation. Before invoking this stage:

1. Finish and freeze the new full CLI, manager and worker tuple. Preserve the complete successful source/build receipt plus separately verified binary-to-source artifact lineage. This stage checks supplied fingerprints/receipt continuity; it does not reconstruct compiler provenance or make a source merge safe.
2. Finish unchanged-package App Server/normal search gates as required by the parent track, then run the unchanged `p01_gui_acceptance.py --exercise-file-search --search-build-report ...` against this exact tuple, inside the unchanged SDK subreaper. Both normal GUI cycles, search workers and manager shutdown must pass. A prior GUI04 result for an older binary is regression history, not a substitute for the required current tuple.
3. Produce a **second fresh** successful `manual_migration_acceptance.py` fixture for the instrumented GUI run using the same tuple and independently built storage package. Do not reuse the normal GUI fixture: it has a persistent selected-search acceptance claim and an installed search selection. Normal GUI proof and instrumented GUI fixture are intentionally separate.
4. Review the staged source/patch and exact resolved absolute paths/digests. Root supplies and authorizes the run tuple. This stage has not resolved those values.

Exact command shape (replace each uppercase placeholder with the root-verified value; do not paste secrets or readiness URLs):

```bash
python3 /workspace/codex-harness-everythings-a-plugin/component-sdk/tests/subreaper_runner.py \
  --report /workspace/acceptance/p02b-gui-preparing-01.subreaper.json \
  -- python3 /tmp/p02b-gui-preparing-stage-02/p01_gui_preparing_acceptance.py \
  --host /ABSOLUTE/FROZEN/MANAGER \
  --host-sha256 FROZEN_MANAGER_SHA256 \
  --codex /ABSOLUTE/FROZEN/FULL_CLI \
  --codex-sha256 FROZEN_FULL_CLI_SHA256 \
  --codex-build-report /ABSOLUTE/FULL_CLI_BUILD.source.json \
  --manual-migration-report /ABSOLUTE/SECOND_FRESH_MIGRATION/manual-migration-report.json \
  --search-build-report /ABSOLUTE/INDEPENDENT_WORKER_BUILD/independent-build.json \
  --normal-gui-report /ABSOLUTE/SAME_TUPLE_NORMAL_GUI/acceptance-private.json \
  --normal-gui-subreaper-report /ABSOLUTE/SAME_TUPLE_NORMAL_GUI.subreaper.json \
  --exercise-file-search \
  --work-dir /workspace/acceptance/p02b-gui-preparing-01
```

The existing browser environment configuration can be used unchanged. The runner's defaults are Chromium at `/usr/bin/chromium` and existing Playwright at `/opt/codex/runtimes/cua/lib/node_modules/playwright-core`; absence is a real blocker, not authorization here to install or replace them. The driver is the existing **Playwright fallback, not the in-app Browser**.

Keep all produced directories private (runner umask077). Readiness logs and browser driver artifacts can contain private authentication/navigation data on failure; never publish raw contents. Publish only whitelisted report fields and reviewed fixture screenshots. No public listener or external URL is added by this stage.

## Required successful outputs

- `acceptance-private.json`: top-level pass, exactly two passing `preparing_clear` and `preparing_shutdown` records, all original GUI04 checks passed, manager status0 both cycles, no forced cleanup, all tracked search workers absent, final child drain pass, exact binary/package preservation, provenance preservation pass.
- `preparing-relay-cycle-1/` and `-2/`: original marker archives including actual held/release/forwarded/physical shutdown/reap sequence; no relay-failed marker.
- unchanged outer subreaper report: exit0/command0/no runner error, all observed adopted statuses retained honestly; do not erase or dismiss nonzero descendant exits.
- private before/after screenshots `preparing-held-N.png` and `preparing-cleared-N.png`, plus old GUI04 artifacts. A screenshot alone is not lifecycle proof.

Failure cleanup stays failure. The original manager helper may send a second interrupt/kill after the cleanup budget expires; such a run cannot pass and reports uncertainty. An uncompleted held gate can block normal physical shutdown; do not auto-unhold during exception cleanup and relabel it success. Root can examine preserved failure artifacts and stage a separate reviewed revision if necessary.

## Explicit remaining gates

- Actual Preparing retirement by root edit, task change and Escape/close control. Existing GUI04 response-barrier tests for these remain but only prove stale-display fencing after the server reply exists. Add fresh relay lifetimes/fixtures for each causal Preparing variant.
- Manager-only SIGINT **while Open remains held** is not tested here: this gate deliberately completes clear cancellation and forwards Open first, then preserves normal launcher shutdown with a real blocked model. A pending-Open shutdown gate needs an independent observer to unhold only after the required release receipt, before physical shutdown can be emitted; the frozen relay will not unhold automatically.
- Public sessionStart/sessionStop Preparing is a separate headless gate; GUI remains on its supported legacy cancellation-token protocol.
- Native constructor Preparing, earlier HTTP pre-admission cancel ordering, document pagehide delivery and reconnect transport guarantees remain separate. This stage does not imply them.
- Browser popup auth inheritance, end-to-end JavaScript callback behavior and real GUI lifecycle remain unverified until the actual run. Python syntax success is not browser proof.
- Package removal/upgrade/rollback are not newly proved by this GUI run; preserve the independent existing headless/package evidence. This run retains its isolated homes and source/package artifacts.
