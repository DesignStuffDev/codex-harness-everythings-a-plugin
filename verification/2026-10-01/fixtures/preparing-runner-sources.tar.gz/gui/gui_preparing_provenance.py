"""Strict input/tooling continuity for the staged GUI instrumented acceptance."""
import hashlib
import json
from pathlib import Path

from file_search.acceptance_support import fingerprint, inventory, require
from harness_acceptance import fingerprint as gui_fingerprint
from gui_selected_search_acceptance import validate_build


def preflight(args):
    stage = Path(__file__).resolve().parent
    repo = Path('/workspace/codex-harness-everythings-a-plugin')
    manifest = json.loads((stage / 'PREIMAGE_MANIFEST.json').read_text())
    for name, expected in manifest['sources'].items():
        actual = fingerprint(Path(name))
        require(all(actual[key] == value for key, value in expected.items()),
                'audited helper/relay source changed; restage before running')
    host, codex = args.host.resolve(strict=True), args.codex.resolve(strict=True)
    require(fingerprint(host)['sha256'] == args.host_sha256
            and fingerprint(codex)['sha256'] == args.codex_sha256,
            'candidate executable digest differs from explicit frozen tuple')
    _, proof, package, _ = validate_build(args.search_build_report, host)
    build_path = args.codex_build_report.resolve(strict=True)
    build = json.loads(build_path.read_text())
    require(build.get('returncode') == 0 and build.get('scoped_source_unchanged') is True
            and build.get('source_before') == build.get('source_after'),
            'successful unchanged-source full CLI build required')
    require('codex-cli' in build.get('command', []) and 'build' in build['command'],
            'supplied build receipt is not a full CLI build')
    normal_path = args.normal_gui_report.resolve(strict=True)
    normal = json.loads(normal_path.read_text())
    binaries = {'host': gui_fingerprint(host), 'codex': gui_fingerprint(codex)}
    require(normal.get('passed') is True and normal.get('binaries_before')
            == normal.get('binaries_after') == binaries,
            'same frozen host/full CLI must pass unchanged-package GUI acceptance first')
    require(normal.get('installed_packages_unchanged') is True
            and normal.get('final_drain', {}).get('passed') is True
            and not normal.get('cleanup_errors') and not normal.get('forced_adopted_cleanup'),
            'normal GUI cleanup or immutability proof missing')
    require(len(normal['runs']) == 2 and all(
        run.get('passed') is True and run.get('manager_status') == 0
        and run.get('selected_search_workers_absent') is True
        and run.get('file_search', {}).get('passed') is True
        and run.get('subreaper_drain', {}).get('passed') is True and not run.get('forced')
        for run in normal['runs']), 'two strict normal GUI cycles required')
    selected = normal['selected_search']
    require(selected['build_report_fingerprint'] == fingerprint(args.search_build_report),
            'normal GUI used another native worker proof')
    # Installation preserves bytes/execute bits, not package source mtimes.
    from file_search.acceptance_support import same_content
    require(same_content(selected['installed_package_files'], proof['package_files']),
            'normal GUI worker differs from original package')
    require(normal['script_fingerprint'] == gui_fingerprint(repo / 'component-sdk/tests/p01_gui_acceptance.py')
            and normal['driver_fingerprint'] == gui_fingerprint(repo / 'component-sdk/tests/gui_browser_driver.cjs'),
            'normal GUI helper/driver source changed')
    outer_path = args.normal_gui_subreaper_report.resolve(strict=True)
    outer = json.loads(outer_path.read_text())
    require(outer.get('subreaper') is True and outer.get('runner_error') is None
            and outer.get('exit_status') == outer.get('command_returncode') == 0
            and str(normal_path.parent) in outer.get('command', []),
            'normal GUI lacks matching successful unchanged outer subreaper')
    inputs = {key: {'path': str(path), **fingerprint(path)} for key, path in (
        ('codex_build', build_path), ('normal_gui', normal_path), ('normal_subreaper', outer_path),
        ('worker_build', args.search_build_report.resolve(strict=True)))}
    return {'inputs': inputs, 'binaries': {'host': fingerprint(host), 'codex': fingerprint(codex)},
            'package_path': str(package), 'package_files': inventory(package),
            'stage_python': {p.name: fingerprint(p) for p in stage.glob('*.py')},
            'sdk_preimages': manifest['sources'],
            'codex_source_after_sha256': hashlib.sha256(json.dumps(build['source_after'], sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
            'binding_authority': 'Caller-verified frozen build/artifact lineage; exact supplied binary/build receipts and normal same-host GUI tuple checked, compiler provenance not reconstructed',
            'normal_gui_scope': 'Unchanged installed native package; instrumented run is a separate test-only relay claim'}


def verify(record):
    stage = Path(__file__).resolve().parent
    require(record['stage_python'] == {p.name: fingerprint(p) for p in stage.glob('*.py')},
            'staged acceptance helper changed during run')
    for expected in record['inputs'].values():
        require({'path': expected['path'], **fingerprint(Path(expected['path']))} == expected,
                'acceptance proof input changed during run')
    for name, expected in record['sdk_preimages'].items():
        actual = fingerprint(Path(name))
        require(all(actual[key] == value for key, value in expected.items()), 'source helper changed during run')
    require(inventory(Path(record['package_path'])) == record['package_files'],
            'original native package changed during run')
