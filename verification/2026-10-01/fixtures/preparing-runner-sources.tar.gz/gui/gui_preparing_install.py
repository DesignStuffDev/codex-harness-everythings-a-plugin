"""Isolated test-only derived relay package; original independent proof retained."""
import json
from pathlib import Path
import shutil

from file_search.acceptance_support import fingerprint, inventory, require, same_content
from gui_selected_search_acceptance import (validate_build, claim_fixture, observed_worker, assert_worker_absent)

PLUGIN = "test.file-search-preparing-relay"


def install(
    proof_path,
    host,
    manual_path,
    manual,
    fixture,
    work,
    environment,
    owner_type,
    drain_subreaper,
    evidence,
):
    proof_path, proof, package, manifest = validate_build(proof_path, host)
    evidence.update(
        backend="selected genuine native worker through a test-only byte-preserving Preparing relay",
        build_report=str(proof_path),
        build_report_fingerprint=fingerprint(proof_path),
        helper_fingerprint=fingerprint(Path(__file__)),
        source_inventory=proof["exported_source_inventory"],
        independent_worker=proof["build_artifact"]["fingerprint"],
        frozen_manager=fingerprint(host),
        full_cli_binding="current manual-migration proof; not the standalone search CLI from the worker build",
        commands=[],
    )
    evidence["fixture_claim"] = claim_fixture(
        manual_path, manual, fixture, work, evidence["build_report_fingerprint"]
    )
    home, project = Path(fixture["codex_home"]), Path(fixture["cwd"])
    original_settings = json.loads((home / "components/config.json").read_text())
    require(PLUGIN not in original_settings["installed"], "instrumented plugin already installed")
    objects = home / "components/objects"
    original_objects = inventory(objects)
    install_input = work / "search-install-input"
    shutil.copytree(package, install_input)
    require(
        same_content(inventory(install_input), proof["package_files"]),
        "search install copy differs from independent package",
    )
    require(manifest.get("args") == [], "original worker has unexpected arguments")
    require(any(c.get("kind") == "file_search" and c.get("name") == "default"
                and c.get("metadata", {}).get("preparing_cancel_receipt") == 1
                for c in manifest["components"]), "worker lacks Preparing receipt declaration")
    relay = Path(__file__).resolve().parent / "preparing_relay.py"
    require(not (install_input / relay.name).exists(), "relay path collides with package")
    shutil.copy2(relay, install_input / relay.name)
    (install_input / relay.name).chmod(0o755)
    instrumented_manifest = dict(manifest, id=PLUGIN, entrypoint=relay.name,
                                 args=["--worker", manifest["entrypoint"]])
    (install_input / "codex-component.json").write_text(json.dumps(instrumented_manifest, indent=2) + "\n")
    derived_files = inventory(install_input)
    require(set(derived_files) == set(proof["package_files"]) | {relay.name},
            "unexpected instrumented package paths")
    for name, original in proof["package_files"].items():
        if name != "codex-component.json":
            require(same_content({name: derived_files[name]}, {name: original}),
                    "original worker/source/license changed")
    evidence.update(original_package_files=proof["package_files"],
                    instrumented_package_files=derived_files,
                    original_manifest=manifest, instrumented_manifest=instrumented_manifest,
                    scope="Only package ID/entrypoint/args and added relay differ; native binary/source/licenses unchanged")
    management = [host, "--codex-home", home]
    environment = dict(environment, CODEX_HOME=str(home))
    for label, arguments in (
        ("install", ["install", install_input]),
        ("select", ["select", "file_search", "default", PLUGIN]),
        ("list", ["list"]),
    ):
        entry = {"label": label, "passed": False}
        evidence["commands"].append(entry)
        owner = owner_type(
            management + arguments,
            project,
            work / f"search-manager-{label}",
            environment,
        )
        try:
            status = owner.process.wait(timeout=90)
            entry["status"] = status
            require(status == 0, "search manager command failed; inspect private logs")
            owner.reap_and_check()
            entry.update(
                processes=owner.snapshot(),
                tracked_processes_absent=True,
                reaped_orphans=owner.reaped_orphans,
            )
            if label == "list":
                selected = json.loads(owner.stdout_path.read_text())
            entry["subreaper_drain"] = drain_subreaper()
            require(entry["subreaper_drain"]["passed"], "search setup left children")
            entry["passed"] = True
        finally:
            try:
                if not entry["passed"]:
                    entry["forced_failure_cleanup"] = True
                    owner.emergency_cleanup()
            finally:
                owner.finish()
    expected_settings = json.loads(json.dumps(original_settings))
    expected_settings["installed"][PLUGIN] = selected["installed"][PLUGIN]
    expected_settings["enabled"].append(PLUGIN)
    expected_settings["selections"]["file_search:default"] = PLUGIN
    require(
        json.loads((home / "components/config.json").read_text()) == expected_settings,
        "search selection changed unrelated saved settings",
    )
    # List intentionally omits per-plugin configuration. Check that public
    # projection separately, while retaining the full saved-config comparison.
    require(
        selected
        == {
            key: expected_settings[key]
            for key in ("enabled", "installed", "selections")
        },
        "manager list differs from saved component settings",
    )
    object_name = selected["installed"][PLUGIN]
    require(
        Path(object_name).name == object_name and object_name not in (".", ".."),
        "installed object identifier escapes object directory",
    )
    installed = objects / object_name
    require(
        installed.resolve(strict=True) == installed, "installed object is a symlink"
    )
    require(
        same_content(inventory(installed), derived_files),
        "immutable installed search object differs from independent package",
    )
    current_objects = inventory(objects)
    require(
        all(
            current_objects.get(name) == data for name, data in original_objects.items()
        ),
        "search setup changed an existing immutable component object",
    )
    require(
        set(current_objects) - set(original_objects)
        == {f"{object_name}/{name}" for name in derived_files},
        "search setup added unexpected immutable objects",
    )
    worker = (installed / manifest["entrypoint"]).resolve(strict=True)
    require(installed in worker.parents, "installed worker escapes immutable object")
    install_input.rename(work / "search-install-input.parked")
    evidence.update(
        installed_worker=str(worker),
        installed_worker_fingerprint=fingerprint(worker),
        installed_package_files=inventory(installed),
        original_components_preserved=True,
        install_input_parked=True,
    )
    require(
        fingerprint(host) == evidence["frozen_manager"],
        "manager changed during install",
    )
    require(fingerprint(worker)["sha256"] == proof["build_artifact"]["fingerprint"]["sha256"],
            "installed worker differs from independent build")
    return worker

