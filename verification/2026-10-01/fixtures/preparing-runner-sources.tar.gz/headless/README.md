# Installed Preparing cancellation gate — relay fixtures passed; real runtime pending

This is a test-only transport adapter around the actual independently compiled
native worker. It does not replace search, synthesize results, implement a fake
backend, or add hooks to production. The exact worker04 package must first pass
normal installed acceptance unchanged. A second, explicitly instrumented package
adds this relay under a different package ID and retains byte-identical worker04.
No real host or native runtime success is claimed by this stage. Relay-only fixture
validation is recorded in VALIDATION.md.

## Two separate claims

1. **Native pre-ready ownership:** the existing owner/backend constructor tests
   exercise private per-start cancellation, result abandonment, join receipts,
   retained original failure and quarantine. The constructor acknowledges ready
   after starting the walker, before filesystem traversal finishes. FIFO ignore
   files, Git configuration waits and SIGSTOP do not prove native Preparing.
2. **Installed host/process Preparing:** the relay forwards the real Open request
   and holds every frame of its genuine successful reply. The native lease is
   already Ready. The host has not received any Open reply frame. A public user
   cancellation must send the real same-lease release and receive the real Joined
   receipt while that reply remains held. The child keeps running and siblings
   continue on the same PID/provider. This is the narrower installed-path proof.

## Source audit and prerequisites

- `file-search/src/lifecycle.rs`: `supervise` sends ready after walker spawn;
  `lib.rs::walker_worker` performs WalkBuilder traversal independently.
- `component-host/src/session_wire.rs`: multiplexed RequestStart/ResultStart,
  Chunk and End frames; reply IDs may complete out of order with bounded gaps.
- `file-search-component/src/process_open.rs`: cancellation owns an independently
  retained paired release even after dropping the passive Open reply observer.
- `component-host/src/session_supervisor.rs`: pending original reply must be
  drained before transport Shutdown. Release held Open explicitly before normal
  shutdown; never wait for Shutdown as the trigger.
- `file-search-component/src/service_runner.rs`: reader-order synchronous
  admission allows release to name the actual lease before response observation.
- `app-server-protocol/src/protocol/common.rs` and
  `app-server/src/request_serialization.rs`: same-session Start/Update/Stop have
  exclusive FIFO serialization. Existing direct processor tests bypass that
  public dispatch. Pending public Stop requires the separately reviewed bounded
  reader-admitted intent ticket change, keeping ordinary dispatch/replies FIFO.
  Do not mark Stop unserialized or claim old public Stop already preempts Start.
- Legacy `fuzzyFileSearch` has no serialization scope. The actual GUI uses this
  method and sends a concurrent empty-query request with the original token.
  Keep this GUI protocol; do not migrate the frontend to manufacture coverage.

## Package and authority boundary

Root should copy the verified worker04 package to a new isolated acceptance input,
verify all original copied contents, retain its Apache/MPL notices and modified
vendor source, then add the staged executable `preparing_relay.py`. Change only
manifest ID to `test.file-search-preparing-relay`, entrypoint to that helper and
args to `["--worker", "codex-file-search-local-plugin"]`. Set the helper executable
(mode 0755), and fingerprint that mode in the instrumented package. Retain contract metadata
and version; record this as an instrumented package, not unchanged worker04.
Install/select with the actual frozen component manager in a fresh private home.
Record both complete package inventories, manifest delta and unchanged worker
SHA a3f73fed15dd7b19ab0f1daed55a74212d4b2f5d2ba5cdebee2a616d2f2419a1.

The relay uses initialization's state_dir only to make a new private
`preparing-relay` directory. It never dumps initialization/configuration or the
process environment. Control markers are regular files owned by the private
acceptance runner. No socket, port, network service or persistent installation
is involved. The child uses the inherited cwd and process group; no shell or
new process group is created. Stdout remains solely original worker protocol.
The unchanged outer SDK subreaper must supervise the whole acceptance.

## Causal public API scenario (no retry)

Use current `RpcServer` and `search_cases` assertions without weakening deadlines,
identity, snapshot ordering or strict PID absence. Run first with a frozen new
host + normal unchanged worker04 package. Native/installed ordered parity,
resource failure, configuration rejection, removal and restoration remain gates.
Then install the separate instrumented package in a fresh home/process:

1. Initialize real App Server. Observe relay/native child identities and the
   actual initialization-ready marker. Start a sibling and exercise alpha/beta.
2. Create regular `arm-next-open` in the private relay marker directory. Send a
   one-shot `fuzzyFileSearch` with a unique cancellationToken and query alpha.
3. Await `held-open-ready.json`; require successful real reply, exact request ID
   and lease identity, no Open bytes delivered, and original public reply absent.
4. While held, update the existing sibling; require exact expected results,
   unchanged provider/native PID and no target delivery. A short quiet check is
   only secondary evidence; the held-frame marker is the causal barrier.
5. Send same-token empty-query legacy request. Require `target-release-sent`
   metadata (control=true, same identity) and `target-release-joined.json` before
   creating release-open. Its real result must have operation Ok and cleanup
   Joined. Both legacy RPCs should complete with empty files, without synthetic
   target search output. Capture actual ordering rather than assuming public
   acknowledgement must wait for the original reply's bytes.
6. Exercise sibling again while held, then create regular `release-open`.
   Require `held-open-forwarded.json` before attempting normal shutdown. Start a
   fresh replacement/query and prove unchanged provider/native PID still works.
7. SessionStop variant: fresh run + reviewed reader-intent host, hold pending
   Start reply, send same-ID Stop plus sibling Update. Require same genuine
   release-before-held-delivery proof. Original Start must fail with JSON-RPC INTERNAL_ERROR (-32603) and a
   diagnostic containing `released before` for clean intended retirement. Stop
   returns `{}` through FIFO only after clean retained startup cleanup. A real
   failure or Unconfirmed cleanup must instead remain visible on Stop; the
   pending reader-intent design must retain that receipt even after Start removes
   its connection entry. Never infer this from direct processor fixture tests.
8. Close through normal public/manager lifecycle, preserve all reports, require
   relay/native/server/descendant PIDs absent including zombies, original frozen
   binaries and installed objects unchanged, no timeout/forced cleanup. A failed
   check is a failed run even if emergency cleanup eventually removes children.

## Existing GUI gate

A fresh GUI page with empty Find file opens no search. Arm the next Open, type a
query, await the held marker, then clear/Escape or change root/task. Browser must
observe the actual concurrent empty-query cancellation and real target Joined
release while the original reply is held. Only then release original bytes;
assert no obsolete results, and a successor query under the new token/current
root succeeds. Preserve existing task/session/storage/recovery/browser checks
and manager-only Ctrl+C cleanup. Existing tests that delay a completed HTTP reply
prove UI stale-response fencing, not Preparing cancellation; retain both claims.
GUI allowlist currently rejects sessionStart/Stop; no change is needed for this.

## Required report and validation before adoption

- Freeze new host build/report/source binding and independent worker04 report;
  keep old-host compatibility proof distinct from new-host Preparing proof.
- Record source/helper/manifest/binary hashes, the exact instrumented delta, real
  request/lease IDs, actual release receipt, marker event order, same-PID sibling
  proof, exact public responses and all observed descendant identities.
- No query/root/result/config/env payload is written by relay evidence. Host RPC
  fixture transcripts remain private acceptance artifacts as before.
- The first a4907593 stage was unexecuted. Subsequent syntax and six relay-only
  protocol fixture checks passed (VALIDATION.md). Real installed acceptance still
  requires the frozen new host. Unit protocol fixtures validate the relay only.
- Helper bounds are acceptance ceilings: 4 MiB physical line, 1 MiB decoded body,
  64 active messages per direction, 8 MiB aggregate assembled input per direction,
  8 MiB pending pipe output per direction, 2 MiB held raw response, 2048 events,
  300-second absolute relay run. Exceeding one fails; none are host RSS promises.
- A successful instrumented gate does not establish native pre-ready cancellation,
  arbitrary third-party provider semantics, multi-connection isolation, Windows,
  process crash recovery, or whole-harness extraction.

## Original stage history and review status

- `preparing_relay.py`: executable package entrypoint proposal (root must set
  executable permission when assembling the instrumented package).
- `public_rpc_gate.py`: `legacy_token_gate(server, marker_directory, baseline)`;
  reusable scenario, not a standalone process/installation runner. Import with
  the existing SDK `tests/file_search` directory on Python's module search path.
  Caller must initialize the server, verify packages/frozen builds, invoke normal
  `RpcServer.finish()`, then check relay-complete and unchanged subreaper results.
- The first stage did not implement the public session Stop scenario or browser
  driver. This stage02 now adds the former; see SCENARIOS.md. The browser driver
  remains separate. The precise expected public Start error for
  clean retirement is -32603 with `released before`; genuine/unconfirmed cleanup
  must remain visible on Stop. The normal legacy GUI path is independent of the
  new session Stop ingress fix.
- Independent static review by allocation_contract_audit found and prompted three
  corrections before execution: publish complete markers atomically; validate
  exact negotiated OpenResponse; require physical shutdown acknowledgement.
  Final read-only re-review found no remaining blocking defect in the current two
  helpers. Subsequent relay-only validation is separate from that static review.
- `*-sent` marker names mean observed complete input/enqueued for forwarding,
  not an OS write acknowledgement. Successful real release reply plus both public
  RPC completions before unhold provide the stronger causal proof. The numbered
  evidence events are bounded and private; no full payload transcript is saved.
- GUI uses only one-shot legacy calls; this stage leaves the frontend unchanged.
  Refer also to `/tmp/p02b-gui-preparing-audit.md` for the GUI-specific source audit.

## Complete runner added in the fresh runner stage

`installed_preparing_acceptance.py` supplies the full installation/lifecycle owner.
It imports the existing unmodified SDK `Runner`, `RpcServer`, inventory and search
scenario helpers directly from `--repo`. Required arguments are `--repo`,
`--server`, `--server-sha256`, `--server-build-report`, `--manager`, `--build-report`,
`--normal-acceptance-report`, `--normal-subreaper-report`, and a fresh `--work-dir`.
For a full Codex executable add `--server-mode codex`; default is standalone AS.
Choose `--scenario legacy` or `--scenario session-stop` and use a fresh work
directory/outer report for each (SCENARIOS.md).
Run it under the unchanged SDK `subreaper_runner.py --report OUTER.json -- python3
/path/to/installed_preparing_acceptance.py ...`, then verify OUTER exit status,
runner_error and child drainage independently. A script's own `passed` field is
not a substitute for that outer result.

Before creating the acceptance home it checks the successful independently built
worker proof, parked export, exact package inventory, original manager fingerprint,
frozen server digest/build report, and successful normal unchanged-package
acceptance on the same host/manager/package tuple. The normal outer subreaper
must name that acceptance work directory and report successful drainage.

It then performs three actual server lifecycles: native baseline; installed relay
causal cancellation scenario; removed native restoration including existing stream
checks. Five real manager commands install/select/list/remove/list own catalog
mutation. All work occurs in a new private directory outside the checkout. The
installed relay object preserves every original worker/source/license file; only
manifest ID/entrypoint/args differ and the executable relay is added. It checks
full original and installed inventories, frozen binary fingerprints, evidence
reports, both helper trees and subreaper bytes again on exit. Failures preserve
reports and use existing emergency cleanup, never convert it to a passing gate.

The new runner and the unchanged relay/scenario passed an in-memory Python syntax
check recorded in `syntax-check-01.json`. That is not an installation, native
runtime or GUI verification. The original a4907593 manifest remains copied in
`PREIMAGE_MANIFEST.json`; no original staged file was overwritten in place.
