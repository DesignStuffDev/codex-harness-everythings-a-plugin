# Two separately reported real-host scenarios (unexecuted)

The original complete runner stage01 remains frozen at manifest
414dc075fbb02bae5d33aaf8c286d0a215c4ba2d45ab13e7eb321721b693bfdb.
This stage02 preserves its copy as RUNNER01_MANIFEST.json and adds a second
scenario. The relay and original legacy scenario are byte-identical to the six
relay-only fixture checks. Those checks do not execute either real-host scenario.

Run the full driver twice under separate unchanged subreaper invocations and
fresh --work-dir directories, using the same frozen new host/worker04 tuple and
successful normal unchanged-package acceptance evidence:

- `--scenario legacy` (default): GUI-compatible concurrent empty-query token
  cancellation, original and cancellation RPCs complete before original Open
  reply is unheld. This remains the unchanged legacy scenario from stage01.
- `--scenario session-stop`: public sessionStart, same-ID sessionStop, then a
  later same-ID sessionStart are all written through real JSON-RPC. While the
  first genuine successful native Open response is held, require actual same-lease
  Joined release, the first Start's -32603 `released before` diagnostic and Stop's
  `{}` response in FIFO order. The later same-ID Start is sent after Stop and
  before awaiting the earlier replies; it must succeed after them. Query it and
  an existing sibling on the same real worker while the old Open remains held,
  explicitly unhold the unchanged old reply, then query both again. Stop the new
  target and leave the sibling for actual normal EOF shutdown.

The session-stop scenario requires the new authenticated reader-order intent
implementation. It must not run against an old host and reinterpret a timeout as
expected behavior. The reviewed source candidate is manifest
1749f435cd878a0a092e6e08bdd47dbb1e451c8f34ef1c5e41d786b4d955f641;
root must compile/verify and bind the actual frozen host before running. Newhost
build identity is intentionally a required caller input, not guessed here.

For each scenario the same full driver independently verifies the normal evidence
tuple, creates an instrumented package and private home, exercises native baseline,
manager install/select/list, the selected public scenario, normal EOF/strict PIDs,
manager remove/list and native restoration with existing stream regressions.
Separate homes avoid reusing relay markers or conflating the two proofs.

No ordinary handler serialization annotation changes. No synthetic backend,
request-processor direct call, native constructor hook, SIGSTOP or synthesized
protocol reply appears in either real-host scenario. The native worker is already
Ready before the host-side barrier, so neither scenario is a native pre-ready
constructor proof. No GUI/browser protocol change is introduced.

Error/Unconfirmed Stop branches remain the separately identified focused tests;
this stage does not add an actual malformed-worker injector or call a clean real
worker error path proved. All existing original failure reports and fixture
negative cases remain preserved. Root still owns host source/binary lineage and
external durability; this staging directory is only a cloud-filesystem artifact.

## Root execution order and adapter invocation

Execute these three top-level commands serially, each under the same unchanged
absolute SDK subreaper and each with a different fresh work directory/report:

1. Current repository `component-sdk/tests/file_search/app_server_acceptance.py`
   against the frozen new host + unchanged independently built worker04 package.
   Expected: native baseline exit0, installed parity/streams exit0, deliberate
   real snapshot-exhaustion server positive failure exit, restored-native exit0;
   six manager/config commands have their existing expected statuses. Its report
   is the mandatory normal-acceptance input to both later runs.
2. This stage02 `installed_preparing_acceptance.py --scenario legacy` using that
   normal report and outer subreaper report. Expected: three real AS lifecycles
   exit0 (native baseline, instrumented public legacy cancellation, restoration),
   five management commands exit0, clean Joined proof before unhold, zero remaining
   observed PIDs, unchanged inventories and frozen binaries.
3. This stage02 `installed_preparing_acceptance.py --scenario session-stop` in a
   second fresh home/work directory. Same expected lifecycle/management statuses;
   cancelled target Start must return -32603 while matching Stop returns `{}` and
   the later same-ID Start succeeds, in actual FIFO reply order. The native child
   remains the same through sibling/successor use and normal EOF.

Use the actual original manager path from worker04's fingerprint proof:
`/workspace/component-checkpoint-candidate-p02b-search-cli-20261001-02/codex-component`.
Worker build proof is
`/workspace/acceptance/p02b-search-independent-04/independent-build.json`.
The source adapter entrypoint is this stage02 absolute
`/tmp/p02b-installed-preparing-runner-stage-02/installed_preparing_acceptance.py`.
Add `--server-mode codex` only if the frozen executable is full Codex; otherwise
use standalone mode. Supply the actual new host path/SHA/build report after root
verifies its frozen candidate/source lineage. No newhost tuple is fabricated.
`INVOCATIONS.json` records exact command-array templates and required bindings;
these templates are not executed by this stage.

Root is the final stage02 reviewer. No separate independent stage02 scenario
review is claimed: the former reviewer moved to the authorized GUI deliverable.
Stage01 relay/full-driver review and six relay fixtures remain valid within their
original scope. Stage02 adds only scenario source, driver dispatch and reporting;
all four Python files passed syntax, but neither real-host scenario has run.
