"""Staged real public FIFO Start/Stop gate; caller owns actual server lifecycle.

Requires the reader-admitted Stop intent implementation in a verified frozen host.
The genuine native worker is already Ready while its complete Open reply is held.
No result/receipt is synthesized and no direct processor/test hook is called.
"""

from acceptance_support import process_snapshot, require
from public_rpc_gate import marker, same_native, trigger
from rpc_support import SEARCH_METHODS
from search_cases import ROOT, update


def session_stop_gate(server, directory, baseline):
    ready = marker(server, directory, "worker-ready")
    server._track()
    native = process_snapshot().get(ready["native_pid"])
    require(native is not None, "actual native PID missing")
    require(native["parent"] == ready["relay_pid"], "worker is not relay child")
    require(ready["relay_pid"] in server.tracked, "relay is not host descendant")
    sibling, target = "stop-sibling", "preparing-stop-target"
    server.request("fuzzyFileSearch/sessionStart", {"sessionId": sibling, "roots": [ROOT]})
    update(server, sibling, "alpha", baseline["lexical-alpha"])
    trigger(directory, "arm-next-open")
    original = server.send("fuzzyFileSearch/sessionStart", {"sessionId": target, "roots": [ROOT]})
    held = marker(server, directory, "held-open-ready", before_reply=original)
    require(held["native_already_ready"] is True and held["open_bytes_delivered"] == 0,
            "gate did not hold a genuine native-ready reply")
    require(not any(msg.get("id") == original for _, msg in server.pending),
            "original Start completed before its held reply")
    require(not any(msg.get("method") in SEARCH_METHODS
                    and msg.get("params", {}).get("sessionId") == target
                    for _, msg in server.pending), "unacknowledged startup published events")
    update(server, sibling, "beta", baseline["beta"])
    same_native(server, native)

    stopped = server.send("fuzzyFileSearch/sessionStop", {"sessionId": target})
    # Received after Stop but before either earlier RPC is awaited. A Stop must
    # not install a tombstone or cancel this later same-ID generation.
    successor = server.send("fuzzyFileSearch/sessionStart", {"sessionId": target, "roots": [ROOT]})
    released = marker(server, directory, "target-release-joined")
    sent = marker(server, directory, "target-release-sent")
    require(held["sequence"] < sent["sequence"] < released["sequence"],
            "actual release did not follow held Open")
    require(held["identity"] == sent["identity"] == released["identity"],
            "Stop released another lease")
    require(released["operation"] == "ok" and released["cleanup"] == "joined"
            and released["open_reply_still_held"] is True,
            "Stop did not obtain genuine Joined release while Open held")
    require(not (directory / "release-open").exists()
            and not (directory / "held-open-forwarded.json").exists(),
            "original Open reply escaped before Stop proof")

    start_sequence, start_reply = server.response(original, error_code=-32603)
    require("released before" in start_reply["error"]["message"],
            "Start failed for a different cause than clean intended retirement")
    require("result" not in start_reply, "cancelled Start also returned a result")
    stop_sequence, stop_reply = server.response(stopped)
    require(stop_reply["result"] == {}, "clean joined Stop result changed")
    require(start_sequence < stop_sequence, "Stop reply bypassed Start FIFO")
    require(not any(msg.get("method") in SEARCH_METHODS
                    and msg.get("params", {}).get("sessionId") == target
                    for _, msg in server.pending), "cancelled startup published events")
    server.assert_quiet(target, stop_sequence)
    next_sequence, next_reply = server.response(successor)
    require(next_reply["result"] == {} and stop_sequence < next_sequence,
            "later same-ID Start was cancelled or bypassed FIFO")
    # Query the new generation and old sibling while the obsolete first Open
    # reply is still held. Both must use the same actual worker/provider.
    update(server, target, "beta", baseline["beta"])
    update(server, sibling, "alpha", baseline["lexical-alpha"])
    same_native(server, native)
    require(not (directory / "held-open-forwarded.json").exists(),
            "first Open reply was released before successor proof")

    trigger(directory, "release-open")
    forwarded = marker(server, directory, "held-open-forwarded")
    require(forwarded["sequence"] > released["sequence"], "original reply unheld early")
    require({k: held[k] for k in ("held_sha256", "held_bytes")} ==
            {k: forwarded[k] for k in ("held_sha256", "held_bytes")},
            "late original Open bytes differ")
    update(server, target, "alpha", baseline["lexical-alpha"])
    update(server, sibling, "beta", baseline["beta"])
    same_native(server, native)
    target_stop_sequence, _ = server.request("fuzzyFileSearch/sessionStop", {"sessionId": target})
    server.assert_quiet(target, target_stop_sequence)
    # Leave the sibling live for actual normal EOF shutdown, as existing strict
    # stream acceptance does. Caller must verify relay/native/host PID absence.
    result = {
        "claim": "public sessionStart/Stop FIFO intent while installed host/process Preparing; native Ready",
        "original_start_request_id": original, "stop_request_id": stopped,
        "successor_start_request_id": successor,
        "reply_sequences": {"cancelled_start": start_sequence, "joined_stop": stop_sequence,
                            "successor_start": next_sequence},
        "cancelled_start_error": start_reply["error"], "clean_stop_result": {},
        "held": held, "release": released, "forwarded": forwarded,
        "native_process": native, "sibling_same_worker": True,
        "later_same_id_received_after_stop_remains_usable": True,
        "later_same_id_usable_before_and_after_late_original_reply": True,
        "active_sibling_for_normal_eof": sibling,
        "error_or_unconfirmed_stop_branch": "not exercised by this real-worker gate; focused tests remain separate",
        "normal_shutdown_and_pid_absence": "caller must verify after this scenario",
    }
    server.entry["rpc_checks"].append(result)
    return result
