"""Staged scenario; imports unchanged SDK RPC observer. No process entrypoint.

Root supplies an initialized real App Server with the instrumented relay package,
a private marker directory, and previously captured exact native baseline. Root
owns successful build/inventory checks, install/select/remove, normal EOF finish,
final strict subreaper/PID absence and immutable executable verification.
"""

import json
import stat
import time

from acceptance_support import process_snapshot, require
from search_cases import ROOT, update


def marker(server, directory, name, *, before_reply=None):
    deadline = time.monotonic() + 60
    path = directory / (name + ".json")
    while not path.exists():
        require(time.monotonic() < deadline, "relay causal marker timed out")
        require(not server.eof, "server exited while waiting for causal marker")
        require(not (directory / "relay-failed.json").exists(), "relay failed")
        if before_reply is not None:
            require(not any(msg.get("id") == before_reply for _, msg in server.pending),
                    "original RPC replied before the held Open barrier")
        server.pump(0.02)
    require(stat.S_ISREG(path.lstat().st_mode), "marker is not regular")
    require(path.stat().st_size <= 8192, "marker exceeds ceiling")
    value = json.loads(path.read_text())
    require(value["event"] == name, "marker identity changed")
    return value


def trigger(directory, name):
    with (directory / name).open("xb") as stream:
        stream.write(b"acceptance runner\n")


def same_native(server, expected):
    server._track()
    current = process_snapshot().get(expected["pid"])
    require(current is not None and current.get("state") != "Z"
            and {k: v for k, v in current.items() if k != "state"} ==
                {k: v for k, v in expected.items() if k != "state"},
            "native process identity changed while exercising sibling")


def legacy_token_gate(server, directory, baseline):
    """Prove actual GUI-compatible legacy token cancellation while Open held."""
    ready = marker(server, directory, "worker-ready")
    server._track()
    native = process_snapshot().get(ready["native_pid"])
    require(native is not None, "actual native PID missing")
    require(native["parent"] == ready["relay_pid"], "worker is not relay child")
    require(ready["relay_pid"] in server.tracked, "relay is not host descendant")
    sibling = "preparing-sibling"
    server.request("fuzzyFileSearch/sessionStart", {"sessionId": sibling, "roots": [ROOT]})
    update(server, sibling, "alpha", baseline["lexical-alpha"])
    trigger(directory, "arm-next-open")
    token = "installed-preparing-target-legacy"
    original = server.send("fuzzyFileSearch", {
        "query": "alpha", "roots": [ROOT], "cancellationToken": token})
    held = marker(server, directory, "held-open-ready", before_reply=original)
    require(held["native_already_ready"] is True and held["open_bytes_delivered"] == 0,
            "gate did not hold a genuine native-ready reply")
    require(not any(msg.get("id") == original for _, msg in server.pending),
            "original RPC completed with Open bytes held")
    update(server, sibling, "beta", baseline["beta"])
    same_native(server, native)
    cancelled = server.send("fuzzyFileSearch", {
        "query": "", "roots": [ROOT], "cancellationToken": token})
    released = marker(server, directory, "target-release-joined")
    sent = marker(server, directory, "target-release-sent")
    require(held["sequence"] < sent["sequence"] < released["sequence"],
            "release did not follow held native-ready Open")
    require(held["identity"] == sent["identity"] == released["identity"],
            "release targeted another lease")
    require(released["operation"] == "ok" and released["cleanup"] == "joined"
            and released["open_reply_still_held"] is True,
            "actual cleanup was not joined while held")
    require(not (directory / "release-open").exists()
            and not (directory / "held-open-forwarded.json").exists(),
            "Open reply escaped before cancellation proof")
    # Empty cancellation acknowledgement alone is insufficient; require original
    # request's retained owner to finish cleanly with actual release receipt.
    for request in (cancelled, original):
        _, response = server.response(request)
        require(response["result"] == {"files": []}, "cancelled target exposed files")
    update(server, sibling, "alpha", baseline["lexical-alpha"])
    same_native(server, native)
    trigger(directory, "release-open")
    forwarded = marker(server, directory, "held-open-forwarded")
    require(forwarded["sequence"] > released["sequence"], "held reply released early")
    require({key: held[key] for key in ("held_sha256", "held_bytes")} ==
            {key: forwarded[key] for key in ("held_sha256", "held_bytes")},
            "forwarded Open bytes differ")
    _, replacement = server.request("fuzzyFileSearch", {
        "query": "alpha", "roots": [ROOT], "cancellationToken": "replacement-token"})
    require(replacement["result"] == baseline["lexical-alpha"],
            "replacement after draining original reply differs")
    same_native(server, native)
    stop_sequence, _ = server.request("fuzzyFileSearch/sessionStop", {"sessionId": sibling})
    server.assert_quiet(sibling, stop_sequence)
    result = {"claim": "public legacy cancellation while installed host/process Preparing; native Ready",
              "original_request_id": original, "cancel_request_id": cancelled,
              "native_process": native, "held": held, "release": released,
              "forwarded": forwarded, "sibling_same_worker": True,
              "original_and_cancel_files": [], "replacement_exact": True,
              "normal_shutdown_and_pid_absence": "caller must verify after this scenario"}
    server.entry["rpc_checks"].append(result)
    return result
