# Isolated relay validation

The frozen original stage manifest a49075933bf50c789aae9b4374ccc6af5c2c2f14c0dfb38c50fbca76fa0374ed
remains unchanged in /tmp/p02b-installed-preparing-gate-stage. A separate fixture
workspace /tmp/p02b-relay-fixture-validation-01 copied and verified its exact
relay (ae1b829f29d1f86b2f934bf009ab657ccd4972f89b70c2da4652d097d12f373e)
and scenario (beea45574eb7fd6481135d1456c0055b731aa0c1fe27eee49f17fc1dfb550a56).

One execution passed all six relay-only fixture cases, with no retries:

- Normal: interleaved requests/replies, complete exact target bytes withheld,
  complete actual fixture-child release reply delivered before unhold, byte-exact
  target/non-target forwarding, domain and physical shutdown, normal child reap.
- Malformed Open cursor: failed with exit 1, no Ready milestone.
- Advertised decoded body cap + 1: failed with exit 1, no Ready milestone.
- Wrong chunk index: failed with exit 1, no Ready milestone.
- Unconfirmed release: failed with exit 1, no Joined milestone.
- EOF without physical shutdown: failed with exit 1, no successful completion.

All twelve observed relay/fixture-child PIDs were absent, including zombies.
The fixture owner needed no emergency cleanup. Negative relay cases may terminate
their fixture child as failure cleanup; these are not evidence of normal native
shutdown. The unchanged SDK subreaper returned 0, runner_error null, and recorded
the fixture command exit 0. Only that command was reaped by the outer subreaper;
the relays owned their fixture children. No extra orphan or zombie exemption was
introduced.

The fixture child is intentionally fake and tests transport observation only.
No Codex host, independently built native worker, GUI or browser was run. The
Python scenario/runner passed syntax checks; they have not yet run against the
real host. These distinctions must carry into publication evidence.

Evidence retained:

- /tmp/p02b-relay-fixture-validation-01/report.json
  SHA256 47133a9fb4e2210af1e14621089f6b3911274ca17b9057df61a04e9f16f0a80b
- /tmp/p02b-relay-fixture-validation-01/subreaper.json
  SHA256 e0ebc68408801dfaa510c2867731af70646be477c0cb2af3214ef3574aa2937d
- /tmp/p02b-relay-fixture-validation-01/preimage-manifest.json contains original
  stage file hashes and unchanged subreaper hash fe01097ae1741cbcb76e15fb07c0c936108a4dc35c08b4264c1caa9eb1e08875.
- Each case preserves relay stderr, raw host/fixture byte streams, exact held
  response, private marker sequence and observed process IDs.
- syntax-check-01.json in this runner stage records the three proposed Python
  sources passing in-memory compilation. It does not execute their bodies.

All artifacts above are inside this cloud filesystem, not independently exported
or externally durable backups. Root owns publication/adoption and the real-host
acceptance run under its unchanged subreaper and source-fingerprint workflow.

The complete runner received independent static review with no blocking defect.
It does not itself reconstruct the compilation-to-binary binding: root must retain
the verified frozen candidate envelope/lineage. A reporting-only qualification
was added after review, and syntax-check-02.json binds those final runner bytes.
The relay and scenario remain exactly the fixture-validated originals.
