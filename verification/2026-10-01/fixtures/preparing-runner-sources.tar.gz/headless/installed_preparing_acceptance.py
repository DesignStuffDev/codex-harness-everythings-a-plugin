#!/usr/bin/env python3
"""Actual frozen host + genuine independently built worker via test-only relay.

Run only inside the unchanged SDK subreaper. No builds, realhost run or pass are
implied by staging this script. A same-host unchanged-package acceptance must
already have passed; instrumented evidence is a separate, narrower claim.
"""

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import sys

PLUGIN = "test.file-search-preparing-relay"


def arguments():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--server", type=Path, required=True)
    parser.add_argument("--server-sha256", required=True)
    parser.add_argument("--server-build-report", type=Path, required=True)
    parser.add_argument("--server-mode", choices=("standalone", "codex"), default="standalone")
    parser.add_argument("--scenario", choices=("legacy", "session-stop"), default="legacy")
    parser.add_argument("--manager", type=Path, required=True)
    parser.add_argument("--build-report", type=Path, required=True)
    parser.add_argument("--normal-acceptance-report", type=Path, required=True)
    parser.add_argument("--normal-subreaper-report", type=Path, required=True)
    parser.add_argument("--work-dir", type=Path, required=True)
    return parser.parse_args()


def main():
    args = arguments()
    repo = args.repo.resolve(strict=True)
    sdk = repo / "component-sdk/tests/file_search"
    sys.path.insert(0, str(sdk))
    from acceptance_support import Runner, fingerprint, inventory, require, same_content, write_report
    from rpc_support import RpcServer
    from search_cases import one_shots, prepare_fixture, streams
    from public_rpc_gate import legacy_token_gate
    from public_session_stop_gate import session_stop_gate

    server = args.server.resolve(strict=True)
    manager = args.manager.resolve(strict=True)
    proof_path = args.build_report.resolve(strict=True)
    server_proof_path = args.server_build_report.resolve(strict=True)
    normal_path = args.normal_acceptance_report.resolve(strict=True)
    normal_outer_path = args.normal_subreaper_report.resolve(strict=True)
    proof = json.loads(proof_path.read_text())
    server_proof = json.loads(server_proof_path.read_text())
    normal = json.loads(normal_path.read_text())
    normal_outer = json.loads(normal_outer_path.read_text())
    before = {"server": fingerprint(server), "manager": fingerprint(manager)}
    require(before["server"]["sha256"] == args.server_sha256, "host digest differs")
    require(server_proof.get("returncode") == 0
            and server_proof.get("scoped_source_unchanged") is True,
            "successful unchanged-source frozen host build required")
    require(proof.get("passed") is True and proof.get("evidence_kind") == "independent_source_build",
            "successful independent worker build required")
    require(proof["build_artifact"]["separate_initially_empty_target"] is True
            and proof["build_artifact"]["fresh"] is False,
            "native worker was not independently compiled")
    require(proof["source_resolution"]["all_local_paths_inside_export"] is True
            and proof["source_resolution"]["lock_new_identities"] == 0,
            "worker dependency/source proof missing")
    require(proof["source_parked_before_runtime"] is True
            and not (Path(proof["artifact_directory"]) / "source").exists(),
            "worker build source was not parked")
    source_inventory = Path(proof["artifact_directory"]) / "source-inventory.json"
    require(fingerprint(source_inventory) == proof["exported_source_inventory"],
            "source inventory changed")
    require(proof["frozen_binaries_before"]["manager"]
            == proof["frozen_binaries_after"]["manager"] == before["manager"],
            "manager differs from independent build proof")
    package = Path(proof["package_path"]).resolve(strict=True)
    package_files = inventory(package)
    require(package_files == proof["package_files"], "original native package changed")
    require(normal.get("passed") is True
            and normal.get("evidence_kind") == "real_app_server_independent_native_search"
            and normal.get("binaries_before") == normal.get("binaries_after") == before,
            "same frozen host/manager must pass normal unchanged-package acceptance first")
    for key in ("frozen_binaries_unchanged", "independent_package_unchanged", "build_proof_unchanged",
                "server_proof_unchanged", "tooling_unchanged", "subreaper_unchanged",
                "installed_package_unchanged"):
        require(normal.get(key) is True, "normal acceptance preservation check missing")
    require(normal["independent_package"]["files"] == package_files
            and normal["worker_build_report"] == {"path": str(proof_path), **fingerprint(proof_path)}
            and normal["app_server_build_report"] == {"path": str(server_proof_path), **fingerprint(server_proof_path)},
            "normal acceptance uses another native package/build source tuple")
    require(normal_outer.get("exit_status") == 0 and normal_outer.get("command_returncode") == 0
            and normal_outer.get("runner_error") is None and normal_outer.get("subreaper") is True,
            "normal acceptance lacks successful unchanged subreaper proof")
    require(str(normal_path.parent) in normal_outer.get("command", []),
            "normal subreaper command does not name the acceptance work directory")
    subreaper = repo / "component-sdk/tests/subreaper_runner.py"
    require(normal["subreaper"] == {"path": str(subreaper), **fingerprint(subreaper)},
            "subreaper changed since normal acceptance")
    stage = Path(__file__).resolve().parent
    relay = stage / "preparing_relay.py"
    stage_files = {p.name: fingerprint(p) for p in stage.glob("*.py")}
    sdk_files = {p.name: fingerprint(p) for p in sdk.glob("*.py")}
    work = args.work_dir.resolve()
    require(not work.exists() and work != repo and repo not in work.parents,
            "fresh acceptance directory outside checkout required")
    work.mkdir(mode=0o700, parents=True)
    report_path = work / "installed-preparing-acceptance.json"
    evidence_inputs = {
        name: {"path": str(path), **fingerprint(path)}
        for name, path in (("worker_build", proof_path), ("server_build", server_proof_path),
                           ("normal_acceptance", normal_path), ("normal_subreaper", normal_outer_path))}
    report = {
        "passed": False, "evidence_kind": "instrumented_real_native_worker_host_preparing",
        "started_utc": datetime.now(timezone.utc).isoformat(), "artifact_directory": str(work),
        "scope": "Real public RPC cancellation with host/process Preparing; native already Ready. Test-only byte-preserving transport relay. No GUI or native-constructor Preparing proof.",
        "scenario": args.scenario,
        "scenario_scope": "Legacy GUI-compatible token retirement" if args.scenario == "legacy" else "Public same-ID Start/Stop/later-Start FIFO with reader intent",
        "source_binary_binding_authority": "Caller-verified frozen candidate lineage; this runner checks supplied digests/build receipts and same-host normal acceptance, but does not reconstruct compilation provenance.",
        "commands": [], "rpc_processes": [], "binaries_before": before,
        "evidence_inputs": evidence_inputs, "stage_tooling": stage_files, "sdk_tooling": sdk_files,
        "subreaper": {"path": str(subreaper), **fingerprint(subreaper)},
        "independent_package": {"path": str(package), "files": package_files},
        "pid_policy": "All observed descendants must be absent, including zombies; no retries or forced-cleanup pass.",
    }
    runner = Runner(work, report, report_path)
    home, base = work / "home", work / "fixture"
    home.mkdir(); base.mkdir()
    (home / "config.toml").write_text("[features]\nshell_snapshot = false\n")
    environment = dict(os.environ, CODEX_HOME=str(home), RUST_LOG="warn",
                       CODEX_APP_SERVER_MANAGED_CONFIG_PATH=str(home / "managed_config.toml"))
    environment.pop("CODEX_INTERNAL_ORIGINATOR_OVERRIDE", None)
    server_command = [server, *(["app-server"] if args.server_mode == "codex" else []), "--listen", "stdio://"]
    management = [manager, "--codex-home", home]
    installed = None
    active = None
    try:
        prepare_fixture(base)
        report["fixture_files"] = inventory(base)
        active = RpcServer("native-baseline", server_command, base, environment, work, report, report_path)
        active.initialize()
        baseline = one_shots(active)
        report["native_baseline"] = baseline
        active.finish()
        active = None

        derived = work / "instrumented-input"
        shutil.copytree(package, derived)
        require(same_content(inventory(derived), package_files), "copy changed original package")
        manifest_path = derived / "codex-component.json"
        original_manifest = json.loads(manifest_path.read_text())
        require(original_manifest["id"] == "native.file-search-local"
                and original_manifest["args"] == []
                and original_manifest["api_version"] == 1,
                "unexpected base manifest")
        worker_relative = Path(original_manifest["entrypoint"])
        require(not worker_relative.is_absolute() and ".." not in worker_relative.parts,
                "base entrypoint is not package relative")
        native_original = package / worker_relative
        require(native_original.is_file() and not native_original.is_symlink(), "native worker missing")
        require(any(c["kind"] == "file_search" and c["name"] == "default"
                    and c["contract_version"] == 1
                    and c.get("metadata", {}).get("preparing_cancel_receipt") == 1
                    for c in original_manifest["components"]), "worker declaration lacks Preparing receipts")
        require(not (derived / "preparing_relay.py").exists(), "relay path collides with original package")
        shutil.copy2(relay, derived / "preparing_relay.py")
        (derived / "preparing_relay.py").chmod(0o755)
        instrumented_manifest = {**original_manifest, "id": PLUGIN,
                                 "entrypoint": "preparing_relay.py",
                                 "args": ["--worker", worker_relative.as_posix()]}
        manifest_path.write_text(json.dumps(instrumented_manifest, indent=2) + "\n")
        derived_files = inventory(derived)
        require(set(derived_files) == set(package_files) | {"preparing_relay.py"},
                "instrumented package contains unexpected files")
        for name, original in package_files.items():
            if name != "codex-component.json":
                require(same_content({name: derived_files[name]}, {name: original}),
                        "instrumented package modified original source/license/worker")
        report["instrumented_package"] = {"files": derived_files, "original_manifest": original_manifest,
                                            "manifest": instrumented_manifest,
                                            "scope": "Only manifest selection/entrypoint/args and added relay differ; worker/licenses/sources unchanged."}
        runner.run("install", [*management, "install", derived], cwd=base, environment=environment)
        runner.run("select", [*management, "select", "file_search", "default", PLUGIN], cwd=base, environment=environment)
        output, _, _ = runner.run("list-selected", [*management, "list"], cwd=base, environment=environment)
        settings = json.loads(output)
        require(settings["selections"].get("file_search:default") == PLUGIN
                and PLUGIN in settings["enabled"], "instrumented selection not active")
        installed = home / "components/objects" / settings["installed"][PLUGIN]
        installed_files = inventory(installed)
        require(same_content(installed_files, derived_files), "installed package differs")
        native = (installed / worker_relative).resolve(strict=True)
        require(installed in native.parents, "native worker escapes installed object")
        report["installed_package"] = {"path": str(installed), "files": installed_files}
        report["installed_native"] = {"path": str(native), **fingerprint(native)}
        require(fingerprint(native)["sha256"] == fingerprint(native_original)["sha256"],
                "installed native binary differs from independent worker")
        derived.rename(work / "instrumented-input.parked")
        report["instrumented_input_parked_before_runtime"] = True

        active = RpcServer("installed-host-preparing", server_command, base, environment, work, report, report_path)
        active.initialize()
        active.require_worker(native)
        directory = home / "components/state" / PLUGIN / "preparing-relay"
        scenario = legacy_token_gate if args.scenario == "legacy" else session_stop_gate
        report["causal_gate"] = scenario(active, directory, baseline)
        active.finish()
        complete = json.loads((directory / "relay-complete.json").read_text())
        require(complete["native_exit"] == 0 and complete["forced_cleanup"] is False,
                "relay did not normally reap native child")
        require(not (directory / "relay-failed.json").exists(), "relay failure marker exists")
        report["relay_complete"] = complete
        report["relay_markers"] = inventory(directory)
        require(same_content(inventory(installed), installed_files), "runtime modified installed package")
        active = None

        runner.run("remove", [*management, "remove", PLUGIN], cwd=base, environment=environment)
        output, _, _ = runner.run("list-removed", [*management, "list"], cwd=base, environment=environment)
        removed = json.loads(output)
        require(PLUGIN not in removed["installed"] and PLUGIN not in removed["enabled"]
                and "file_search:default" not in removed["selections"], "removal retained selection")
        active = RpcServer("removed-native-restored", server_command, base, environment, work, report, report_path)
        active.initialize()
        one_shots(active, baseline)
        streams(active, baseline)
        active.finish()
        require(not any(p.get("executable") == str(native) for p in active.entry["observed_processes"]),
                "removed instrumented plugin still ran")
        active = None
        report["passed"] = True
    except BaseException as error:
        report["failure"] = f"{type(error).__name__}: {error}"
        if active is not None:
            try:
                active.abort()
            except BaseException as cleanup:
                report["failure_cleanup_error"] = f"{type(cleanup).__name__}: {cleanup}"
        raise
    finally:
        report["finished_utc"] = datetime.now(timezone.utc).isoformat()
        report["binaries_after"] = {"server": fingerprint(server), "manager": fingerprint(manager)}
        checks = {
            "frozen_binaries_unchanged": report["binaries_after"] == before,
            "original_package_unchanged": inventory(package) == package_files,
            "source_inventory_unchanged": fingerprint(source_inventory) == proof["exported_source_inventory"],
            "input_proofs_unchanged": all(fingerprint(Path(v["path"])) == {k:x for k,x in v.items() if k != "path"} for v in evidence_inputs.values()),
            "stage_tooling_unchanged": {p.name:fingerprint(p) for p in stage.glob("*.py")} == stage_files,
            "sdk_tooling_unchanged": {p.name:fingerprint(p) for p in sdk.glob("*.py")} == sdk_files,
            "subreaper_unchanged": fingerprint(subreaper) == {k:v for k,v in report["subreaper"].items() if k != "path"},
            "installed_package_unchanged": installed is None or inventory(installed) == report.get("installed_package", {}).get("files"),
        }
        report["preservation_checks"] = checks
        if not all(checks.values()):
            report["passed"] = False
        write_report(report_path, report)
    require(report["passed"], "installed Preparing acceptance failed; see report")
    print(report_path)
    return 0


if __name__ == "__main__":
    sys.exit(main())
