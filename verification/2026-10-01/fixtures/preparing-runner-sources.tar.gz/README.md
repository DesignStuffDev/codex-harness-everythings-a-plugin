# Tested Preparing acceptance source fixtures

This archive preserves the exact source bytes of the separately staged headless
and GUI acceptance runners exercised for the 2026-10-01 search-lifecycle milestone.
Historical stage READMEs/manifests say unexecuted because that was their status
when frozen. Subsequent successful evidence is recorded outside this archive in
P02B_PREPARING_NEWHOST_EVIDENCE.md and P02B_PREPARING_GUI_HELD_EVIDENCE.md.

The headless tests hold a genuine successful Open reply while native search is
already Ready and the host/process is Preparing, then exercise legacy cancellation
and public session Stop. The GUI test clears the actual search query, observes
Joined release before forwarding that exact held reply, and retains full GUI and
manager-only SIGINT/cold-recovery regressions. SIGINT occurs after Open is unheld;
pending-Open shutdown and native-constructor cancellation are separate obligations.

This is a historical fixture replay bundle, not an installed portable SDK command.
Use headless/INVOCATIONS.json and gui/README.md for ordered inputs. A successful
same-host normal package run is required before each instrumented gate; GUI needs
a second fresh migration fixture. GUI provenance deliberately retains original
/workspace and /tmp absolute paths and preimage hashes. Another machine requires
reviewed restaging and fresh bound inputs; never disable those checks or rewrite
old receipts. Preserve original scripts/manifests when making a new revision.

Only reviewed regular source, documentation, preimages, manifests, LICENSE and
NOTICE are included. No credentials, private logs, runtime databases, bytecode,
compiled hosts/workers or screenshots are present. The public member manifest
beside this archive records every original source hash. Published source is not
a backup of private runtime state or frozen executable artifacts.
