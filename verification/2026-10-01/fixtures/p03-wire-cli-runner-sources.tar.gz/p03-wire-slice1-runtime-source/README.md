# Preserved source for the completed P03 CLI compatibility run

The original staged README/manifest are unchanged historical records. The later
run passed 24 commands on 2026-10-01; see P03_WIRE_SLICE1_RUNTIME_EVIDENCE.md and
p03-wire-slice1-runtime-results.json beside this archive in the repository.

This archive contains reviewed source and licenses only. Exact path/report pins
require reviewed restaging elsewhere; do not disable provenance or lifecycle
assertions to rerun it. No executable, runtime state, private report or credential
is included. The original independent worker build proof remains separate.
