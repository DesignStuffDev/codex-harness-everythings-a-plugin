# Staged P03 search CLI compatibility acceptance

This explicit compatibility gate reuses worker04's original independent-build
proof and package with the freshly built P03 search CLI and the original component
manager. It does not rebuild the worker or rewrite its proof. The repository CLI
acceptance script and support helper remain unchanged. The staged orchestrator is
a minimal copy; all fixture functions, cases, Runner calls and runtime assertions
are retained. It imports the actual repository acceptance_support.py without
writing Python bytecode caches.

The new CLI is bound to the exact root artifact receipt and successful unchanged
build report. The full codex-rs/ and component-sdk/ source subsets must match the
format report. The only accepted scope differences are MODULE.bazel added by the
build map and 1,293 SDK paths omitted: python 1,257; typescript 31; python-runtime 5.
All 8,861 build-map inputs must match current bytes before and after acceptance;
their size, mode, mtime, device, inode and link count must remain unchanged. This
does not cover generated/unlisted files or the omitted SDK paths. Prior library
tests used pre-format bytes and remain a separate execution.

The final check also preserves the original proof/package/source inventory,
source-parking condition, receipts, source reports, tooling and both executables,
including after a failed case. The original manager must exactly match its
worker04 build fingerprint. The new manager listed in the root receipt is not
used by this gate. The outer unchanged subreaper remains mandatory; retain raw
reap statuses without interpreting every descendant as successful. Process
polling can miss short-lived descendants.

Run only under root ownership, with a new work directory:

```sh
python3 -B /workspace/codex-harness-everythings-a-plugin/component-sdk/tests/subreaper_runner.py \
  --report /workspace/acceptance/p03-wire-slice1-cli-runtime.subreaper.json -- \
  python3 -B /tmp/p03-reused-search-cli-stage/reused_cli_acceptance.py \
  --repo /workspace/codex-harness-everythings-a-plugin \
  --cli /workspace/component-checkpoint-candidate-p03-wire-cli-20261001/codex-file-search \
  --manager /workspace/component-checkpoint-candidate-p02b-search-cli-20261001-02/codex-component \
  --build-report /workspace/acceptance/p02b-search-independent-04/independent-build.json \
  --runtime-artifact-receipt /workspace/acceptance/p03-wire-slice1-cli-artifact.json \
  --expected-source-report /workspace/acceptance/p03-wire-slice1-fmt.source.json \
  --tests-source-report /workspace/acceptance/p03-wire-slice1-tests.source.json \
  --work-dir /tmp/p03-wire-slice1-cli-runtime
```

Staging validation is in-memory Python syntax compilation and static comparison
with the original orchestrator. It is not acceptance execution or runtime proof.
Scope remains standalone one-root CLI; App Server, TUI, GUI, newly built manager
runtime, broker activation and independent worker rebuild are outside this gate.
