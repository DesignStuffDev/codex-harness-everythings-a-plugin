"""Explicit P03 host / preserved worker04 compatibility binding; no builds."""

from collections import Counter
import hashlib
import json
from pathlib import Path
import stat

from acceptance_support import fingerprint, require

REPO = Path('/workspace/codex-harness-everythings-a-plugin')
PINNED = {
    'worker_build': '32ff6abae383066ff6271d25d8194fd43a705a5a0621ca09d730e715ba9ed948',
    'runtime_receipt': '9093788b89952b86cf2e5ec936f274de3ea0df06b7b3b91d383297e00acd0354',
    'runtime_build': 'c3da48c94096a9ca91fc2ad16826bacc9fc65ce7d657dcea16e307ac785dd7a2',
    'formatted_source': '9776ae39a5b757a56a2f3fe2b9a56934e8b600c24b308d2d938fa157c7614c0e',
    'tested_source': '123778032f821923bf28d36a9db73e4f464939cf7199262c915168041e1a8cc0',
    'original_orchestrator': '6644ccac92e0c287ebba192a4607cea2ad9be071fbd7628e26591075f3fa5e6d',
    'acceptance_support': '838cee4184dbb0f29cf164fa186dbef5f43c004f993cc003fa3291075ebec194',
    'subreaper_runner': 'fe01097ae1741cbcb76e15fb07c0c936108a4dc35c08b4264c1caa9eb1e08875',
}
SDK_OMISSIONS = {'sdk/python': 1257, 'sdk/typescript': 31, 'sdk/python-runtime': 5}


def digest_map(mapping):
    return hashlib.sha256(json.dumps(mapping, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def checked_file(path):
    path = Path(path)
    info = path.lstat()
    require(stat.S_ISREG(info.st_mode), f'not a regular evidence/source file: {path}')
    result = fingerprint(path)
    later = path.lstat()
    stable = ('st_dev', 'st_ino', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    require(all(getattr(later, k) == getattr(info, k) for k in stable),
            f'file changed while fingerprinting: {path}')
    return {**result, 'device': info.st_dev, 'inode': info.st_ino, 'nlink': info.st_nlink, 'ctime_ns': info.st_ctime_ns}


def source_snapshot(repo, source_map):
    result = {}
    for name, expected in sorted(source_map.items()):
        relative = Path(name)
        require(not relative.is_absolute() and '..' not in relative.parts, 'unsafe source-map path')
        path = repo / relative
        require(path.resolve(strict=True) == path, f'source path contains symlink: {name}')
        value = checked_file(path)
        require(value['sha256'] == expected, f'current source differs from built input: {name}')
        result[name] = value
    return result


def finished(report, name, unchanged=False):
    require(report.get('status') == 'finished' and report.get('returncode') == 0
            and report.get('finished_utc'), f'{name} is not a successful terminal report')
    if unchanged:
        require(report.get('scoped_source_unchanged') is True
                and report['source_before'] == report['source_after'], f'{name} sources changed')


def bind(args, repo, cli, manager, proof, before, orchestrator, support_path):
    require(repo == REPO, 'this frozen compatibility helper is scoped to its recorded checkout')
    require(Path(support_path).resolve(strict=True) == repo / 'component-sdk/tests/file_search/acceptance_support.py',
            'imported acceptance support path differs')
    paths = {
        'worker_build': args.build_report.resolve(strict=True),
        'runtime_receipt': args.runtime_artifact_receipt.resolve(strict=True),
        'formatted_source': args.expected_source_report.resolve(strict=True),
        'tested_source': args.tests_source_report.resolve(strict=True),
        'original_orchestrator': repo / 'component-sdk/tests/file_search/cli_acceptance.py',
        'acceptance_support': Path(support_path).resolve(strict=True),
        'subreaper_runner': repo / 'component-sdk/tests/subreaper_runner.py',
        'staged_orchestrator': Path(orchestrator).resolve(strict=True),
        'staged_provenance': Path(__file__).resolve(strict=True),
        'stage_manifest': Path(__file__).with_name('manifest.json'),
        'stage_readme': Path(__file__).with_name('README.md'),
        'worker_source_inventory': Path(proof['artifact_directory']) / 'source-inventory.json',
    }
    receipt = json.loads(paths['runtime_receipt'].read_text())
    paths['runtime_build'] = Path(receipt['source_report']).resolve(strict=True)
    inputs = {name: {'path': str(path), **checked_file(path)} for name, path in paths.items()}
    manifest = json.loads(paths['stage_manifest'].read_text())
    for name in ('staged_orchestrator', 'staged_provenance', 'stage_readme'):
        require(inputs[name]['sha256'] == manifest['staged_files'][paths[name].name]['sha256'],
                f'staged file differs from manifest: {name}')
    for name, expected in PINNED.items():
        require(inputs[name]['sha256'] == expected, f'frozen provenance input changed: {name}')
    build = json.loads(paths['runtime_build'].read_text())
    formatted = json.loads(paths['formatted_source'].read_text())
    tested = json.loads(paths['tested_source'].read_text())
    finished(build, 'runtime build', unchanged=True)
    finished(formatted, 'format')
    finished(tested, 'library tests', unchanged=True)
    for name, report in [('build', build), ('format', formatted), ('tests', tested)]:
        require(Path(report['cwd']).resolve(strict=True) == repo / 'codex-rs', f'{name} checkout differs')
    require(receipt.get('evidence_kind') == 'newly_built_host_executables'
            and receipt.get('source_unchanged') is True
            and receipt['source_report_sha256'] == inputs['runtime_build']['sha256']
            and receipt['command'] == build['command']
            and receipt['log_sha256'] == build['log_sha256'], 'artifact receipt/build mismatch')
    bmap, fmap = build['source_after'], formatted['source_after']
    require(len(bmap) == receipt['source_entries'] == 8861 and len(fmap) == 10153,
            'unexpected source scope size')
    for prefix in ('codex-rs/', 'component-sdk/'):
        require({k: v for k, v in bmap.items() if k.startswith(prefix)}
                == {k: v for k, v in fmap.items() if k.startswith(prefix)},
                f'build/format complete source subset differs: {prefix}')
    build_only, format_only = set(bmap) - set(fmap), set(fmap) - set(bmap)
    require(build_only == {'MODULE.bazel'}, 'unexpected build-only source scope')
    require(dict(Counter('/'.join(k.split('/')[:2]) for k in format_only)) == SDK_OMISSIONS,
            'unexpected omitted SDK source scope')
    require(all(bmap[k] == fmap[k] for k in set(bmap) & set(fmap)), 'shared source hashes differ')
    require(tested['source_after'] == formatted['source_before'], 'test/format source chain differs')
    cli_entries = [x for x in receipt['artifacts'] if x['name'] == 'codex-file-search']
    require(len(cli_entries) == 1, 'receipt must contain one search CLI artifact')
    artifact = cli_entries[0]
    actual_cli = checked_file(cli)
    require(Path(artifact['path']) == cli
            and actual_cli['sha256'] == artifact['sha256']
            and actual_cli['bytes'] == artifact['bytes']
            and actual_cli['mode'] == int(artifact['mode'], 8) == 0o555
            and actual_cli['nlink'] == artifact['nlink'] == 1,
            'fresh CLI does not match frozen artifact receipt')
    require(proof['frozen_binaries_before'] == proof['frozen_binaries_after'],
            'original worker build changed its historical binaries')
    require(before['manager'] == proof['frozen_binaries_before']['manager'],
            'reuse mode requires the exact original component manager fingerprint')
    require(before['cli']['sha256'] != proof['frozen_binaries_before']['cli']['sha256'],
            'reuse gate requires the separately built fresh CLI')
    paths['fresh_cli'] = cli
    paths['original_manager'] = manager
    inputs.update({name: {'path': str(paths[name]), **checked_file(paths[name])}
                   for name in ('fresh_cli', 'original_manager')})
    metadata = source_snapshot(repo, bmap)
    changes = sorted(k for k in fmap if tested['source_after'][k] != fmap[k])
    report = {
        'mode': 'new_codec_linked_search_cli_with_original_manager_and_preserved_worker04',
        'inputs_before': inputs,
        'original_worker_build_proof_preserved': True,
        'original_manager_full_fingerprint_matches_worker_build': True,
        'fresh_cli_artifact': artifact,
        'other_receipt_artifacts_not_executed_by_this_gate': [x['name'] for x in receipt['artifacts'] if x != artifact],
        'source_scope': {
            'build_entries': len(bmap), 'format_entries': len(fmap),
            'common_entries': len(set(bmap) & set(fmap)),
            'exact_complete_subsets': ['codex-rs/', 'component-sdk/'],
            'build_only': {k: bmap[k] for k in sorted(build_only)},
            'format_only_prefix_counts': SDK_OMISSIONS,
            'build_map_sha256': digest_map(bmap),
            'current_build_map_bytes_match': True,
            'current_source_metadata_before_sha256': digest_map(metadata),
            'test_to_formatted_changed_paths': changes,
            'limitation': 'Checks every mapped build input; SDK omissions and unlisted/generated files are outside this current-source snapshot. Prior tests used pre-format bytes; this gate is a separate installed-worker CLI execution.',
        },
        'lifecycle_limit': 'Unchanged Runner assertions cover observed PIDs; process polling may miss short-lived descendants. Preserve outer strict subreaper report and raw reap statuses separately.',
    }
    state = {'paths': paths, 'inputs': inputs, 'repo': repo, 'source_map': bmap,
             'metadata': metadata, 'worker_source': Path(proof['artifact_directory']) / 'source'}
    return report, state


def verify_after(state):
    after = {name: {'path': str(path), **checked_file(path)} for name, path in state['paths'].items()}
    require(after == state['inputs'], 'bound provenance, tooling, binary or inventory changed during acceptance')
    metadata = source_snapshot(state['repo'], state['source_map'])
    require(metadata == state['metadata'], 'mapped source bytes/metadata changed during acceptance')
    require(not state['worker_source'].exists(), 'original worker source path became active')
    return {'inputs_after': after, 'all_bound_inputs_unchanged': True,
            'current_source_metadata_after_sha256': digest_map(metadata),
            'mapped_source_bytes_and_metadata_unchanged': True}
